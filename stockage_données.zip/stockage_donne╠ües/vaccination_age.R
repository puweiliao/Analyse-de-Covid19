rm(list=objects())
graphics.off()
setwd("~/M1/TER")
data.original.vaccination=read.csv("donnees-vaccination-par-tranche-dage-type-de-vaccin-et-departement.csv",sep=";")

data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="00-54")]<-1
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="55-64")]<-2
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="65-74")]<-2
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="75 et +")]<-2


####semaine_injection 2021_01 2021_24
data.original.vaccination<-data.original.vaccination[,c("semaine_injection","departement_residence","classe_age","taux_cumu_termine")]

#######On remplace NA par 0
data.original.vaccination$taux_cumu_termine[is.na(data.original.vaccination$taux_cumu_termine)]=0


V01_age1<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$classe_age=="1")])


