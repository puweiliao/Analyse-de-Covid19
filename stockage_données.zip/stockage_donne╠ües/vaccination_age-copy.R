rm(list=objects())
graphics.off()
setwd("~/M1/TER")
data.original.vaccination=read.csv("donnees-vaccination-par-tranche-dage-type-de-vaccin-et-departement.csv",sep=";")

data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="00-54")]<-1
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="55-64")]<-2
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="65-74")]<-2
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="75 et +")]<-2


####semaine_injection 2021_01 2021_24
data.original.vaccination<-data.original.vaccination[,c("semaine_injection","departement_residence","classe_age","taux_cumu_termine")]

#######On remplace NA par 0
data.original.vaccination$taux_cumu_termine[is.na(data.original.vaccination$taux_cumu_termine)]=0

##age1

V01_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$classe_age=="1")])
V02_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$classe_age=="1")])
V03_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$classe_age=="1")])
V04_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$classe_age=="1")])
V05_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$classe_age=="1")])
V06_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$classe_age=="1")])
V07_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$classe_age=="1")])
V08_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$classe_age=="1")])
V09_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$classe_age=="1")])
V10_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$classe_age=="1")])
V11_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$classe_age=="1")])
V12_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$classe_age=="1")])
V13_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$classe_age=="1")])
V14_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$classe_age=="1")])
V15_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$classe_age=="1")])
V16_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$classe_age=="1")])
V17_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$classe_age=="1")])
V18_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$classe_age=="1")])
V19_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$classe_age=="1")])
V20_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$classe_age=="1")])
V21_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$classe_age=="1")])
V22_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$classe_age=="1")])
V23_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$classe_age=="1")])
V24_age1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$classe_age=="1")])


##age2
V01_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$classe_age=="2")])
V02_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$classe_age=="2")])
V03_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$classe_age=="2")])
V04_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$classe_age=="2")])
V05_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$classe_age=="2")])
V06_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$classe_age=="2")])
V07_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$classe_age=="2")])
V08_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$classe_age=="2")])
V09_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$classe_age=="2")])
V10_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$classe_age=="2")])
V11_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$classe_age=="2")])
V12_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$classe_age=="2")])
V13_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$classe_age=="2")])
V14_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$classe_age=="2")])
V15_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$classe_age=="2")])
V16_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$classe_age=="2")])
V17_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$classe_age=="2")])
V18_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$classe_age=="2")])
V19_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$classe_age=="2")])
V20_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$classe_age=="2")])
V21_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$classe_age=="2")])
V22_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$classe_age=="2")])
V23_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$classe_age=="2")])
V24_age2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$classe_age=="2")])


age1=c(V01_age1,V02_age1, V03_age1, V04_age1, V05_age1, V06_age1, V07_age1, V08_age1, V09_age1, V10_age1, V11_age1, V12_age1, V13_age1, V14_age1, V15_age1, V16_age1, V17_age1, V18_age1, V19_age1, V20_age1, V21_age1, V22_age1, V23_age1,V24_age1)
age2=c(V01_age2,V02_age2, V03_age2, V04_age2, V05_age2, V06_age2, V07_age2, V08_age2, V09_age2, V10_age2, V11_age2, V12_age2, V13_age2, V14_age2, V15_age2, V16_age2, V17_age2, V18_age2, V19_age2, V20_age2, V21_age2, V22_age2, V23_age2,V24_age2)

vaccination<-data.frame(age1,age2)
write.csv(vaccination,file="~/M1/TER/vaccination_age.csv")

