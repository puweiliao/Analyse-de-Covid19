rm(list=objects())
graphics.off()
setwd("~/M1/TER")



t1=4.5
t2=4.5
t3=4.5
t4=4.5
t5=4.5
t6=5.0
t7=5.0
t8=5.5
t9=5.5
t10=7.5
t11=8.5
t12=9.0
t13=9.0
t14=10.0
t15=10.0
t16=11.5
t17=12.5
t18=13.5
t19=14.5
t20=15.5
t21=15.5
t22=16.5
t23=16.5
t24=17.0

V=c(t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23,t24)

T<-data.frame(V)
write.csv(T,file="~/M1/TER/temperature.csv")
  