rm(list=objects())
graphics.off()
setwd("~/M1/TER")
Y=read.csv("sp-pos-heb-fra-2021-06-25-19h10.csv",sep=";")
Y<-Y[,c("week","P","T","cl_age90")]
Y1<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S01")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S01")])
Y2<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S02")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S02")])
Y3<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S03")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S03")])
Y4<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S04")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S04")])
Y5<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S05")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S05")])
Y6<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S06")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S06")])
Y7<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S07")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S07")])
Y8<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S08")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S08")])
Y9<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S09")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S09")])
Y10<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S10")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S10")])
Y11<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S11")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S11")])
Y12<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S12")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S12")])
Y13<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S13")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S13")])
Y14<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S14")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S14")])
Y15<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S15")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S15")])
Y16<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S16")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S16")])
Y17<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S17")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S17")])
Y18<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S18")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S18")])
Y19<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S19")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S19")])
Y20<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S20")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S20")])
Y21<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S21")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S21")])
Y22<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S22")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S22")])
Y23<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S23")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S23")])
Y24<-(Y$P[which(Y$cl_age90==0 & Y$week=="2021-S24")]/Y$T[which(Y$cl_age90==0 & Y$week=="2021-S24")])


Y1=100*Y1
Y2=100*Y2
Y3=100*Y3
Y4=100*Y4
Y5=100*Y5
Y6=100*Y6
Y7=100*Y7
Y8=100*Y8
Y9=100*Y9
Y10=100*Y10
Y11=100*Y11
Y12=100*Y12
Y13=100*Y13
Y14=100*Y14
Y15=100*Y15
Y16=100*Y16
Y17=100*Y17
Y18=100*Y18
Y19=100*Y19
Y20=100*Y20
Y21=100*Y21
Y22=100*Y22
Y23=100*Y23
Y24=100*Y24






Y<-c(Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8,Y9,Y10,Y11,Y12,Y13,Y14,Y15,Y16,Y17,Y18,Y19,Y20,Y21,Y22,Y23,Y24)
Y<-data.frame(Y)
write.csv(Y,file="~/M1/TER/Ydata.csv")
