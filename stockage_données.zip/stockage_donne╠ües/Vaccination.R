rm(list=objects())
graphics.off()
setwd("~/M1/TER")
data.original.vaccination=read.csv("donnees-vaccination-par-tranche-dage-type-de-vaccin-et-departement.csv",sep=";")


data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="95")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="92")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="91")]<-2

data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="85")]<-1
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="86")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="80")]<-2

data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="79")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="78")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="76")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="75")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="72")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="18")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="28")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="36")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="37")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="41")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="45")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="02")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="14")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="27")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="50")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="61")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="59")]<-3
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="60")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="62")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="44")]<-1

data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="49")]<-1
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="53")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="22")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="29")]<-1
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="35")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="56")]<-1





############
############
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="90")]<-4

data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="94")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="93")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="89")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="88")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="77")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="71")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="70")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="68")]<-4
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="67")]<-4
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="21")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="25")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="39")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="58")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="08")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="10")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="51")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="52")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="54")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="55")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="57")]<-4





data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="84")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="83")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="73")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="74")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="69")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="66")]<-7
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="01")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="03")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="07")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="15")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="26")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="38")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="42")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="43")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="63")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="04")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="05")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="06")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="13")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="2A")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="2B")]<-9



data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="87")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="82")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="81")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="16")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="17")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="19")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="23")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="24")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="33")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="40")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="47")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="64")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="9")]<-7
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="11")]<-7
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="12")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="30")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="31")]<-7
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="32")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="34")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="46")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="48")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="65")]<-8


#####classment age
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="00-54")]<-1
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="55-64")]<-2
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="65-74")]<-2
data.original.vaccination$classe_age[which(data.original.vaccination$classe_age=="75 et +")]<-2



####semaine_injection 2021_01 2021_24
data.original.vaccination<-data.original.vaccination[,c("semaine_injection","departement_residence","classe_age","taux_cumu_termine")]

#######On remplace NA par 0
data.original.vaccination$taux_cumu_termine[is.na(data.original.vaccination$taux_cumu_termine)]=0

#####semaine injection_region_classeage

V01_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V02_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V03_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V04_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V05_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V06_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V07_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V08_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V09_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V10_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V11_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V12_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V13_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V14_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V15_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V16_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V17_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V18_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V19_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V20_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V21_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V22_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V23_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])

V24_11<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="1")])


V01_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V02_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V03_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V04_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V05_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V06_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V07_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V08_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V09_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V10_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V11_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V12_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V13_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V14_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V15_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V16_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V17_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V18_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V19_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V20_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V21_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V22_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V23_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])

V24_21<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="1")])


V01_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V02_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V03_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V04_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V05_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V06_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V07_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V08_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V09_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V10_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V11_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V12_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V13_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V14_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V15_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V16_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V17_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V18_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V19_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V20_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V21_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V22_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V23_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])

V24_31<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="1")])



V01_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V02_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V03_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V04_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V05_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V06_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V07_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V08_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V09_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V10_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V11_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V12_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V13_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V14_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V15_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V16_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V17_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V18_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V19_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V20_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V21_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V22_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V23_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])

V24_41<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="1")])



V01_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V02_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V03_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V04_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V05_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V06_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V07_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V08_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V09_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V10_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V11_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V12_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V13_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V14_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V15_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V16_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V17_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V18_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V19_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V20_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V21_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V22_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V23_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])

V24_12<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="1" & data.original.vaccination$classe_age=="2")])


V01_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V02_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V03_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V04_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V05_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V06_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V07_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V08_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V09_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V10_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V11_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V12_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V13_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V14_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V15_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V16_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V17_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V18_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V19_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V20_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V21_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V22_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V23_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])

V24_22<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="2" & data.original.vaccination$classe_age=="2")])


V01_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V02_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V03_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V04_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V05_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V06_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V07_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V08_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V09_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V10_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V11_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V12_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V13_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V14_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V15_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V16_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V17_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V18_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V19_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V20_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V21_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V22_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V23_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])

V24_32<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="3" & data.original.vaccination$classe_age=="2")])



V01_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V02_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V03_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V04_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V05_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V06_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V07_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V08_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V09_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V10_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V11_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V12_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V13_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V14_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V15_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V16_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V17_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V18_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V19_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V20_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V21_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V22_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V23_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])

V24_42<-sum(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="4" & data.original.vaccination$classe_age=="2")])



######variables
V11=c(V01_11,V02_11, V03_11, V04_11, V05_11, V06_11, V07_11, V08_11, V09_11, V10_11, V11_11, V12_11, V13_11, V14_11, V15_11, V16_11, V17_11, V18_11, V19_11, V20_11, V21_11, V22_11, V23_11,V24_11)

V21=c(V01_21,V02_21, V03_21, V04_21, V05_21, V06_21, V07_21, V08_21, V09_21, V10_21, V11_21, V12_21, V13_21, V14_21, V15_21, V16_21, V17_21, V18_21, V19_21, V20_21, V21_21, V22_21, V23_21,V24_21)

V31=c(V01_31,V02_31, V03_31, V04_31, V05_31, V06_31, V07_31, V08_31, V09_31, V10_31, V11_31, V12_31, V13_31, V14_31, V15_31, V16_31, V17_31, V18_31, V19_31, V20_31, V21_31, V22_31, V23_31,V24_31)

V41=c(V01_41,V02_41, V03_41, V04_41, V05_41, V06_41, V07_41, V08_41, V09_41, V10_41, V11_41, V12_41, V13_41, V14_41, V15_41, V16_41, V17_41, V18_41, V19_41, V20_41, V21_41, V22_41, V23_41,V24_41)

V12=c(V01_12,V02_12, V03_12, V04_12, V05_12, V06_12, V07_12, V08_12, V09_12, V10_12, V11_12, V12_12, V13_12, V14_12, V15_12, V16_12, V17_12, V18_12, V19_12, V20_12, V21_12, V22_12, V23_12,V24_12)

V22=c(V01_22,V02_22, V03_22, V04_22, V05_22, V06_22, V07_22, V08_22, V09_22, V10_22, V11_22, V12_22, V13_22, V14_22, V15_22, V16_22, V17_22, V18_22, V19_22, V20_22, V21_22, V22_22, V23_22,V24_22)

V32=c(V01_32,V02_32, V03_32, V04_32, V05_32, V06_32, V07_32, V08_32, V09_32, V10_32, V11_32, V12_32, V13_32, V14_32, V15_32, V16_32, V17_32, V18_32, V19_32, V20_32, V21_32, V22_32, V23_32,V24_32)

V42=c(V01_42,V02_42, V03_42, V04_42, V05_42, V06_42, V07_42, V08_42, V09_42, V10_42, V11_42, V12_42, V13_42, V14_42, V15_42, V16_42, V17_42, V18_42, V19_42, V20_42, V21_42, V22_42, V23_42,V24_42)



vaccination<-data.frame(V11,V21,V31,V41,V12,V22,V32,V42)
write.csv(vaccination,file="~/M1/TER/vaccination.csv")



