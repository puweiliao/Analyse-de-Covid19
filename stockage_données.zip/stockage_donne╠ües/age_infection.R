rm(list=objects())
graphics.off()
setwd("~/M1/TER")
data.original.infection=read.csv("sp-pos-quot-reg-2021-06-20-19h08.csv",sep=";")


#découpage de date
#on extrait jeu de données de 2021-01-01 à 2021-06-15
data.filtrage.infection=data.original.infection[which(data.original.infection$jour=="2021-01-01"):which(data.original.infection$jour=="2021-06-16"),]


####classment age
#if age<60 then classment 1, if not classment 2###
########
data.filtrage.infection$cl_age90[which(data.filtrage.infection$cl_age90<60 & data.filtrage.infection$cl_age90>0)]<-1
data.filtrage.infection$cl_age90[which(data.filtrage.infection$cl_age90>60)]<-2


data.filtrage<-data.filtrage.infection[,c("reg","jour","P","T","cl_age90")]


############
####regroupement de variables
############

######variable age 1
##age1
age1_0101_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-01")])
age1_0101_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-01")])
age1_0102_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-02")])
age1_0102_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-02")])
age1_0103_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-03")])
age1_0103_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-03")])
age1_0104_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-04")])
age1_0104_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-04")])
age1_0105_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-05")])
age1_0105_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-05")])
age1_0106_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-06")])
age1_0106_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-06")])
age1_0107_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-07")])
age1_0107_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-07")])
age1_0108_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-08")])
age1_0108_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-08")])
age1_0109_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-09")])
age1_0109_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-09")])
age1_0110_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-10")])
age1_0110_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-10")])
age1_0111_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-11")])
age1_0111_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-11")])
age1_0112_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-12")])
age1_0112_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-12")])
age1_0113_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-13")])
age1_0113_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-13")])
age1_0114_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-14")])
age1_0114_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-14")])
age1_0115_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-15")])
age1_0115_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-15")])
age1_0116_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-16")])
age1_0116_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-16")])
age1_0117_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-17")])
age1_0117_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-17")])
age1_0118_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-18")])
age1_0118_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-18")])
age1_0119_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-19")])
age1_0119_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-19")])
age1_0120_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-20")])
age1_0120_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-20")])
age1_0121_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-21")])
age1_0121_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-21")])
age1_0122_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-22")])
age1_0122_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-22")])
age1_0123_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-23")])
age1_0123_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-23")])
age1_0124_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-24")])
age1_0124_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-24")])
age1_0125_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-25")])
age1_0125_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-25")])
age1_0126_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-26")])
age1_0126_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-26")])
age1_0127_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-27")])
age1_0127_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-27")])
age1_0128_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-28")])
age1_0128_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-28")])
age1_0129_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-29")])
age1_0129_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-29")])

age1_0130_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-30")])
age1_0130_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-30")])
age1_0131_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-31")])
age1_0131_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-31")])




age1_0201_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-01")])
age1_0201_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-01")])
age1_0202_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-02")])
age1_0202_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-02")])
age1_0203_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-03")])
age1_0203_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-03")])
age1_0204_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-04")])
age1_0204_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-04")])
age1_0205_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-05")])
age1_0205_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-05")])
age1_0206_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-06")])
age1_0206_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-06")])
age1_0207_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-07")])
age1_0207_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-07")])
age1_0208_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-08")])
age1_0208_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-08")])
age1_0209_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-09")])
age1_0209_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-09")])
age1_0210_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-10")])
age1_0210_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-10")])
age1_0211_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-11")])
age1_0211_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-11")])
age1_0212_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-12")])
age1_0212_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-12")])
age1_0213_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-13")])
age1_0213_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-13")])
age1_0214_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-14")])
age1_0214_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-14")])
age1_0215_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-15")])
age1_0215_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-15")])
age1_0216_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-16")])
age1_0216_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-16")])
age1_0217_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-17")])
age1_0217_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-17")])
age1_0218_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-18")])
age1_0218_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-18")])
age1_0219_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-19")])
age1_0219_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-19")])
age1_0220_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-20")])
age1_0220_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-20")])
age1_0221_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-21")])
age1_0221_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-21")])
age1_0222_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-22")])
age1_0222_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-22")])
age1_0223_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-23")])
age1_0223_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-23")])
age1_0224_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-24")])
age1_0224_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-24")])
age1_0225_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-25")])
age1_0225_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-25")])
age1_0226_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-26")])
age1_0226_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-26")])
age1_0227_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-27")])
age1_0227_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-27")])
age1_0228_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-28")])
age1_0228_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-02-28")])

age1_0301_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-01")])
age1_0301_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-01")])

age1_0302_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-02")])
age1_0302_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-02")])

age1_0303_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-03")])
age1_0303_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-03")])

age1_0304_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-04")])
age1_0304_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-04")])

age1_0305_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-05")])
age1_0305_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-05")])

age1_0306_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-06")])
age1_0306_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-06")])

age1_0307_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-07")])
age1_0307_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-07")])


age1_0308_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-08")])
age1_0308_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-08")])

age1_0309_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-09")])
age1_0309_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-09")])

age1_0310_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-10")])
age1_0310_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-10")])

age1_0311_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-11")])
age1_0311_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-11")])

age1_0312_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-12")])
age1_0312_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-12")])

age1_0313_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-13")])
age1_0313_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-13")])

age1_0314_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-14")])
age1_0314_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-14")])

age1_0315_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-15")])
age1_0315_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-15")])

age1_0316_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-16")])
age1_0316_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-16")])

age1_0317_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-17")])
age1_0317_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-17")])

age1_0318_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-18")])
age1_0318_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-18")])

age1_0319_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-19")])
age1_0319_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-19")])

age1_0320_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-20")])
age1_0320_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-20")])

age1_0321_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-21")])
age1_0321_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-21")])

age1_0322_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-22")])
age1_0322_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-22")])

age1_0323_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-23")])
age1_0323_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-23")])

age1_0324_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-24")])
age1_0324_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-24")])

age1_0325_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-25")])
age1_0325_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-25")])

age1_0326_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-26")])
age1_0326_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-26")])

age1_0327_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-27")])
age1_0327_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-27")])

age1_0328_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-28")])
age1_0328_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-28")])

age1_0329_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-29")])
age1_0329_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-29")])

age1_0330_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-30")])
age1_0330_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-30")])

age1_0331_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-31")])
age1_0331_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-03-31")])

age1_0501_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-01")])
age1_0501_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-01")])

age1_0502_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-02")])
age1_0502_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-02")])

age1_0503_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-03")])
age1_0503_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-03")])

age1_0504_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-04")])
age1_0504_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-04")])

age1_0505_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-05")])
age1_0505_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-05")])

age1_0506_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-06")])
age1_0506_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-06")])

age1_0507_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-07")])
age1_0507_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-07")])

age1_0508_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-08")])
age1_0508_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-08")])

age1_0509_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-09")])
age1_0509_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-09")])

age1_0510_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-10")])
age1_0510_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-10")])

age1_0511_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-11")])
age1_0511_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-11")])

age1_0512_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-12")])
age1_0512_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-12")])

age1_0513_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-13")])
age1_0513_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-13")])

age1_0514_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-14")])
age1_0514_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-14")])

age1_0515_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-15")])
age1_0515_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-15")])

age1_0516_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-16")])
age1_0516_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-16")])

age1_0517_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-17")])
age1_0517_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-17")])

age1_0518_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-18")])
age1_0518_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-18")])

age1_0519_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-19")])
age1_0519_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-19")])

age1_0520_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-20")])
age1_0520_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-20")])

age1_0521_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-21")])
age1_0521_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-21")])

age1_0522_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-22")])
age1_0522_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-22")])

age1_0523_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-23")])
age1_0523_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-23")])

age1_0524_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-24")])
age1_0524_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-24")])

age1_0525_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-25")])
age1_0525_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-25")])

age1_0526_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-26")])
age1_0526_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-26")])

age1_0527_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-27")])
age1_0527_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-27")])

age1_0528_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-28")])
age1_0528_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-28")])

age1_0529_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-29")])
age1_0529_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-29")])

age1_0530_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-30")])
age1_0530_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-30")])

age1_0531_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-31")])
age1_0531_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-05-31")])

age1_0601_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-01")])
age1_0601_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-01")])
age1_0602_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-02")])
age1_0602_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-02")])
age1_0603_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-03")])
age1_0603_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-03")])
age1_0604_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-04")])
age1_0604_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-04")])
age1_0605_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-05")])
age1_0605_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-05")])
age1_0606_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-06")])
age1_0606_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-06")])
age1_0607_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-07")])
age1_0607_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-07")])
age1_0608_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-08")])
age1_0608_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-08")])
age1_0609_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-09")])
age1_0609_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-09")])
age1_0610_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-10")])
age1_0610_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-10")])
age1_0611_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-11")])
age1_0611_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-11")])
age1_0612_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-12")])
age1_0612_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-12")])
age1_0613_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-13")])
age1_0613_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-13")])
age1_0614_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-14")])
age1_0614_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-14")])
age1_0615_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-15")])
age1_0615_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-15")])
age1_0616_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-16")])
age1_0616_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-16")])
age1_0617_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-17")])
age1_0617_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-17")])
age1_0618_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-18")])
age1_0618_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-18")])
age1_0619_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-19")])
age1_0619_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-19")])
age1_0620_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-20")])
age1_0620_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-20")])
age1_0621_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-21")])
age1_0621_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-21")])
age1_0622_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-22")])
age1_0622_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-22")])
age1_0623_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-23")])
age1_0623_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-23")])
age1_0624_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-24")])
age1_0624_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-24")])
age1_0625_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-25")])
age1_0625_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-06-25")])


######variable age 1
##age2
age2_0101_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-01")])
age2_0101_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-01")])
age2_0102_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-02")])
age2_0102_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-02")])
age2_0103_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-03")])
age2_0103_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-03")])
age2_0104_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-04")])
age2_0104_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-04")])
age2_0105_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-05")])
age2_0105_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-05")])
age2_0106_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-06")])
age2_0106_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-06")])
age2_0107_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-07")])
age2_0107_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-07")])
age2_0108_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-08")])
age2_0108_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-08")])
age2_0109_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-09")])
age2_0109_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-09")])
age2_0110_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-10")])
age2_0110_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-10")])
age2_0111_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-11")])
age2_0111_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-11")])
age2_0112_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-12")])
age2_0112_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-12")])
age2_0113_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-13")])
age2_0113_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-13")])
age2_0114_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-14")])
age2_0114_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-14")])
age2_0115_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-15")])
age2_0115_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-15")])
age2_0116_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-16")])
age2_0116_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-16")])
age2_0117_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-17")])
age2_0117_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-17")])
age2_0118_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-18")])
age2_0118_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-18")])
age2_0119_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-19")])
age2_0119_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-19")])
age2_0120_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-20")])
age2_0120_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-20")])
age2_0121_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-21")])
age2_0121_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-21")])
age2_0122_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-22")])
age2_0122_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-22")])
age2_0123_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-23")])
age2_0123_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-23")])
age2_0124_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-24")])
age2_0124_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-24")])
age2_0125_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-25")])
age2_0125_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-25")])
age2_0126_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-26")])
age2_0126_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-26")])
age2_0127_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-27")])
age2_0127_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-27")])
age2_0128_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-28")])
age2_0128_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-28")])
age2_0129_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-29")])
age2_0129_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-29")])

age2_0130_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-30")])
age2_0130_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-30")])
age2_0131_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-31")])
age2_0131_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-31")])




age2_0201_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-01")])
age2_0201_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-01")])
age2_0202_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-02")])
age2_0202_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-02")])
age2_0203_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-03")])
age2_0203_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-03")])
age2_0204_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-04")])
age2_0204_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-04")])
age2_0205_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-05")])
age2_0205_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-05")])
age2_0206_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-06")])
age2_0206_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-06")])
age2_0207_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-07")])
age2_0207_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-07")])
age2_0208_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-08")])
age2_0208_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-08")])
age2_0209_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-09")])
age2_0209_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-09")])
age2_0210_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-10")])
age2_0210_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-10")])
age2_0211_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-11")])
age2_0211_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-11")])
age2_0212_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-12")])
age2_0212_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-12")])
age2_0213_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-13")])
age2_0213_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-13")])
age2_0214_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-14")])
age2_0214_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-14")])
age2_0215_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-15")])
age2_0215_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-15")])
age2_0216_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-16")])
age2_0216_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-16")])
age2_0217_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-17")])
age2_0217_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-17")])
age2_0218_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-18")])
age2_0218_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-18")])
age2_0219_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-19")])
age2_0219_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-19")])
age2_0220_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-20")])
age2_0220_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-20")])
age2_0221_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-21")])
age2_0221_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-21")])
age2_0222_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-22")])
age2_0222_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-22")])
age2_0223_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-23")])
age2_0223_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-23")])
age2_0224_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-24")])
age2_0224_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-24")])
age2_0225_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-25")])
age2_0225_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-25")])
age2_0226_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-26")])
age2_0226_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-26")])
age2_0227_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-27")])
age2_0227_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-27")])
age2_0228_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-28")])
age2_0228_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-02-28")])

age2_0301_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-01")])
age2_0301_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-01")])

age2_0302_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-02")])
age2_0302_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-02")])

age2_0303_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-03")])
age2_0303_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-03")])

age2_0304_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-04")])
age2_0304_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-04")])

age2_0305_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-05")])
age2_0305_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-05")])

age2_0306_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-06")])
age2_0306_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-06")])

age2_0307_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-07")])
age2_0307_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-07")])


age2_0308_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-08")])
age2_0308_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-08")])

age2_0309_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-09")])
age2_0309_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-09")])

age2_0310_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-10")])
age2_0310_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-10")])

age2_0311_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-11")])
age2_0311_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-11")])

age2_0312_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-12")])
age2_0312_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-12")])

age2_0313_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-13")])
age2_0313_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-13")])

age2_0314_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-14")])
age2_0314_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-14")])

age2_0315_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-15")])
age2_0315_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-15")])

age2_0316_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-16")])
age2_0316_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-16")])

age2_0317_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-17")])
age2_0317_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-17")])

age2_0318_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-18")])
age2_0318_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-18")])

age2_0319_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-19")])
age2_0319_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-19")])

age2_0320_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-20")])
age2_0320_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-20")])

age2_0321_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-21")])
age2_0321_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-21")])

age2_0322_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-22")])
age2_0322_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-22")])

age2_0323_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-23")])
age2_0323_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-23")])

age2_0324_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-24")])
age2_0324_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-24")])

age2_0325_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-25")])
age2_0325_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-25")])

age2_0326_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-26")])
age2_0326_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-26")])

age2_0327_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-27")])
age2_0327_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-27")])

age2_0328_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-28")])
age2_0328_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-28")])

age2_0329_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-29")])
age2_0329_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-29")])

age2_0330_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-30")])
age2_0330_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-30")])

age2_0331_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-31")])
age2_0331_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-03-31")])




age2_0501_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-01")])
age2_0501_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-01")])

age2_0502_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-02")])
age2_0502_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-02")])

age2_0503_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-03")])
age2_0503_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-03")])

age2_0504_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-04")])
age2_0504_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-04")])

age2_0505_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-05")])
age2_0505_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-05")])

age2_0506_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-06")])
age2_0506_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-06")])

age2_0507_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-07")])
age2_0507_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-07")])

age2_0508_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-08")])
age2_0508_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-08")])

age2_0509_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-09")])
age2_0509_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-09")])

age2_0510_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-10")])
age2_0510_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-10")])

age2_0511_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-11")])
age2_0511_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-11")])

age2_0512_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-12")])
age2_0512_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-12")])

age2_0513_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-13")])
age2_0513_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-13")])

age2_0514_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-14")])
age2_0514_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-14")])

age2_0515_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-15")])
age2_0515_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-15")])

age2_0516_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-16")])
age2_0516_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-16")])

age2_0517_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-17")])
age2_0517_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-17")])

age2_0518_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-18")])
age2_0518_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-18")])

age2_0519_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-19")])
age2_0519_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-19")])

age2_0520_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-20")])
age2_0520_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-20")])

age2_0521_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-21")])
age2_0521_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-21")])

age2_0522_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-22")])
age2_0522_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-22")])

age2_0523_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-23")])
age2_0523_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-23")])

age2_0524_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-24")])
age2_0524_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-24")])

age2_0525_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-25")])
age2_0525_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-25")])

age2_0526_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-26")])
age2_0526_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-26")])

age2_0527_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-27")])
age2_0527_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-27")])

age2_0528_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-28")])
age2_0528_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-28")])

age2_0529_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-29")])
age2_0529_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-29")])

age2_0530_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-30")])
age2_0530_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-30")])

age2_0531_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-31")])
age2_0531_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-05-31")])

age2_0601_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-01")])
age2_0601_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-01")])
age2_0602_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-02")])
age2_0602_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-02")])
age2_0603_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-03")])
age2_0603_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-03")])
age2_0604_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-04")])
age2_0604_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-04")])
age2_0605_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-05")])
age2_0605_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-05")])
age2_0606_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-06")])
age2_0606_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-06")])
age2_0607_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-07")])
age2_0607_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-07")])
age2_0608_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-08")])
age2_0608_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-08")])
age2_0609_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-09")])
age2_0609_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-09")])
age2_0610_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-10")])
age2_0610_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-10")])
age2_0611_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-11")])
age2_0611_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-11")])
age2_0612_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-12")])
age2_0612_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-12")])
age2_0613_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-13")])
age2_0613_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-13")])
age2_0614_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-14")])
age2_0614_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-14")])
age2_0615_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-15")])
age2_0615_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-15")])
age2_0616_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-16")])
age2_0616_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-16")])
age2_0617_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-17")])
age2_0617_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-17")])
age2_0618_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-18")])
age2_0618_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-18")])
age2_0619_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-19")])
age2_0619_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-19")])
age2_0620_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-20")])
age2_0620_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-20")])
age2_0621_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-21")])
age2_0621_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-21")])
age2_0622_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-22")])
age2_0622_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-22")])
age2_0623_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-23")])
age2_0623_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-23")])
age2_0624_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-24")])
age2_0624_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-24")])
age2_0625_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-25")])
age2_0625_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-06-25")])



age1_0401_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-01")])
age1_0401_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-01")])
age1_0402_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-02")])
age1_0402_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-02")])
age1_0403_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-03")])
age1_0403_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-03")])
age1_0404_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-04")])
age1_0404_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-04")])
age1_0405_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-05")])
age1_0405_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-05")])
age1_0406_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-06")])
age1_0406_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-06")])
age1_0407_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-07")])
age1_0407_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-07")])
age1_0408_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-08")])
age1_0408_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-08")])
age1_0409_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-09")])
age1_0409_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-09")])
age1_0410_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-10")])
age1_0410_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-10")])
age1_0411_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-11")])
age1_0411_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-11")])
age1_0412_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-12")])
age1_0412_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-12")])
age1_0413_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-13")])
age1_0413_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-13")])
age1_0414_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-14")])
age1_0414_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-14")])
age1_0415_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-15")])
age1_0415_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-15")])
age1_0416_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-16")])
age1_0416_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-16")])
age1_0417_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-17")])
age1_0417_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-17")])
age1_0418_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-18")])
age1_0418_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-18")])
age1_0419_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-19")])
age1_0419_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-19")])
age1_0420_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-20")])
age1_0420_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-20")])
age1_0421_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-21")])
age1_0421_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-21")])
age1_0422_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-22")])
age1_0422_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-22")])
age1_0423_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-23")])
age1_0423_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-23")])
age1_0424_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-24")])
age1_0424_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-24")])
age1_0425_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-25")])
age1_0425_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-25")])
age1_0426_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-26")])
age1_0426_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-26")])
age1_0427_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-27")])
age1_0427_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-27")])
age1_0428_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-28")])
age1_0428_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-28")])
age1_0429_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-29")])
age1_0429_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-29")])

age1_0430_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-30")])
age1_0430_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==1  & data.filtrage$jour=="2021-01-30")])



age2_0401_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-01")])
age2_0401_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-01")])
age2_0402_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-02")])
age2_0402_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-02")])
age2_0403_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-03")])
age2_0403_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-03")])
age2_0404_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-04")])
age2_0404_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-04")])
age2_0405_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-05")])
age2_0405_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-05")])
age2_0406_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-06")])
age2_0406_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-06")])
age2_0407_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-07")])
age2_0407_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-07")])
age2_0408_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-08")])
age2_0408_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-08")])
age2_0409_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-09")])
age2_0409_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-09")])
age2_0410_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-10")])
age2_0410_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-10")])
age2_0411_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-11")])
age2_0411_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-11")])
age2_0412_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-12")])
age2_0412_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-12")])
age2_0413_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-13")])
age2_0413_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-13")])
age2_0414_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-14")])
age2_0414_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-14")])
age2_0415_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-15")])
age2_0415_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-15")])
age2_0416_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-16")])
age2_0416_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-16")])
age2_0417_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-17")])
age2_0417_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-17")])
age2_0418_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-18")])
age2_0418_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-18")])
age2_0419_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-19")])
age2_0419_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-19")])
age2_0420_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-20")])
age2_0420_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-20")])
age2_0421_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-21")])
age2_0421_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-21")])
age2_0422_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-22")])
age2_0422_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-22")])
age2_0423_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-23")])
age2_0423_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-23")])
age2_0424_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-24")])
age2_0424_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-24")])
age2_0425_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-25")])
age2_0425_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-25")])
age2_0426_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-26")])
age2_0426_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-26")])
age2_0427_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-27")])
age2_0427_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-27")])
age2_0428_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-28")])
age2_0428_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-28")])
age2_0429_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-29")])
age2_0429_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-29")])

age2_0430_p<-sum(data.filtrage$P[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-30")])
age2_0430_t<-sum(data.filtrage$T[which(data.filtrage$cl_age90==2  & data.filtrage$jour=="2021-01-30")])



#######
######jours->semaine######
######


######semaine_region_age

age01_1<-((age1_0104_p+age1_0105_p+age1_0106_p+age1_0107_p+age1_0108_p+age1_0109_p+age1_0110_p)/7)/((age1_0104_t+age1_0105_t+age1_0106_t+age1_0107_t+age1_0108_t+age1_0109_t+age1_0110_t)/7)

age02_1<-((age1_0111_p+age1_0112_p+age1_0113_p+age1_0114_p+age1_0115_p+age1_0116_p+age1_0117_p)/7)/((age1_0111_t+age1_0112_t+age1_0113_t+age1_0114_t+age1_0115_t+age1_0116_t+age1_0117_t)/7)

age03_1<-((age1_0118_p+age1_0119_p+age1_0120_p+age1_0121_p+age1_0122_p+age1_0123_p+age1_0124_p)/7)/((age1_0118_t+age1_0119_t+age1_0120_t+age1_0121_t+age1_0122_t+age1_0123_t+age1_0124_t)/7)

age04_1<-((age1_0125_p+age1_0126_p+age1_0127_p+age1_0128_p+age1_0129_p+age1_0130_p+age1_0131_p)/7)/((age1_0125_t+age1_0126_t+age1_0127_t+age1_0128_t+age1_0129_t+age1_0130_t+age1_0131_t)/7)

age05_1<-((age1_0201_p+age1_0202_p+age1_0203_p+age1_0204_p+age1_0205_p+age1_0206_p+age1_0207_p)/7)/((age1_0201_t+age1_0202_t+age1_0203_t+age1_0204_t+age1_0205_t+age1_0206_t+age1_0207_t)/7)

age06_1<-((age1_0208_p+age1_0209_p+age1_0210_p+age1_0211_p+age1_0212_p+age1_0213_p+age1_0214_p)/7)/((age1_0208_t+age1_0209_t+age1_0210_t+age1_0211_t+age1_0212_t+age1_0213_t+age1_0214_t)/7)

age07_1<-((age1_0215_p+age1_0216_p+age1_0217_p+age1_0218_p+age1_0219_p+age1_0220_p+age1_0221_p)/7)/((age1_0215_t+age1_0216_t+age1_0217_t+age1_0218_t+age1_0219_t+age1_0220_t+age1_0221_t)/7)

age08_1<-((age1_0222_p+age1_0223_p+age1_0224_p+age1_0225_p+age1_0226_p+age1_0227_p+age1_0228_p)/7)/((age1_0222_t+age1_0223_t+age1_0224_t+age1_0225_t+age1_0226_t+age1_0227_t+age1_0228_t)/7)

age09_1<-((age1_0301_p+age1_0302_p+age1_0303_p+age1_0304_p+age1_0305_p+age1_0306_p+age1_0307_p)/7)/(( age1_0301_t+age1_0302_t+age1_0303_t+age1_0304_t+age1_0305_t+age1_0306_t+age1_0307_t)/7)

age10_1<-((age1_0308_p+age1_0309_p+age1_0310_p+age1_0311_p+age1_0312_p+age1_0313_p+age1_0314_p)/7)/(( age1_0308_t+age1_0309_t+age1_0310_t+age1_0311_t+age1_0312_t+age1_0313_t+age1_0314_t)/7)

age11_1<-((age1_0315_p+age1_0316_p+age1_0317_p+age1_0318_p+age1_0319_p+age1_0320_p+age1_0321_p)/7)/(( age1_0315_t+age1_0316_t+age1_0317_t+age1_0318_t+age1_0319_t+age1_0320_t+age1_0321_t)/7)

age12_1<-((age1_0322_p+age1_0323_p+age1_0324_p+age1_0325_p+age1_0326_p+age1_0327_p+age1_0328_p)/7)/(( age1_0322_t+age1_0323_t+age1_0324_t+age1_0325_t+age1_0326_t+age1_0327_t+age1_0328_t)/7)

age13_1<-((age1_0329_p+age1_0330_p+age1_0331_p+age1_0401_p+age1_0402_p+age1_0403_p+age1_0404_p)/7)/(( age1_0329_t+age1_0330_t+age1_0331_t+age1_0401_t+age1_0402_t+age1_0403_t+age1_0404_t)/7)

age14_1<-((age1_0405_p+age1_0406_p+age1_0407_p+age1_0408_p+age1_0409_p+age1_0410_p+age1_0411_p)/7)/(( age1_0405_t+age1_0406_t+age1_0407_t+age1_0408_t+age1_0409_t+age1_0410_t+age1_0411_t)/7)

age15_1<-((age1_0412_p+age1_0413_p+age1_0414_p+age1_0415_p+age1_0416_p+age1_0417_p+age1_0418_p)/7)/(( age1_0412_t+age1_0413_t+age1_0414_t+age1_0415_t+age1_0416_t+age1_0417_t+age1_0418_t)/7)

age16_1<-((age1_0419_p+age1_0420_p+age1_0421_p+age1_0422_p+age1_0423_p+age1_0424_p+age1_0425_p)/7)/(( age1_0419_t+age1_0420_t+age1_0421_t+age1_0422_t+age1_0423_t+age1_0424_t+age1_0425_t)/7)

age17_1<-((age1_0426_p+age1_0427_p+age1_0428_p+age1_0429_p+age1_0430_p+age1_0501_p+age1_0502_p)/7)/((age1_0426_t+age1_0427_t+age1_0428_t+age1_0429_t+age1_0430_t+age1_0501_t+age1_0502_t)/7)

age18_1<-((age1_0503_p+age1_0504_p+age1_0505_p+age1_0506_p+age1_0507_p+age1_0508_p+age1_0509_p)/7)/((age1_0503_t+age1_0504_t+age1_0505_t+age1_0506_t+age1_0507_t+age1_0508_t+age1_0509_t)/7)

age19_1<-((age1_0510_p+age1_0511_p+age1_0512_p+age1_0513_p+age1_0514_p+age1_0515_p+age1_0516_p)/7)/((age1_0510_t+age1_0511_t+age1_0512_t+age1_0513_t+age1_0514_t+age1_0515_t+age1_0516_t)/7)

age20_1<-((age1_0517_p+age1_0518_p+age1_0519_p+age1_0520_p+age1_0521_p+age1_0522_p+age1_0523_p)/7)/((age1_0517_t+age1_0518_t+age1_0519_t+age1_0520_t+age1_0521_t+age1_0522_t+age1_0523_t)/7)

age21_1<-((age1_0524_p+age1_0525_p+age1_0526_p+age1_0527_p+age1_0528_p+age1_0529_p+age1_0530_p)/7)/((age1_0524_t+age1_0525_t+age1_0526_t+age1_0527_t+age1_0528_t+age1_0529_t+age1_0530_t)/7)

age22_1<-((age1_0531_p+age1_0601_p+age1_0602_p+age1_0603_p+age1_0604_p+age1_0605_p+age1_0606_p)/7)/((age1_0531_t+age1_0601_t+age1_0602_t+age1_0603_t+age1_0604_t+age1_0605_t+age1_0606_t)/7)

age23_1<-((age1_0607_p+age1_0608_p+age1_0609_p+age1_0610_p+age1_0611_p+age1_0612_p+age1_0613_p)/7)/((age1_0607_t+age1_0608_t+age1_0609_t+age1_0610_t+age1_0611_t+age1_0612_t+age1_0613_t)/7)

age24_1<-((age1_0614_p+age1_0615_p+age1_0616_p+age1_0617_p+age1_0618_p+age1_0619_p+age1_0620_p)/7)/((age1_0614_t+age1_0615_t+age1_0616_t+age1_0617_t+age1_0618_t+age1_0619_t+age1_0620_t)/7)



age01_2<-((age2_0104_p+age2_0105_p+age2_0106_p+age2_0107_p+age2_0108_p+age2_0109_p+age2_0110_p)/7)/((age2_0104_t+age2_0105_t+age2_0106_t+age2_0107_t+age2_0108_t+age2_0109_t+age2_0110_t)/7)

age02_2<-((age2_0111_p+age2_0112_p+age2_0113_p+age2_0114_p+age2_0115_p+age2_0116_p+age2_0117_p)/7)/((age2_0111_t+age2_0112_t+age2_0113_t+age2_0114_t+age2_0115_t+age2_0116_t+age2_0117_t)/7)

age03_2<-((age2_0118_p+age2_0119_p+age2_0120_p+age2_0121_p+age2_0122_p+age2_0123_p+age2_0124_p)/7)/((age2_0118_t+age2_0119_t+age2_0120_t+age2_0121_t+age2_0122_t+age2_0123_t+age2_0124_t)/7)

age04_2<-((age2_0125_p+age2_0126_p+age2_0127_p+age2_0128_p+age2_0129_p+age2_0130_p+age2_0131_p)/7)/((age2_0125_t+age2_0126_t+age2_0127_t+age2_0128_t+age2_0129_t+age2_0130_t+age2_0131_t)/7)

age05_2<-((age2_0201_p+age2_0202_p+age2_0203_p+age2_0204_p+age2_0205_p+age2_0206_p+age2_0207_p)/7)/((age2_0201_t+age2_0202_t+age2_0203_t+age2_0204_t+age2_0205_t+age2_0206_t+age2_0207_t)/7)

age06_2<-((age2_0208_p+age2_0209_p+age2_0210_p+age2_0211_p+age2_0212_p+age2_0213_p+age2_0214_p)/7)/((age2_0208_t+age2_0209_t+age2_0210_t+age2_0211_t+age2_0212_t+age2_0213_t+age2_0214_t)/7)

age07_2<-((age2_0215_p+age2_0216_p+age2_0217_p+age2_0218_p+age2_0219_p+age2_0220_p+age2_0221_p)/7)/((age2_0215_t+age2_0216_t+age2_0217_t+age2_0218_t+age2_0219_t+age2_0220_t+age2_0221_t)/7)

age08_2<-((age2_0222_p+age2_0223_p+age2_0224_p+age2_0225_p+age2_0226_p+age2_0227_p+age2_0228_p)/7)/((age2_0222_t+age2_0223_t+age2_0224_t+age2_0225_t+age2_0226_t+age2_0227_t+age2_0228_t)/7)

age09_2<-((age2_0301_p+age2_0302_p+age2_0303_p+age2_0304_p+age2_0305_p+age2_0306_p+age2_0307_p)/7)/(( age2_0301_t+age2_0302_t+age2_0303_t+age2_0304_t+age2_0305_t+age2_0306_t+age2_0307_t)/7)

age10_2<-((age2_0308_p+age2_0309_p+age2_0310_p+age2_0311_p+age2_0312_p+age2_0313_p+age2_0314_p)/7)/(( age2_0308_t+age2_0309_t+age2_0310_t+age2_0311_t+age2_0312_t+age2_0313_t+age2_0314_t)/7)

age11_2<-((age2_0315_p+age2_0316_p+age2_0317_p+age2_0318_p+age2_0319_p+age2_0320_p+age2_0321_p)/7)/(( age2_0315_t+age2_0316_t+age2_0317_t+age2_0318_t+age2_0319_t+age2_0320_t+age2_0321_t)/7)

age12_2<-((age2_0322_p+age2_0323_p+age2_0324_p+age2_0325_p+age2_0326_p+age2_0327_p+age2_0328_p)/7)/(( age2_0322_t+age2_0323_t+age2_0324_t+age2_0325_t+age2_0326_t+age2_0327_t+age2_0328_t)/7)

age13_2<-((age2_0329_p+age2_0330_p+age2_0331_p+age2_0401_p+age2_0402_p+age2_0403_p+age2_0404_p)/7)/(( age2_0329_t+age2_0330_t+age2_0331_t+age2_0401_t+age2_0402_t+age2_0403_t+age2_0404_t)/7)

age14_2<-((age2_0405_p+age2_0406_p+age2_0407_p+age2_0408_p+age2_0409_p+age2_0410_p+age2_0411_p)/7)/(( age2_0405_t+age2_0406_t+age2_0407_t+age2_0408_t+age2_0409_t+age2_0410_t+age2_0411_t)/7)

age15_2<-((age2_0412_p+age2_0413_p+age2_0414_p+age2_0415_p+age2_0416_p+age2_0417_p+age2_0418_p)/7)/(( age2_0412_t+age2_0413_t+age2_0414_t+age2_0415_t+age2_0416_t+age2_0417_t+age2_0418_t)/7)

age16_2<-((age2_0419_p+age2_0420_p+age2_0421_p+age2_0422_p+age2_0423_p+age2_0424_p+age2_0425_p)/7)/(( age2_0419_t+age2_0420_t+age2_0421_t+age2_0422_t+age2_0423_t+age2_0424_t+age2_0425_t)/7)

age17_2<-((age2_0426_p+age2_0427_p+age2_0428_p+age2_0429_p+age2_0430_p+age2_0501_p+age2_0502_p)/7)/((age2_0426_t+age2_0427_t+age2_0428_t+age2_0429_t+age2_0430_t+age2_0501_t+age2_0502_t)/7)

age18_2<-((age2_0503_p+age2_0504_p+age2_0505_p+age2_0506_p+age2_0507_p+age2_0508_p+age2_0509_p)/7)/((age2_0503_t+age2_0504_t+age2_0505_t+age2_0506_t+age2_0507_t+age2_0508_t+age2_0509_t)/7)

age19_2<-((age2_0510_p+age2_0511_p+age2_0512_p+age2_0513_p+age2_0514_p+age2_0515_p+age2_0516_p)/7)/((age2_0510_t+age2_0511_t+age2_0512_t+age2_0513_t+age2_0514_t+age2_0515_t+age2_0516_t)/7)

age20_2<-((age2_0517_p+age2_0518_p+age2_0519_p+age2_0520_p+age2_0521_p+age2_0522_p+age2_0523_p)/7)/((age2_0517_t+age2_0518_t+age2_0519_t+age2_0520_t+age2_0521_t+age2_0522_t+age2_0523_t)/7)

age21_2<-((age2_0524_p+age2_0525_p+age2_0526_p+age2_0527_p+age2_0528_p+age2_0529_p+age2_0530_p)/7)/((age2_0524_t+age2_0525_t+age2_0526_t+age2_0527_t+age2_0528_t+age2_0529_t+age2_0530_t)/7)

age22_2<-((age2_0531_p+age2_0601_p+age2_0602_p+age2_0603_p+age2_0604_p+age2_0605_p+age2_0606_p)/7)/((age2_0531_t+age2_0601_t+age2_0602_t+age2_0603_t+age2_0604_t+age2_0605_t+age2_0606_t)/7)

age23_2<-((age2_0607_p+age2_0608_p+age2_0609_p+age2_0610_p+age2_0611_p+age2_0612_p+age2_0613_p)/7)/((age2_0607_t+age2_0608_t+age2_0609_t+age2_0610_t+age2_0611_t+age2_0612_t+age2_0613_t)/7)

age24_2<-((age2_0614_p+age2_0615_p+age2_0616_p+age2_0617_p+age2_0618_p+age2_0619_p+age2_0620_p)/7)/((age2_0614_t+age2_0615_t+age2_0616_t+age2_0617_t+age2_0618_t+age2_0619_t+age2_0620_t)/7)


age1<-c(age01_1,age02_1,age03_1,age04_1,age05_1,age06_1,age07_1,age08_1,age09_1,age10_1,age11_1,age12_1,age13_1,age14_1,age15_1,age16_1,age17_1,age18_1,age19_1,age20_1,age21_1,age22_1,age23_1,age24_1)

age2<-c(age01_2,age02_2,age03_2,age04_2,age05_2,age06_2,age07_2,age08_2,age09_2,age10_2,age11_2,age12_2,age13_2,age14_2,age15_2,age16_2,age17_2,age18_2,age19_2,age20_2,age21_2,age22_2,age23_2,age24_2)


age1=100*age1
age2=100*age2






covid<-data.frame(age1,age2)
write.csv(covid,file="~/M1/TER/age_infection.csv")


