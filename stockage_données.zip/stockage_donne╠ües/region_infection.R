rm(list=objects())
graphics.off()
setwd("~/M1/TER")
data.original.infection=read.csv("sp-pos-quot-reg-2021-06-20-19h08.csv",sep=";")


#découpage de date
#on extrait jeu de données de 2021-01-01 à 2021-06-15
data.filtrage.infection=data.original.infection[which(data.original.infection$jour=="2021-01-01"):which(data.original.infection$jour=="2021-06-16"),]



#classment region
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="7")]<-1 
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="6")]<-1



data.filtrage.infection$reg[which(data.filtrage.infection$reg=="75")]<-9
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="76")]<-7


data.filtrage.infection$reg[which(data.filtrage.infection$reg=="4")]<-2
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="84")]<-5
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="93")]<-6
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="94")]<-9


data.filtrage.infection$reg[which(data.filtrage.infection$reg=="27")]<-8
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="44")]<-4



data.filtrage.infection$reg[which(data.filtrage.infection$reg=="24")]<-8
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="28")]<-2
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="32")]<-3 
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="52")]<-1 
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="53")]<-9 
data.filtrage.infection$reg[which(data.filtrage.infection$reg=="32")]<-3







data.filtrage<-data.filtrage.infection[,c("reg","jour","P","T","cl_age90")]




data.filtrage[is.na(data.filtrage)] <- 0


############
####regroupement de variables
############



######région 1
##

reg1_0102_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-02")])
reg1_0102_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-02")])
reg1_0103_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-03")])
reg1_0103_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-03")])
reg1_0104_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-04")])
reg1_0104_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-04")])
reg1_0105_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-05")])
reg1_0105_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-05")])
reg1_0106_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-06")])
reg1_0106_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-06")])
reg1_0107_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-07")])
reg1_0107_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-07")])
reg1_0108_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-08")])
reg1_0108_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-08")])
reg1_0109_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-09")])
reg1_0109_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-09")])
reg1_0110_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-10")])
reg1_0110_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-10")])
reg1_0111_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-11")])
reg1_0111_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-11")])
reg1_0112_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-12")])
reg1_0112_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-12")])
reg1_0113_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-13")])
reg1_0113_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-13")])
reg1_0114_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-14")])
reg1_0114_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-14")])
reg1_0115_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-15")])
reg1_0115_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-15")])
reg1_0116_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-16")])
reg1_0116_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-16")])
reg1_0117_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-17")])
reg1_0117_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-17")])
reg1_0118_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-18")])
reg1_0118_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-18")])
reg1_0119_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-19")])
reg1_0119_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-19")])
reg1_0120_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-20")])
reg1_0120_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-20")])
reg1_0121_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-21")])
reg1_0121_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-21")])
reg1_0122_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-22")])
reg1_0122_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-22")])
reg1_0123_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-23")])
reg1_0123_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-23")])
reg1_0124_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-24")])
reg1_0124_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-24")])
reg1_0125_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-25")])
reg1_0125_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-25")])
reg1_0126_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-26")])
reg1_0126_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-26")])
reg1_0127_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-27")])
reg1_0127_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-27")])
reg1_0128_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-28")])
reg1_0128_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-28")])
reg1_0129_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-29")])
reg1_0129_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-29")])

reg1_0130_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-30")])
reg1_0130_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-30")])
reg1_0131_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-31")])
reg1_0131_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-31")])




reg1_0201_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-01")])
reg1_0201_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-01")])
reg1_0202_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-02")])
reg1_0202_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-02")])
reg1_0203_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-03")])
reg1_0203_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-03")])
reg1_0204_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-04")])
reg1_0204_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-04")])
reg1_0205_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-05")])
reg1_0205_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-05")])
reg1_0206_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-06")])
reg1_0206_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-06")])
reg1_0207_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-07")])
reg1_0207_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-07")])
reg1_0208_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-08")])
reg1_0208_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-08")])
reg1_0209_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-09")])
reg1_0209_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-09")])
reg1_0210_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-10")])
reg1_0210_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-10")])
reg1_0211_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-11")])
reg1_0211_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-11")])
reg1_0212_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-12")])
reg1_0212_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-12")])
reg1_0213_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-13")])
reg1_0213_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-13")])
reg1_0214_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-14")])
reg1_0214_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-14")])
reg1_0215_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-15")])
reg1_0215_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-15")])
reg1_0216_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-16")])
reg1_0216_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-16")])
reg1_0217_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-17")])
reg1_0217_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-17")])
reg1_0218_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-18")])
reg1_0218_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-18")])
reg1_0219_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-19")])
reg1_0219_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-19")])
reg1_0220_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-20")])
reg1_0220_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-20")])
reg1_0221_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-21")])
reg1_0221_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-21")])
reg1_0222_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-22")])
reg1_0222_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-22")])
reg1_0223_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-23")])
reg1_0223_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-23")])
reg1_0224_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-24")])
reg1_0224_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-24")])
reg1_0225_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-25")])
reg1_0225_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-25")])
reg1_0226_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-26")])
reg1_0226_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-26")])
reg1_0227_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-27")])
reg1_0227_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-27")])
reg1_0228_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-28")])
reg1_0228_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-02-28")])

reg1_0301_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-01")])
reg1_0301_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-01")])

reg1_0302_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-02")])
reg1_0302_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-02")])

reg1_0303_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-03")])
reg1_0303_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-03")])

reg1_0304_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-04")])
reg1_0304_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-04")])

reg1_0305_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-05")])
reg1_0305_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-05")])

reg1_0306_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-06")])
reg1_0306_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-06")])

reg1_0307_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-07")])
reg1_0307_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-07")])


reg1_0308_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-08")])
reg1_0308_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-08")])

reg1_0309_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-09")])
reg1_0309_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-09")])

reg1_0310_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-10")])
reg1_0310_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-10")])

reg1_0311_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-11")])
reg1_0311_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-11")])

reg1_0312_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-12")])
reg1_0312_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-12")])

reg1_0313_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-13")])
reg1_0313_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-13")])

reg1_0314_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-14")])
reg1_0314_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-14")])

reg1_0315_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-15")])
reg1_0315_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-15")])

reg1_0316_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-16")])
reg1_0316_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-16")])

reg1_0317_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-17")])
reg1_0317_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-17")])

reg1_0318_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-18")])
reg1_0318_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-18")])

reg1_0319_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-19")])
reg1_0319_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-19")])

reg1_0320_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-20")])
reg1_0320_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-20")])

reg1_0321_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-21")])
reg1_0321_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-21")])

reg1_0322_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-22")])
reg1_0322_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-22")])

reg1_0323_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-23")])
reg1_0323_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-23")])

reg1_0324_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-24")])
reg1_0324_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-24")])

reg1_0325_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-25")])
reg1_0325_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-25")])

reg1_0326_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-26")])
reg1_0326_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-26")])

reg1_0327_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-27")])
reg1_0327_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-27")])

reg1_0328_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-28")])
reg1_0328_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-28")])

reg1_0329_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-29")])
reg1_0329_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-29")])

reg1_0330_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-30")])
reg1_0330_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-30")])

reg1_0331_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-31")])
reg1_0331_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-03-31")])

reg1_0401_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-01")])
reg1_0401_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-01")])
reg1_0402_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-02")])
reg1_0402_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-02")])
reg1_0403_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-03")])
reg1_0403_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-03")])
reg1_0404_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-04")])
reg1_0404_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-04")])
reg1_0405_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-05")])
reg1_0405_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-05")])
reg1_0406_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-06")])
reg1_0406_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-06")])
reg1_0407_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-07")])
reg1_0407_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-07")])
reg1_0408_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-08")])
reg1_0408_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-08")])
reg1_0409_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-09")])
reg1_0409_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-09")])
reg1_0410_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-10")])
reg1_0410_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-10")])
reg1_0411_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-11")])
reg1_0411_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-11")])
reg1_0412_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-12")])
reg1_0412_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-12")])
reg1_0413_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-13")])
reg1_0413_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-13")])
reg1_0414_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-14")])
reg1_0414_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-14")])
reg1_0415_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-15")])
reg1_0415_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-15")])
reg1_0416_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-16")])
reg1_0416_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-16")])
reg1_0417_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-17")])
reg1_0417_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-17")])
reg1_0418_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-18")])
reg1_0418_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-18")])
reg1_0419_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-19")])
reg1_0419_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-19")])
reg1_0420_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-20")])
reg1_0420_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-20")])
reg1_0421_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-21")])
reg1_0421_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-21")])
reg1_0422_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-22")])
reg1_0422_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-22")])
reg1_0423_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-23")])
reg1_0423_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-23")])
reg1_0424_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-24")])
reg1_0424_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-24")])
reg1_0425_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-25")])
reg1_0425_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-25")])
reg1_0426_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-26")])
reg1_0426_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-26")])
reg1_0427_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-27")])
reg1_0427_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-27")])
reg1_0428_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-28")])
reg1_0428_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-28")])
reg1_0429_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-29")])
reg1_0429_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-29")])
reg1_0430_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-30")])
reg1_0430_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-01-30")])


reg1_0501_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-01")])
reg1_0501_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-01")])

reg1_0502_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-02")])
reg1_0502_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-02")])

reg1_0503_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-03")])
reg1_0503_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-03")])

reg1_0504_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-04")])
reg1_0504_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-04")])

reg1_0505_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-05")])
reg1_0505_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-05")])

reg1_0506_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-06")])
reg1_0506_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-06")])

reg1_0507_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-07")])
reg1_0507_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-07")])

reg1_0508_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-08")])
reg1_0508_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-08")])

reg1_0509_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-09")])
reg1_0509_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-09")])

reg1_0510_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-10")])
reg1_0510_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-10")])

reg1_0511_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-11")])
reg1_0511_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-11")])

reg1_0512_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-12")])
reg1_0512_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-12")])

reg1_0513_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-13")])
reg1_0513_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-13")])

reg1_0514_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-14")])
reg1_0514_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-14")])

reg1_0515_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-15")])
reg1_0515_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-15")])

reg1_0516_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-16")])
reg1_0516_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-16")])

reg1_0517_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-17")])
reg1_0517_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-17")])

reg1_0518_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-18")])
reg1_0518_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-18")])

reg1_0519_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-19")])
reg1_0519_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-19")])

reg1_0520_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-20")])
reg1_0520_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-20")])

reg1_0521_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-21")])
reg1_0521_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-21")])

reg1_0522_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-22")])
reg1_0522_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-22")])

reg1_0523_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-23")])
reg1_0523_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-23")])

reg1_0524_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-24")])
reg1_0524_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-24")])

reg1_0525_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-25")])
reg1_0525_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-25")])

reg1_0526_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-26")])
reg1_0526_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-26")])

reg1_0527_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-27")])
reg1_0527_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-27")])

reg1_0528_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-28")])
reg1_0528_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-28")])

reg1_0529_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-29")])
reg1_0529_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-29")])

reg1_0530_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-30")])
reg1_0530_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-30")])

reg1_0531_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-31")])
reg1_0531_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-05-31")])

reg1_0601_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-01")])
reg1_0601_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-01")])
reg1_0602_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-02")])
reg1_0602_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-02")])
reg1_0603_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-03")])
reg1_0603_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-03")])
reg1_0604_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-04")])
reg1_0604_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-04")])
reg1_0605_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-05")])
reg1_0605_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-05")])
reg1_0606_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-06")])
reg1_0606_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-06")])
reg1_0607_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-07")])
reg1_0607_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-07")])
reg1_0608_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-08")])
reg1_0608_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-08")])
reg1_0609_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-09")])
reg1_0609_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-09")])
reg1_0610_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-10")])
reg1_0610_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-10")])
reg1_0611_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-11")])
reg1_0611_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-11")])
reg1_0612_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-12")])
reg1_0612_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-12")])
reg1_0613_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-13")])
reg1_0613_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-13")])
reg1_0614_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-14")])
reg1_0614_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-14")])
reg1_0615_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-15")])
reg1_0615_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-15")])
reg1_0616_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-16")])
reg1_0616_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-16")])
reg1_0617_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-17")])
reg1_0617_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-17")])
reg1_0618_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-18")])
reg1_0618_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-18")])
reg1_0619_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-19")])
reg1_0619_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-19")])
reg1_0620_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-20")])
reg1_0620_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-20")])
reg1_0621_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-21")])
reg1_0621_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-21")])
reg1_0622_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-22")])
reg1_0622_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-22")])
reg1_0623_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-23")])
reg1_0623_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-23")])
reg1_0624_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-24")])
reg1_0624_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-24")])
reg1_0625_p<-sum(data.filtrage$P[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-25")])
reg1_0625_t<-sum(data.filtrage$T[which( data.filtrage$reg==1 & data.filtrage$jour=="2021-06-25")])

reg2_0102_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-02")])
reg2_0102_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-02")])
reg2_0103_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-03")])
reg2_0103_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-03")])
reg2_0104_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-04")])
reg2_0104_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-04")])
reg2_0105_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-05")])
reg2_0105_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-05")])
reg2_0106_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-06")])
reg2_0106_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-06")])
reg2_0107_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-07")])
reg2_0107_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-07")])
reg2_0108_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-08")])
reg2_0108_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-08")])
reg2_0109_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-09")])
reg2_0109_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-09")])
reg2_0110_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-10")])
reg2_0110_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-10")])
reg2_0111_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-11")])
reg2_0111_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-11")])
reg2_0112_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-12")])
reg2_0112_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-12")])
reg2_0113_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-13")])
reg2_0113_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-13")])
reg2_0114_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-14")])
reg2_0114_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-14")])
reg2_0115_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-15")])
reg2_0115_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-15")])
reg2_0116_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-16")])
reg2_0116_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-16")])
reg2_0117_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-17")])
reg2_0117_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-17")])
reg2_0118_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-18")])
reg2_0118_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-18")])
reg2_0119_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-19")])
reg2_0119_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-19")])
reg2_0120_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-20")])
reg2_0120_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-20")])
reg2_0121_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-21")])
reg2_0121_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-21")])
reg2_0122_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-22")])
reg2_0122_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-22")])
reg2_0123_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-23")])
reg2_0123_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-23")])
reg2_0124_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-24")])
reg2_0124_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-24")])
reg2_0125_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-25")])
reg2_0125_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-25")])
reg2_0126_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-26")])
reg2_0126_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-26")])
reg2_0127_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-27")])
reg2_0127_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-27")])
reg2_0128_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-28")])
reg2_0128_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-28")])
reg2_0129_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-29")])
reg2_0129_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-29")])

reg2_0130_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-30")])
reg2_0130_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-30")])
reg2_0131_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-31")])
reg2_0131_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-31")])




reg2_0201_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-01")])
reg2_0201_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-01")])
reg2_0202_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-02")])
reg2_0202_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-02")])
reg2_0203_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-03")])
reg2_0203_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-03")])
reg2_0204_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-04")])
reg2_0204_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-04")])
reg2_0205_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-05")])
reg2_0205_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-05")])
reg2_0206_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-06")])
reg2_0206_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-06")])
reg2_0207_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-07")])
reg2_0207_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-07")])
reg2_0208_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-08")])
reg2_0208_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-08")])
reg2_0209_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-09")])
reg2_0209_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-09")])
reg2_0210_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-10")])
reg2_0210_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-10")])
reg2_0211_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-11")])
reg2_0211_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-11")])
reg2_0212_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-12")])
reg2_0212_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-12")])
reg2_0213_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-13")])
reg2_0213_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-13")])
reg2_0214_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-14")])
reg2_0214_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-14")])
reg2_0215_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-15")])
reg2_0215_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-15")])
reg2_0216_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-16")])
reg2_0216_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-16")])
reg2_0217_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-17")])
reg2_0217_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-17")])
reg2_0218_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-18")])
reg2_0218_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-18")])
reg2_0219_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-19")])
reg2_0219_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-19")])
reg2_0220_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-20")])
reg2_0220_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-20")])
reg2_0221_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-21")])
reg2_0221_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-21")])
reg2_0222_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-22")])
reg2_0222_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-22")])
reg2_0223_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-23")])
reg2_0223_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-23")])
reg2_0224_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-24")])
reg2_0224_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-24")])
reg2_0225_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-25")])
reg2_0225_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-25")])
reg2_0226_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-26")])
reg2_0226_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-26")])
reg2_0227_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-27")])
reg2_0227_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-27")])
reg2_0228_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-28")])
reg2_0228_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-02-28")])

reg2_0301_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-01")])
reg2_0301_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-01")])

reg2_0302_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-02")])
reg2_0302_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-02")])

reg2_0303_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-03")])
reg2_0303_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-03")])

reg2_0304_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-04")])
reg2_0304_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-04")])

reg2_0305_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-05")])
reg2_0305_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-05")])

reg2_0306_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-06")])
reg2_0306_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-06")])

reg2_0307_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-07")])
reg2_0307_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-07")])


reg2_0308_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-08")])
reg2_0308_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-08")])

reg2_0309_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-09")])
reg2_0309_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-09")])

reg2_0310_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-10")])
reg2_0310_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-10")])

reg2_0311_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-11")])
reg2_0311_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-11")])

reg2_0312_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-12")])
reg2_0312_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-12")])

reg2_0313_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-13")])
reg2_0313_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-13")])

reg2_0314_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-14")])
reg2_0314_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-14")])

reg2_0315_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-15")])
reg2_0315_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-15")])

reg2_0316_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-16")])
reg2_0316_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-16")])

reg2_0317_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-17")])
reg2_0317_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-17")])

reg2_0318_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-18")])
reg2_0318_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-18")])

reg2_0319_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-19")])
reg2_0319_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-19")])

reg2_0320_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-20")])
reg2_0320_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-20")])

reg2_0321_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-21")])
reg2_0321_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-21")])

reg2_0322_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-22")])
reg2_0322_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-22")])

reg2_0323_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-23")])
reg2_0323_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-23")])

reg2_0324_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-24")])
reg2_0324_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-24")])

reg2_0325_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-25")])
reg2_0325_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-25")])

reg2_0326_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-26")])
reg2_0326_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-26")])

reg2_0327_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-27")])
reg2_0327_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-27")])

reg2_0328_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-28")])
reg2_0328_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-28")])

reg2_0329_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-29")])
reg2_0329_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-29")])

reg2_0330_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-30")])
reg2_0330_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-30")])

reg2_0331_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-31")])
reg2_0331_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-03-31")])

reg2_0401_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-01")])
reg2_0401_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-01")])
reg2_0402_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-02")])
reg2_0402_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-02")])
reg2_0403_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-03")])
reg2_0403_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-03")])
reg2_0404_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-04")])
reg2_0404_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-04")])
reg2_0405_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-05")])
reg2_0405_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-05")])
reg2_0406_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-06")])
reg2_0406_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-06")])
reg2_0407_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-07")])
reg2_0407_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-07")])
reg2_0408_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-08")])
reg2_0408_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-08")])
reg2_0409_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-09")])
reg2_0409_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-09")])
reg2_0410_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-10")])
reg2_0410_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-10")])
reg2_0411_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-11")])
reg2_0411_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-11")])
reg2_0412_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-12")])
reg2_0412_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-12")])
reg2_0413_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-13")])
reg2_0413_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-13")])
reg2_0414_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-14")])
reg2_0414_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-14")])
reg2_0415_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-15")])
reg2_0415_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-15")])
reg2_0416_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-16")])
reg2_0416_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-16")])
reg2_0417_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-17")])
reg2_0417_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-17")])
reg2_0418_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-18")])
reg2_0418_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-18")])
reg2_0419_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-19")])
reg2_0419_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-19")])
reg2_0420_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-20")])
reg2_0420_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-20")])
reg2_0421_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-21")])
reg2_0421_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-21")])
reg2_0422_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-22")])
reg2_0422_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-22")])
reg2_0423_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-23")])
reg2_0423_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-23")])
reg2_0424_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-24")])
reg2_0424_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-24")])
reg2_0425_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-25")])
reg2_0425_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-25")])
reg2_0426_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-26")])
reg2_0426_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-26")])
reg2_0427_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-27")])
reg2_0427_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-27")])
reg2_0428_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-28")])
reg2_0428_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-28")])
reg2_0429_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-29")])
reg2_0429_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-29")])
reg2_0430_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-30")])
reg2_0430_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-01-30")])


reg2_0501_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-01")])
reg2_0501_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-01")])

reg2_0502_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-02")])
reg2_0502_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-02")])

reg2_0503_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-03")])
reg2_0503_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-03")])

reg2_0504_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-04")])
reg2_0504_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-04")])

reg2_0505_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-05")])
reg2_0505_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-05")])

reg2_0506_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-06")])
reg2_0506_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-06")])

reg2_0507_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-07")])
reg2_0507_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-07")])

reg2_0508_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-08")])
reg2_0508_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-08")])

reg2_0509_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-09")])
reg2_0509_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-09")])

reg2_0510_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-10")])
reg2_0510_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-10")])

reg2_0511_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-11")])
reg2_0511_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-11")])

reg2_0512_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-12")])
reg2_0512_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-12")])

reg2_0513_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-13")])
reg2_0513_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-13")])

reg2_0514_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-14")])
reg2_0514_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-14")])

reg2_0515_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-15")])
reg2_0515_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-15")])

reg2_0516_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-16")])
reg2_0516_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-16")])

reg2_0517_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-17")])
reg2_0517_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-17")])

reg2_0518_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-18")])
reg2_0518_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-18")])

reg2_0519_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-19")])
reg2_0519_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-19")])

reg2_0520_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-20")])
reg2_0520_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-20")])

reg2_0521_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-21")])
reg2_0521_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-21")])

reg2_0522_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-22")])
reg2_0522_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-22")])

reg2_0523_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-23")])
reg2_0523_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-23")])

reg2_0524_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-24")])
reg2_0524_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-24")])

reg2_0525_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-25")])
reg2_0525_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-25")])

reg2_0526_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-26")])
reg2_0526_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-26")])

reg2_0527_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-27")])
reg2_0527_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-27")])

reg2_0528_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-28")])
reg2_0528_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-28")])

reg2_0529_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-29")])
reg2_0529_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-29")])

reg2_0530_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-30")])
reg2_0530_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-30")])

reg2_0531_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-31")])
reg2_0531_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-05-31")])

reg2_0601_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-01")])
reg2_0601_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-01")])
reg2_0602_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-02")])
reg2_0602_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-02")])
reg2_0603_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-03")])
reg2_0603_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-03")])
reg2_0604_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-04")])
reg2_0604_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-04")])
reg2_0605_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-05")])
reg2_0605_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-05")])
reg2_0606_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-06")])
reg2_0606_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-06")])
reg2_0607_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-07")])
reg2_0607_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-07")])
reg2_0608_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-08")])
reg2_0608_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-08")])
reg2_0609_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-09")])
reg2_0609_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-09")])
reg2_0610_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-10")])
reg2_0610_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-10")])
reg2_0611_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-11")])
reg2_0611_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-11")])
reg2_0612_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-12")])
reg2_0612_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-12")])
reg2_0613_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-13")])
reg2_0613_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-13")])
reg2_0614_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-14")])
reg2_0614_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-14")])
reg2_0615_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-15")])
reg2_0615_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-15")])
reg2_0616_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-16")])
reg2_0616_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-16")])
reg2_0617_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-17")])
reg2_0617_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-17")])
reg2_0618_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-18")])
reg2_0618_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-18")])
reg2_0619_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-19")])
reg2_0619_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-19")])
reg2_0620_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-20")])
reg2_0620_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-20")])
reg2_0621_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-21")])
reg2_0621_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-21")])
reg2_0622_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-22")])
reg2_0622_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-22")])
reg2_0623_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-23")])
reg2_0623_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-23")])
reg2_0624_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-24")])
reg2_0624_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-24")])
reg2_0625_p<-sum(data.filtrage$P[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-25")])
reg2_0625_t<-sum(data.filtrage$T[which( data.filtrage$reg==2 & data.filtrage$jour=="2021-06-25")])


reg3_0102_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-02")])
reg3_0102_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-02")])
reg3_0103_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-03")])
reg3_0103_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-03")])
reg3_0104_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-04")])
reg3_0104_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-04")])
reg3_0105_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-05")])
reg3_0105_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-05")])
reg3_0106_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-06")])
reg3_0106_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-06")])
reg3_0107_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-07")])
reg3_0107_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-07")])
reg3_0108_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-08")])
reg3_0108_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-08")])
reg3_0109_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-09")])
reg3_0109_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-09")])
reg3_0110_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-10")])
reg3_0110_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-10")])
reg3_0111_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-11")])
reg3_0111_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-11")])
reg3_0112_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-12")])
reg3_0112_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-12")])
reg3_0113_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-13")])
reg3_0113_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-13")])
reg3_0114_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-14")])
reg3_0114_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-14")])
reg3_0115_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-15")])
reg3_0115_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-15")])
reg3_0116_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-16")])
reg3_0116_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-16")])
reg3_0117_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-17")])
reg3_0117_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-17")])
reg3_0118_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-18")])
reg3_0118_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-18")])
reg3_0119_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-19")])
reg3_0119_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-19")])
reg3_0120_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-20")])
reg3_0120_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-20")])
reg3_0121_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-21")])
reg3_0121_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-21")])
reg3_0122_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-22")])
reg3_0122_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-22")])
reg3_0123_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-23")])
reg3_0123_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-23")])
reg3_0124_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-24")])
reg3_0124_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-24")])
reg3_0125_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-25")])
reg3_0125_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-25")])
reg3_0126_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-26")])
reg3_0126_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-26")])
reg3_0127_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-27")])
reg3_0127_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-27")])
reg3_0128_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-28")])
reg3_0128_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-28")])
reg3_0129_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-29")])
reg3_0129_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-29")])

reg3_0130_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-30")])
reg3_0130_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-30")])
reg3_0131_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-31")])
reg3_0131_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-31")])




reg3_0201_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-01")])
reg3_0201_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-01")])
reg3_0202_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-02")])
reg3_0202_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-02")])
reg3_0203_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-03")])
reg3_0203_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-03")])
reg3_0204_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-04")])
reg3_0204_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-04")])
reg3_0205_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-05")])
reg3_0205_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-05")])
reg3_0206_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-06")])
reg3_0206_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-06")])
reg3_0207_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-07")])
reg3_0207_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-07")])
reg3_0208_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-08")])
reg3_0208_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-08")])
reg3_0209_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-09")])
reg3_0209_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-09")])
reg3_0210_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-10")])
reg3_0210_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-10")])
reg3_0211_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-11")])
reg3_0211_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-11")])
reg3_0212_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-12")])
reg3_0212_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-12")])
reg3_0213_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-13")])
reg3_0213_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-13")])
reg3_0214_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-14")])
reg3_0214_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-14")])
reg3_0215_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-15")])
reg3_0215_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-15")])
reg3_0216_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-16")])
reg3_0216_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-16")])
reg3_0217_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-17")])
reg3_0217_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-17")])
reg3_0218_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-18")])
reg3_0218_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-18")])
reg3_0219_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-19")])
reg3_0219_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-19")])
reg3_0220_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-20")])
reg3_0220_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-20")])
reg3_0221_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-21")])
reg3_0221_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-21")])
reg3_0222_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-22")])
reg3_0222_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-22")])
reg3_0223_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-23")])
reg3_0223_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-23")])
reg3_0224_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-24")])
reg3_0224_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-24")])
reg3_0225_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-25")])
reg3_0225_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-25")])
reg3_0226_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-26")])
reg3_0226_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-26")])
reg3_0227_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-27")])
reg3_0227_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-27")])
reg3_0228_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-28")])
reg3_0228_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-02-28")])

reg3_0301_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-01")])
reg3_0301_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-01")])

reg3_0302_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-02")])
reg3_0302_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-02")])

reg3_0303_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-03")])
reg3_0303_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-03")])

reg3_0304_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-04")])
reg3_0304_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-04")])

reg3_0305_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-05")])
reg3_0305_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-05")])

reg3_0306_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-06")])
reg3_0306_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-06")])

reg3_0307_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-07")])
reg3_0307_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-07")])


reg3_0308_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-08")])
reg3_0308_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-08")])

reg3_0309_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-09")])
reg3_0309_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-09")])

reg3_0310_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-10")])
reg3_0310_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-10")])

reg3_0311_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-11")])
reg3_0311_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-11")])

reg3_0312_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-12")])
reg3_0312_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-12")])

reg3_0313_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-13")])
reg3_0313_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-13")])

reg3_0314_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-14")])
reg3_0314_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-14")])

reg3_0315_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-15")])
reg3_0315_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-15")])

reg3_0316_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-16")])
reg3_0316_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-16")])

reg3_0317_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-17")])
reg3_0317_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-17")])

reg3_0318_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-18")])
reg3_0318_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-18")])

reg3_0319_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-19")])
reg3_0319_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-19")])

reg3_0320_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-20")])
reg3_0320_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-20")])

reg3_0321_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-21")])
reg3_0321_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-21")])

reg3_0322_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-22")])
reg3_0322_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-22")])

reg3_0323_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-23")])
reg3_0323_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-23")])

reg3_0324_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-24")])
reg3_0324_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-24")])

reg3_0325_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-25")])
reg3_0325_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-25")])

reg3_0326_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-26")])
reg3_0326_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-26")])

reg3_0327_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-27")])
reg3_0327_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-27")])

reg3_0328_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-28")])
reg3_0328_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-28")])

reg3_0329_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-29")])
reg3_0329_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-29")])

reg3_0330_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-30")])
reg3_0330_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-30")])

reg3_0331_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-31")])
reg3_0331_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-03-31")])

reg3_0401_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-01")])
reg3_0401_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-01")])
reg3_0402_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-02")])
reg3_0402_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-02")])
reg3_0403_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-03")])
reg3_0403_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-03")])
reg3_0404_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-04")])
reg3_0404_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-04")])
reg3_0405_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-05")])
reg3_0405_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-05")])
reg3_0406_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-06")])
reg3_0406_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-06")])
reg3_0407_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-07")])
reg3_0407_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-07")])
reg3_0408_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-08")])
reg3_0408_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-08")])
reg3_0409_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-09")])
reg3_0409_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-09")])
reg3_0410_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-10")])
reg3_0410_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-10")])
reg3_0411_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-11")])
reg3_0411_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-11")])
reg3_0412_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-12")])
reg3_0412_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-12")])
reg3_0413_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-13")])
reg3_0413_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-13")])
reg3_0414_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-14")])
reg3_0414_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-14")])
reg3_0415_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-15")])
reg3_0415_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-15")])
reg3_0416_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-16")])
reg3_0416_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-16")])
reg3_0417_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-17")])
reg3_0417_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-17")])
reg3_0418_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-18")])
reg3_0418_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-18")])
reg3_0419_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-19")])
reg3_0419_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-19")])
reg3_0420_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-20")])
reg3_0420_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-20")])
reg3_0421_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-21")])
reg3_0421_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-21")])
reg3_0422_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-22")])
reg3_0422_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-22")])
reg3_0423_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-23")])
reg3_0423_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-23")])
reg3_0424_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-24")])
reg3_0424_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-24")])
reg3_0425_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-25")])
reg3_0425_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-25")])
reg3_0426_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-26")])
reg3_0426_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-26")])
reg3_0427_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-27")])
reg3_0427_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-27")])
reg3_0428_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-28")])
reg3_0428_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-28")])
reg3_0429_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-29")])
reg3_0429_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-29")])
reg3_0430_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-30")])
reg3_0430_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-01-30")])


reg3_0501_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-01")])
reg3_0501_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-01")])

reg3_0502_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-02")])
reg3_0502_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-02")])

reg3_0503_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-03")])
reg3_0503_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-03")])

reg3_0504_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-04")])
reg3_0504_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-04")])

reg3_0505_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-05")])
reg3_0505_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-05")])

reg3_0506_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-06")])
reg3_0506_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-06")])

reg3_0507_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-07")])
reg3_0507_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-07")])

reg3_0508_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-08")])
reg3_0508_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-08")])

reg3_0509_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-09")])
reg3_0509_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-09")])

reg3_0510_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-10")])
reg3_0510_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-10")])

reg3_0511_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-11")])
reg3_0511_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-11")])

reg3_0512_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-12")])
reg3_0512_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-12")])

reg3_0513_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-13")])
reg3_0513_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-13")])

reg3_0514_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-14")])
reg3_0514_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-14")])

reg3_0515_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-15")])
reg3_0515_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-15")])

reg3_0516_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-16")])
reg3_0516_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-16")])

reg3_0517_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-17")])
reg3_0517_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-17")])

reg3_0518_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-18")])
reg3_0518_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-18")])

reg3_0519_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-19")])
reg3_0519_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-19")])

reg3_0520_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-20")])
reg3_0520_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-20")])

reg3_0521_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-21")])
reg3_0521_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-21")])

reg3_0522_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-22")])
reg3_0522_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-22")])

reg3_0523_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-23")])
reg3_0523_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-23")])

reg3_0524_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-24")])
reg3_0524_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-24")])

reg3_0525_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-25")])
reg3_0525_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-25")])

reg3_0526_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-26")])
reg3_0526_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-26")])

reg3_0527_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-27")])
reg3_0527_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-27")])

reg3_0528_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-28")])
reg3_0528_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-28")])

reg3_0529_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-29")])
reg3_0529_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-29")])

reg3_0530_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-30")])
reg3_0530_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-30")])

reg3_0531_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-31")])
reg3_0531_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-05-31")])

reg3_0601_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-01")])
reg3_0601_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-01")])
reg3_0602_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-02")])
reg3_0602_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-02")])
reg3_0603_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-03")])
reg3_0603_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-03")])
reg3_0604_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-04")])
reg3_0604_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-04")])
reg3_0605_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-05")])
reg3_0605_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-05")])
reg3_0606_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-06")])
reg3_0606_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-06")])
reg3_0607_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-07")])
reg3_0607_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-07")])
reg3_0608_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-08")])
reg3_0608_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-08")])
reg3_0609_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-09")])
reg3_0609_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-09")])
reg3_0610_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-10")])
reg3_0610_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-10")])
reg3_0611_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-11")])
reg3_0611_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-11")])
reg3_0612_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-12")])
reg3_0612_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-12")])
reg3_0613_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-13")])
reg3_0613_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-13")])
reg3_0614_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-14")])
reg3_0614_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-14")])
reg3_0615_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-15")])
reg3_0615_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-15")])
reg3_0616_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-16")])
reg3_0616_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-16")])
reg3_0617_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-17")])
reg3_0617_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-17")])
reg3_0618_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-18")])
reg3_0618_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-18")])
reg3_0619_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-19")])
reg3_0619_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-19")])
reg3_0620_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-20")])
reg3_0620_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-20")])
reg3_0621_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-21")])
reg3_0621_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-21")])
reg3_0622_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-22")])
reg3_0622_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-22")])
reg3_0623_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-23")])
reg3_0623_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-23")])
reg3_0624_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-24")])
reg3_0624_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-24")])
reg3_0625_p<-sum(data.filtrage$P[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-25")])
reg3_0625_t<-sum(data.filtrage$T[which( data.filtrage$reg==3 & data.filtrage$jour=="2021-06-25")])


reg4_0102_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-02")])
reg4_0102_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-02")])
reg4_0103_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-03")])
reg4_0103_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-03")])
reg4_0104_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-04")])
reg4_0104_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-04")])
reg4_0105_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-05")])
reg4_0105_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-05")])
reg4_0106_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-06")])
reg4_0106_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-06")])
reg4_0107_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-07")])
reg4_0107_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-07")])
reg4_0108_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-08")])
reg4_0108_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-08")])
reg4_0109_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-09")])
reg4_0109_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-09")])
reg4_0110_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-10")])
reg4_0110_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-10")])
reg4_0111_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-11")])
reg4_0111_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-11")])
reg4_0112_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-12")])
reg4_0112_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-12")])
reg4_0113_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-13")])
reg4_0113_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-13")])
reg4_0114_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-14")])
reg4_0114_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-14")])
reg4_0115_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-15")])
reg4_0115_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-15")])
reg4_0116_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-16")])
reg4_0116_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-16")])
reg4_0117_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-17")])
reg4_0117_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-17")])
reg4_0118_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-18")])
reg4_0118_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-18")])
reg4_0119_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-19")])
reg4_0119_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-19")])
reg4_0120_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-20")])
reg4_0120_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-20")])
reg4_0121_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-21")])
reg4_0121_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-21")])
reg4_0122_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-22")])
reg4_0122_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-22")])
reg4_0123_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-23")])
reg4_0123_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-23")])
reg4_0124_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-24")])
reg4_0124_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-24")])
reg4_0125_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-25")])
reg4_0125_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-25")])
reg4_0126_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-26")])
reg4_0126_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-26")])
reg4_0127_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-27")])
reg4_0127_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-27")])
reg4_0128_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-28")])
reg4_0128_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-28")])
reg4_0129_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-29")])
reg4_0129_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-29")])

reg4_0130_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-30")])
reg4_0130_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-30")])
reg4_0131_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-31")])
reg4_0131_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-31")])




reg4_0201_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-01")])
reg4_0201_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-01")])
reg4_0202_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-02")])
reg4_0202_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-02")])
reg4_0203_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-03")])
reg4_0203_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-03")])
reg4_0204_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-04")])
reg4_0204_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-04")])
reg4_0205_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-05")])
reg4_0205_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-05")])
reg4_0206_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-06")])
reg4_0206_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-06")])
reg4_0207_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-07")])
reg4_0207_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-07")])
reg4_0208_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-08")])
reg4_0208_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-08")])
reg4_0209_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-09")])
reg4_0209_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-09")])
reg4_0210_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-10")])
reg4_0210_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-10")])
reg4_0211_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-11")])
reg4_0211_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-11")])
reg4_0212_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-12")])
reg4_0212_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-12")])
reg4_0213_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-13")])
reg4_0213_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-13")])
reg4_0214_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-14")])
reg4_0214_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-14")])
reg4_0215_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-15")])
reg4_0215_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-15")])
reg4_0216_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-16")])
reg4_0216_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-16")])
reg4_0217_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-17")])
reg4_0217_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-17")])
reg4_0218_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-18")])
reg4_0218_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-18")])
reg4_0219_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-19")])
reg4_0219_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-19")])
reg4_0220_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-20")])
reg4_0220_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-20")])
reg4_0221_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-21")])
reg4_0221_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-21")])
reg4_0222_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-22")])
reg4_0222_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-22")])
reg4_0223_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-23")])
reg4_0223_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-23")])
reg4_0224_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-24")])
reg4_0224_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-24")])
reg4_0225_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-25")])
reg4_0225_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-25")])
reg4_0226_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-26")])
reg4_0226_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-26")])
reg4_0227_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-27")])
reg4_0227_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-27")])
reg4_0228_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-28")])
reg4_0228_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-02-28")])

reg4_0301_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-01")])
reg4_0301_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-01")])

reg4_0302_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-02")])
reg4_0302_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-02")])

reg4_0303_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-03")])
reg4_0303_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-03")])

reg4_0304_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-04")])
reg4_0304_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-04")])

reg4_0305_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-05")])
reg4_0305_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-05")])

reg4_0306_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-06")])
reg4_0306_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-06")])

reg4_0307_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-07")])
reg4_0307_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-07")])


reg4_0308_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-08")])
reg4_0308_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-08")])

reg4_0309_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-09")])
reg4_0309_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-09")])

reg4_0310_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-10")])
reg4_0310_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-10")])

reg4_0311_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-11")])
reg4_0311_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-11")])

reg4_0312_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-12")])
reg4_0312_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-12")])

reg4_0313_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-13")])
reg4_0313_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-13")])

reg4_0314_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-14")])
reg4_0314_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-14")])

reg4_0315_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-15")])
reg4_0315_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-15")])

reg4_0316_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-16")])
reg4_0316_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-16")])

reg4_0317_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-17")])
reg4_0317_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-17")])

reg4_0318_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-18")])
reg4_0318_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-18")])

reg4_0319_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-19")])
reg4_0319_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-19")])

reg4_0320_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-20")])
reg4_0320_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-20")])

reg4_0321_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-21")])
reg4_0321_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-21")])

reg4_0322_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-22")])
reg4_0322_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-22")])

reg4_0323_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-23")])
reg4_0323_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-23")])

reg4_0324_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-24")])
reg4_0324_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-24")])

reg4_0325_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-25")])
reg4_0325_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-25")])

reg4_0326_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-26")])
reg4_0326_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-26")])

reg4_0327_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-27")])
reg4_0327_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-27")])

reg4_0328_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-28")])
reg4_0328_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-28")])

reg4_0329_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-29")])
reg4_0329_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-29")])

reg4_0330_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-30")])
reg4_0330_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-30")])

reg4_0331_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-31")])
reg4_0331_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-03-31")])

reg4_0401_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-01")])
reg4_0401_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-01")])
reg4_0402_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-02")])
reg4_0402_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-02")])
reg4_0403_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-03")])
reg4_0403_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-03")])
reg4_0404_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-04")])
reg4_0404_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-04")])
reg4_0405_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-05")])
reg4_0405_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-05")])
reg4_0406_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-06")])
reg4_0406_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-06")])
reg4_0407_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-07")])
reg4_0407_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-07")])
reg4_0408_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-08")])
reg4_0408_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-08")])
reg4_0409_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-09")])
reg4_0409_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-09")])
reg4_0410_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-10")])
reg4_0410_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-10")])
reg4_0411_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-11")])
reg4_0411_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-11")])
reg4_0412_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-12")])
reg4_0412_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-12")])
reg4_0413_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-13")])
reg4_0413_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-13")])
reg4_0414_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-14")])
reg4_0414_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-14")])
reg4_0415_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-15")])
reg4_0415_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-15")])
reg4_0416_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-16")])
reg4_0416_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-16")])
reg4_0417_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-17")])
reg4_0417_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-17")])
reg4_0418_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-18")])
reg4_0418_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-18")])
reg4_0419_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-19")])
reg4_0419_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-19")])
reg4_0420_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-20")])
reg4_0420_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-20")])
reg4_0421_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-21")])
reg4_0421_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-21")])
reg4_0422_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-22")])
reg4_0422_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-22")])
reg4_0423_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-23")])
reg4_0423_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-23")])
reg4_0424_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-24")])
reg4_0424_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-24")])
reg4_0425_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-25")])
reg4_0425_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-25")])
reg4_0426_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-26")])
reg4_0426_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-26")])
reg4_0427_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-27")])
reg4_0427_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-27")])
reg4_0428_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-28")])
reg4_0428_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-28")])
reg4_0429_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-29")])
reg4_0429_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-29")])
reg4_0430_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-30")])
reg4_0430_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-01-30")])


reg4_0501_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-01")])
reg4_0501_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-01")])

reg4_0502_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-02")])
reg4_0502_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-02")])

reg4_0503_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-03")])
reg4_0503_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-03")])

reg4_0504_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-04")])
reg4_0504_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-04")])

reg4_0505_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-05")])
reg4_0505_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-05")])

reg4_0506_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-06")])
reg4_0506_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-06")])

reg4_0507_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-07")])
reg4_0507_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-07")])

reg4_0508_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-08")])
reg4_0508_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-08")])

reg4_0509_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-09")])
reg4_0509_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-09")])

reg4_0510_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-10")])
reg4_0510_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-10")])

reg4_0511_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-11")])
reg4_0511_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-11")])

reg4_0512_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-12")])
reg4_0512_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-12")])

reg4_0513_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-13")])
reg4_0513_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-13")])

reg4_0514_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-14")])
reg4_0514_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-14")])

reg4_0515_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-15")])
reg4_0515_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-15")])

reg4_0516_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-16")])
reg4_0516_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-16")])

reg4_0517_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-17")])
reg4_0517_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-17")])

reg4_0518_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-18")])
reg4_0518_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-18")])

reg4_0519_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-19")])
reg4_0519_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-19")])

reg4_0520_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-20")])
reg4_0520_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-20")])

reg4_0521_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-21")])
reg4_0521_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-21")])

reg4_0522_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-22")])
reg4_0522_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-22")])

reg4_0523_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-23")])
reg4_0523_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-23")])

reg4_0524_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-24")])
reg4_0524_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-24")])

reg4_0525_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-25")])
reg4_0525_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-25")])

reg4_0526_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-26")])
reg4_0526_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-26")])

reg4_0527_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-27")])
reg4_0527_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-27")])

reg4_0528_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-28")])
reg4_0528_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-28")])

reg4_0529_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-29")])
reg4_0529_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-29")])

reg4_0530_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-30")])
reg4_0530_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-30")])

reg4_0531_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-31")])
reg4_0531_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-05-31")])

reg4_0601_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-01")])
reg4_0601_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-01")])
reg4_0602_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-02")])
reg4_0602_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-02")])
reg4_0603_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-03")])
reg4_0603_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-03")])
reg4_0604_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-04")])
reg4_0604_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-04")])
reg4_0605_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-05")])
reg4_0605_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-05")])
reg4_0606_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-06")])
reg4_0606_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-06")])
reg4_0607_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-07")])
reg4_0607_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-07")])
reg4_0608_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-08")])
reg4_0608_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-08")])
reg4_0609_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-09")])
reg4_0609_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-09")])
reg4_0610_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-10")])
reg4_0610_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-10")])
reg4_0611_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-11")])
reg4_0611_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-11")])
reg4_0612_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-12")])
reg4_0612_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-12")])
reg4_0613_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-13")])
reg4_0613_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-13")])
reg4_0614_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-14")])
reg4_0614_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-14")])
reg4_0615_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-15")])
reg4_0615_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-15")])
reg4_0616_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-16")])
reg4_0616_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-16")])
reg4_0617_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-17")])
reg4_0617_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-17")])
reg4_0618_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-18")])
reg4_0618_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-18")])
reg4_0619_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-19")])
reg4_0619_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-19")])
reg4_0620_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-20")])
reg4_0620_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-20")])
reg4_0621_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-21")])
reg4_0621_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-21")])
reg4_0622_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-22")])
reg4_0622_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-22")])
reg4_0623_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-23")])
reg4_0623_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-23")])
reg4_0624_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-24")])
reg4_0624_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-24")])
reg4_0625_p<-sum(data.filtrage$P[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-25")])
reg4_0625_t<-sum(data.filtrage$T[which( data.filtrage$reg==4 & data.filtrage$jour=="2021-06-25")])


reg5_0102_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-02")])
reg5_0102_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-02")])
reg5_0103_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-03")])
reg5_0103_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-03")])
reg5_0104_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-04")])
reg5_0104_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-04")])
reg5_0105_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-05")])
reg5_0105_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-05")])
reg5_0106_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-06")])
reg5_0106_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-06")])
reg5_0107_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-07")])
reg5_0107_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-07")])
reg5_0108_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-08")])
reg5_0108_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-08")])
reg5_0109_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-09")])
reg5_0109_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-09")])
reg5_0110_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-10")])
reg5_0110_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-10")])
reg5_0111_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-11")])
reg5_0111_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-11")])
reg5_0112_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-12")])
reg5_0112_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-12")])
reg5_0113_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-13")])
reg5_0113_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-13")])
reg5_0114_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-14")])
reg5_0114_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-14")])
reg5_0115_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-15")])
reg5_0115_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-15")])
reg5_0116_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-16")])
reg5_0116_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-16")])
reg5_0117_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-17")])
reg5_0117_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-17")])
reg5_0118_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-18")])
reg5_0118_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-18")])
reg5_0119_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-19")])
reg5_0119_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-19")])
reg5_0120_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-20")])
reg5_0120_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-20")])
reg5_0121_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-21")])
reg5_0121_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-21")])
reg5_0122_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-22")])
reg5_0122_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-22")])
reg5_0123_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-23")])
reg5_0123_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-23")])
reg5_0124_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-24")])
reg5_0124_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-24")])
reg5_0125_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-25")])
reg5_0125_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-25")])
reg5_0126_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-26")])
reg5_0126_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-26")])
reg5_0127_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-27")])
reg5_0127_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-27")])
reg5_0128_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-28")])
reg5_0128_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-28")])
reg5_0129_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-29")])
reg5_0129_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-29")])

reg5_0130_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-30")])
reg5_0130_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-30")])
reg5_0131_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-31")])
reg5_0131_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-31")])




reg5_0201_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-01")])
reg5_0201_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-01")])
reg5_0202_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-02")])
reg5_0202_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-02")])
reg5_0203_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-03")])
reg5_0203_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-03")])
reg5_0204_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-04")])
reg5_0204_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-04")])
reg5_0205_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-05")])
reg5_0205_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-05")])
reg5_0206_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-06")])
reg5_0206_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-06")])
reg5_0207_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-07")])
reg5_0207_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-07")])
reg5_0208_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-08")])
reg5_0208_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-08")])
reg5_0209_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-09")])
reg5_0209_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-09")])
reg5_0210_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-10")])
reg5_0210_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-10")])
reg5_0211_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-11")])
reg5_0211_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-11")])
reg5_0212_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-12")])
reg5_0212_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-12")])
reg5_0213_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-13")])
reg5_0213_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-13")])
reg5_0214_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-14")])
reg5_0214_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-14")])
reg5_0215_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-15")])
reg5_0215_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-15")])
reg5_0216_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-16")])
reg5_0216_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-16")])
reg5_0217_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-17")])
reg5_0217_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-17")])
reg5_0218_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-18")])
reg5_0218_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-18")])
reg5_0219_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-19")])
reg5_0219_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-19")])
reg5_0220_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-20")])
reg5_0220_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-20")])
reg5_0221_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-21")])
reg5_0221_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-21")])
reg5_0222_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-22")])
reg5_0222_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-22")])
reg5_0223_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-23")])
reg5_0223_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-23")])
reg5_0224_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-24")])
reg5_0224_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-24")])
reg5_0225_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-25")])
reg5_0225_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-25")])
reg5_0226_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-26")])
reg5_0226_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-26")])
reg5_0227_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-27")])
reg5_0227_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-27")])
reg5_0228_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-28")])
reg5_0228_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-02-28")])

reg5_0301_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-01")])
reg5_0301_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-01")])

reg5_0302_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-02")])
reg5_0302_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-02")])

reg5_0303_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-03")])
reg5_0303_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-03")])

reg5_0304_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-04")])
reg5_0304_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-04")])

reg5_0305_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-05")])
reg5_0305_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-05")])

reg5_0306_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-06")])
reg5_0306_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-06")])

reg5_0307_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-07")])
reg5_0307_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-07")])


reg5_0308_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-08")])
reg5_0308_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-08")])

reg5_0309_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-09")])
reg5_0309_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-09")])

reg5_0310_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-10")])
reg5_0310_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-10")])

reg5_0311_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-11")])
reg5_0311_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-11")])

reg5_0312_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-12")])
reg5_0312_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-12")])

reg5_0313_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-13")])
reg5_0313_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-13")])

reg5_0314_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-14")])
reg5_0314_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-14")])

reg5_0315_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-15")])
reg5_0315_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-15")])

reg5_0316_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-16")])
reg5_0316_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-16")])

reg5_0317_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-17")])
reg5_0317_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-17")])

reg5_0318_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-18")])
reg5_0318_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-18")])

reg5_0319_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-19")])
reg5_0319_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-19")])

reg5_0320_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-20")])
reg5_0320_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-20")])

reg5_0321_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-21")])
reg5_0321_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-21")])

reg5_0322_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-22")])
reg5_0322_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-22")])

reg5_0323_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-23")])
reg5_0323_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-23")])

reg5_0324_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-24")])
reg5_0324_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-24")])

reg5_0325_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-25")])
reg5_0325_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-25")])

reg5_0326_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-26")])
reg5_0326_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-26")])

reg5_0327_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-27")])
reg5_0327_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-27")])

reg5_0328_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-28")])
reg5_0328_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-28")])

reg5_0329_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-29")])
reg5_0329_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-29")])

reg5_0330_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-30")])
reg5_0330_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-30")])

reg5_0331_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-31")])
reg5_0331_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-03-31")])

reg5_0401_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-01")])
reg5_0401_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-01")])
reg5_0402_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-02")])
reg5_0402_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-02")])
reg5_0403_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-03")])
reg5_0403_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-03")])
reg5_0404_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-04")])
reg5_0404_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-04")])
reg5_0405_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-05")])
reg5_0405_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-05")])
reg5_0406_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-06")])
reg5_0406_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-06")])
reg5_0407_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-07")])
reg5_0407_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-07")])
reg5_0408_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-08")])
reg5_0408_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-08")])
reg5_0409_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-09")])
reg5_0409_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-09")])
reg5_0410_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-10")])
reg5_0410_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-10")])
reg5_0411_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-11")])
reg5_0411_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-11")])
reg5_0412_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-12")])
reg5_0412_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-12")])
reg5_0413_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-13")])
reg5_0413_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-13")])
reg5_0414_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-14")])
reg5_0414_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-14")])
reg5_0415_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-15")])
reg5_0415_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-15")])
reg5_0416_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-16")])
reg5_0416_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-16")])
reg5_0417_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-17")])
reg5_0417_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-17")])
reg5_0418_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-18")])
reg5_0418_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-18")])
reg5_0419_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-19")])
reg5_0419_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-19")])
reg5_0420_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-20")])
reg5_0420_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-20")])
reg5_0421_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-21")])
reg5_0421_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-21")])
reg5_0422_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-22")])
reg5_0422_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-22")])
reg5_0423_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-23")])
reg5_0423_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-23")])
reg5_0424_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-24")])
reg5_0424_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-24")])
reg5_0425_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-25")])
reg5_0425_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-25")])
reg5_0426_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-26")])
reg5_0426_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-26")])
reg5_0427_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-27")])
reg5_0427_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-27")])
reg5_0428_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-28")])
reg5_0428_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-28")])
reg5_0429_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-29")])
reg5_0429_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-29")])
reg5_0430_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-30")])
reg5_0430_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-01-30")])


reg5_0501_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-01")])
reg5_0501_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-01")])

reg5_0502_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-02")])
reg5_0502_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-02")])

reg5_0503_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-03")])
reg5_0503_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-03")])

reg5_0504_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-04")])
reg5_0504_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-04")])

reg5_0505_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-05")])
reg5_0505_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-05")])

reg5_0506_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-06")])
reg5_0506_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-06")])

reg5_0507_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-07")])
reg5_0507_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-07")])

reg5_0508_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-08")])
reg5_0508_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-08")])

reg5_0509_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-09")])
reg5_0509_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-09")])

reg5_0510_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-10")])
reg5_0510_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-10")])

reg5_0511_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-11")])
reg5_0511_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-11")])

reg5_0512_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-12")])
reg5_0512_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-12")])

reg5_0513_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-13")])
reg5_0513_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-13")])

reg5_0514_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-14")])
reg5_0514_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-14")])

reg5_0515_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-15")])
reg5_0515_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-15")])

reg5_0516_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-16")])
reg5_0516_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-16")])

reg5_0517_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-17")])
reg5_0517_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-17")])

reg5_0518_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-18")])
reg5_0518_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-18")])

reg5_0519_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-19")])
reg5_0519_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-19")])

reg5_0520_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-20")])
reg5_0520_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-20")])

reg5_0521_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-21")])
reg5_0521_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-21")])

reg5_0522_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-22")])
reg5_0522_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-22")])

reg5_0523_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-23")])
reg5_0523_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-23")])

reg5_0524_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-24")])
reg5_0524_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-24")])

reg5_0525_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-25")])
reg5_0525_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-25")])

reg5_0526_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-26")])
reg5_0526_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-26")])

reg5_0527_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-27")])
reg5_0527_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-27")])

reg5_0528_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-28")])
reg5_0528_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-28")])

reg5_0529_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-29")])
reg5_0529_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-29")])

reg5_0530_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-30")])
reg5_0530_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-30")])

reg5_0531_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-31")])
reg5_0531_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-05-31")])

reg5_0601_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-01")])
reg5_0601_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-01")])
reg5_0602_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-02")])
reg5_0602_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-02")])
reg5_0603_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-03")])
reg5_0603_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-03")])
reg5_0604_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-04")])
reg5_0604_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-04")])
reg5_0605_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-05")])
reg5_0605_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-05")])
reg5_0606_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-06")])
reg5_0606_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-06")])
reg5_0607_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-07")])
reg5_0607_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-07")])
reg5_0608_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-08")])
reg5_0608_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-08")])
reg5_0609_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-09")])
reg5_0609_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-09")])
reg5_0610_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-10")])
reg5_0610_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-10")])
reg5_0611_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-11")])
reg5_0611_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-11")])
reg5_0612_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-12")])
reg5_0612_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-12")])
reg5_0613_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-13")])
reg5_0613_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-13")])
reg5_0614_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-14")])
reg5_0614_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-14")])
reg5_0615_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-15")])
reg5_0615_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-15")])
reg5_0616_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-16")])
reg5_0616_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-16")])
reg5_0617_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-17")])
reg5_0617_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-17")])
reg5_0618_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-18")])
reg5_0618_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-18")])
reg5_0619_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-19")])
reg5_0619_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-19")])
reg5_0620_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-20")])
reg5_0620_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-20")])
reg5_0621_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-21")])
reg5_0621_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-21")])
reg5_0622_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-22")])
reg5_0622_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-22")])
reg5_0623_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-23")])
reg5_0623_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-23")])
reg5_0624_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-24")])
reg5_0624_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-24")])
reg5_0625_p<-sum(data.filtrage$P[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-25")])
reg5_0625_t<-sum(data.filtrage$T[which( data.filtrage$reg==5 & data.filtrage$jour=="2021-06-25")])


reg6_0102_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-02")])
reg6_0102_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-02")])
reg6_0103_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-03")])
reg6_0103_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-03")])
reg6_0104_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-04")])
reg6_0104_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-04")])
reg6_0105_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-05")])
reg6_0105_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-05")])
reg6_0106_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-06")])
reg6_0106_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-06")])
reg6_0107_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-07")])
reg6_0107_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-07")])
reg6_0108_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-08")])
reg6_0108_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-08")])
reg6_0109_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-09")])
reg6_0109_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-09")])
reg6_0110_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-10")])
reg6_0110_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-10")])
reg6_0111_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-11")])
reg6_0111_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-11")])
reg6_0112_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-12")])
reg6_0112_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-12")])
reg6_0113_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-13")])
reg6_0113_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-13")])
reg6_0114_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-14")])
reg6_0114_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-14")])
reg6_0115_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-15")])
reg6_0115_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-15")])
reg6_0116_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-16")])
reg6_0116_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-16")])
reg6_0117_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-17")])
reg6_0117_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-17")])
reg6_0118_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-18")])
reg6_0118_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-18")])
reg6_0119_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-19")])
reg6_0119_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-19")])
reg6_0120_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-20")])
reg6_0120_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-20")])
reg6_0121_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-21")])
reg6_0121_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-21")])
reg6_0122_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-22")])
reg6_0122_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-22")])
reg6_0123_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-23")])
reg6_0123_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-23")])
reg6_0124_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-24")])
reg6_0124_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-24")])
reg6_0125_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-25")])
reg6_0125_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-25")])
reg6_0126_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-26")])
reg6_0126_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-26")])
reg6_0127_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-27")])
reg6_0127_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-27")])
reg6_0128_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-28")])
reg6_0128_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-28")])
reg6_0129_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-29")])
reg6_0129_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-29")])

reg6_0130_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-30")])
reg6_0130_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-30")])
reg6_0131_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-31")])
reg6_0131_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-31")])




reg6_0201_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-01")])
reg6_0201_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-01")])
reg6_0202_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-02")])
reg6_0202_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-02")])
reg6_0203_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-03")])
reg6_0203_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-03")])
reg6_0204_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-04")])
reg6_0204_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-04")])
reg6_0205_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-05")])
reg6_0205_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-05")])
reg6_0206_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-06")])
reg6_0206_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-06")])
reg6_0207_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-07")])
reg6_0207_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-07")])
reg6_0208_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-08")])
reg6_0208_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-08")])
reg6_0209_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-09")])
reg6_0209_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-09")])
reg6_0210_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-10")])
reg6_0210_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-10")])
reg6_0211_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-11")])
reg6_0211_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-11")])
reg6_0212_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-12")])
reg6_0212_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-12")])
reg6_0213_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-13")])
reg6_0213_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-13")])
reg6_0214_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-14")])
reg6_0214_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-14")])
reg6_0215_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-15")])
reg6_0215_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-15")])
reg6_0216_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-16")])
reg6_0216_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-16")])
reg6_0217_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-17")])
reg6_0217_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-17")])
reg6_0218_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-18")])
reg6_0218_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-18")])
reg6_0219_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-19")])
reg6_0219_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-19")])
reg6_0220_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-20")])
reg6_0220_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-20")])
reg6_0221_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-21")])
reg6_0221_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-21")])
reg6_0222_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-22")])
reg6_0222_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-22")])
reg6_0223_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-23")])
reg6_0223_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-23")])
reg6_0224_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-24")])
reg6_0224_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-24")])
reg6_0225_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-25")])
reg6_0225_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-25")])
reg6_0226_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-26")])
reg6_0226_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-26")])
reg6_0227_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-27")])
reg6_0227_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-27")])
reg6_0228_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-28")])
reg6_0228_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-02-28")])

reg6_0301_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-01")])
reg6_0301_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-01")])

reg6_0302_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-02")])
reg6_0302_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-02")])

reg6_0303_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-03")])
reg6_0303_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-03")])

reg6_0304_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-04")])
reg6_0304_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-04")])

reg6_0305_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-05")])
reg6_0305_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-05")])

reg6_0306_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-06")])
reg6_0306_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-06")])

reg6_0307_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-07")])
reg6_0307_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-07")])


reg6_0308_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-08")])
reg6_0308_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-08")])

reg6_0309_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-09")])
reg6_0309_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-09")])

reg6_0310_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-10")])
reg6_0310_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-10")])

reg6_0311_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-11")])
reg6_0311_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-11")])

reg6_0312_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-12")])
reg6_0312_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-12")])

reg6_0313_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-13")])
reg6_0313_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-13")])

reg6_0314_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-14")])
reg6_0314_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-14")])

reg6_0315_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-15")])
reg6_0315_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-15")])

reg6_0316_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-16")])
reg6_0316_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-16")])

reg6_0317_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-17")])
reg6_0317_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-17")])

reg6_0318_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-18")])
reg6_0318_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-18")])

reg6_0319_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-19")])
reg6_0319_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-19")])

reg6_0320_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-20")])
reg6_0320_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-20")])

reg6_0321_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-21")])
reg6_0321_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-21")])

reg6_0322_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-22")])
reg6_0322_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-22")])

reg6_0323_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-23")])
reg6_0323_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-23")])

reg6_0324_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-24")])
reg6_0324_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-24")])

reg6_0325_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-25")])
reg6_0325_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-25")])

reg6_0326_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-26")])
reg6_0326_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-26")])

reg6_0327_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-27")])
reg6_0327_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-27")])

reg6_0328_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-28")])
reg6_0328_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-28")])

reg6_0329_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-29")])
reg6_0329_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-29")])

reg6_0330_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-30")])
reg6_0330_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-30")])

reg6_0331_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-31")])
reg6_0331_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-03-31")])

reg6_0401_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-01")])
reg6_0401_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-01")])
reg6_0402_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-02")])
reg6_0402_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-02")])
reg6_0403_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-03")])
reg6_0403_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-03")])
reg6_0404_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-04")])
reg6_0404_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-04")])
reg6_0405_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-05")])
reg6_0405_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-05")])
reg6_0406_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-06")])
reg6_0406_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-06")])
reg6_0407_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-07")])
reg6_0407_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-07")])
reg6_0408_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-08")])
reg6_0408_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-08")])
reg6_0409_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-09")])
reg6_0409_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-09")])
reg6_0410_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-10")])
reg6_0410_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-10")])
reg6_0411_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-11")])
reg6_0411_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-11")])
reg6_0412_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-12")])
reg6_0412_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-12")])
reg6_0413_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-13")])
reg6_0413_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-13")])
reg6_0414_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-14")])
reg6_0414_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-14")])
reg6_0415_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-15")])
reg6_0415_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-15")])
reg6_0416_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-16")])
reg6_0416_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-16")])
reg6_0417_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-17")])
reg6_0417_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-17")])
reg6_0418_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-18")])
reg6_0418_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-18")])
reg6_0419_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-19")])
reg6_0419_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-19")])
reg6_0420_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-20")])
reg6_0420_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-20")])
reg6_0421_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-21")])
reg6_0421_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-21")])
reg6_0422_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-22")])
reg6_0422_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-22")])
reg6_0423_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-23")])
reg6_0423_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-23")])
reg6_0424_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-24")])
reg6_0424_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-24")])
reg6_0425_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-25")])
reg6_0425_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-25")])
reg6_0426_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-26")])
reg6_0426_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-26")])
reg6_0427_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-27")])
reg6_0427_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-27")])
reg6_0428_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-28")])
reg6_0428_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-28")])
reg6_0429_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-29")])
reg6_0429_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-29")])
reg6_0430_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-30")])
reg6_0430_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-01-30")])


reg6_0501_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-01")])
reg6_0501_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-01")])

reg6_0502_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-02")])
reg6_0502_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-02")])

reg6_0503_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-03")])
reg6_0503_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-03")])

reg6_0504_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-04")])
reg6_0504_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-04")])

reg6_0505_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-05")])
reg6_0505_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-05")])

reg6_0506_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-06")])
reg6_0506_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-06")])

reg6_0507_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-07")])
reg6_0507_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-07")])

reg6_0508_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-08")])
reg6_0508_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-08")])

reg6_0509_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-09")])
reg6_0509_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-09")])

reg6_0510_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-10")])
reg6_0510_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-10")])

reg6_0511_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-11")])
reg6_0511_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-11")])

reg6_0512_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-12")])
reg6_0512_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-12")])

reg6_0513_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-13")])
reg6_0513_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-13")])

reg6_0514_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-14")])
reg6_0514_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-14")])

reg6_0515_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-15")])
reg6_0515_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-15")])

reg6_0516_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-16")])
reg6_0516_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-16")])

reg6_0517_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-17")])
reg6_0517_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-17")])

reg6_0518_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-18")])
reg6_0518_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-18")])

reg6_0519_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-19")])
reg6_0519_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-19")])

reg6_0520_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-20")])
reg6_0520_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-20")])

reg6_0521_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-21")])
reg6_0521_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-21")])

reg6_0522_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-22")])
reg6_0522_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-22")])

reg6_0523_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-23")])
reg6_0523_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-23")])

reg6_0524_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-24")])
reg6_0524_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-24")])

reg6_0525_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-25")])
reg6_0525_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-25")])

reg6_0526_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-26")])
reg6_0526_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-26")])

reg6_0527_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-27")])
reg6_0527_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-27")])

reg6_0528_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-28")])
reg6_0528_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-28")])

reg6_0529_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-29")])
reg6_0529_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-29")])

reg6_0530_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-30")])
reg6_0530_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-30")])

reg6_0531_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-31")])
reg6_0531_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-05-31")])

reg6_0601_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-01")])
reg6_0601_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-01")])
reg6_0602_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-02")])
reg6_0602_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-02")])
reg6_0603_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-03")])
reg6_0603_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-03")])
reg6_0604_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-04")])
reg6_0604_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-04")])
reg6_0605_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-05")])
reg6_0605_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-05")])
reg6_0606_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-06")])
reg6_0606_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-06")])
reg6_0607_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-07")])
reg6_0607_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-07")])
reg6_0608_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-08")])
reg6_0608_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-08")])
reg6_0609_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-09")])
reg6_0609_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-09")])
reg6_0610_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-10")])
reg6_0610_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-10")])
reg6_0611_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-11")])
reg6_0611_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-11")])
reg6_0612_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-12")])
reg6_0612_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-12")])
reg6_0613_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-13")])
reg6_0613_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-13")])
reg6_0614_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-14")])
reg6_0614_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-14")])
reg6_0615_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-15")])
reg6_0615_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-15")])
reg6_0616_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-16")])
reg6_0616_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-16")])
reg6_0617_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-17")])
reg6_0617_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-17")])
reg6_0618_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-18")])
reg6_0618_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-18")])
reg6_0619_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-19")])
reg6_0619_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-19")])
reg6_0620_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-20")])
reg6_0620_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-20")])
reg6_0621_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-21")])
reg6_0621_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-21")])
reg6_0622_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-22")])
reg6_0622_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-22")])
reg6_0623_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-23")])
reg6_0623_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-23")])
reg6_0624_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-24")])
reg6_0624_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-24")])
reg6_0625_p<-sum(data.filtrage$P[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-25")])
reg6_0625_t<-sum(data.filtrage$T[which( data.filtrage$reg==6 & data.filtrage$jour=="2021-06-25")])


reg7_0102_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-02")])
reg7_0102_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-02")])
reg7_0103_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-03")])
reg7_0103_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-03")])
reg7_0104_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-04")])
reg7_0104_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-04")])
reg7_0105_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-05")])
reg7_0105_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-05")])
reg7_0106_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-06")])
reg7_0106_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-06")])
reg7_0107_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-07")])
reg7_0107_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-07")])
reg7_0108_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-08")])
reg7_0108_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-08")])
reg7_0109_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-09")])
reg7_0109_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-09")])
reg7_0110_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-10")])
reg7_0110_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-10")])
reg7_0111_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-11")])
reg7_0111_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-11")])
reg7_0112_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-12")])
reg7_0112_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-12")])
reg7_0113_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-13")])
reg7_0113_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-13")])
reg7_0114_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-14")])
reg7_0114_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-14")])
reg7_0115_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-15")])
reg7_0115_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-15")])
reg7_0116_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-16")])
reg7_0116_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-16")])
reg7_0117_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-17")])
reg7_0117_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-17")])
reg7_0118_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-18")])
reg7_0118_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-18")])
reg7_0119_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-19")])
reg7_0119_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-19")])
reg7_0120_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-20")])
reg7_0120_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-20")])
reg7_0121_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-21")])
reg7_0121_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-21")])
reg7_0122_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-22")])
reg7_0122_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-22")])
reg7_0123_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-23")])
reg7_0123_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-23")])
reg7_0124_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-24")])
reg7_0124_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-24")])
reg7_0125_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-25")])
reg7_0125_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-25")])
reg7_0126_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-26")])
reg7_0126_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-26")])
reg7_0127_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-27")])
reg7_0127_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-27")])
reg7_0128_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-28")])
reg7_0128_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-28")])
reg7_0129_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-29")])
reg7_0129_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-29")])

reg7_0130_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-30")])
reg7_0130_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-30")])
reg7_0131_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-31")])
reg7_0131_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-31")])




reg7_0201_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-01")])
reg7_0201_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-01")])
reg7_0202_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-02")])
reg7_0202_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-02")])
reg7_0203_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-03")])
reg7_0203_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-03")])
reg7_0204_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-04")])
reg7_0204_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-04")])
reg7_0205_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-05")])
reg7_0205_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-05")])
reg7_0206_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-06")])
reg7_0206_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-06")])
reg7_0207_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-07")])
reg7_0207_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-07")])
reg7_0208_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-08")])
reg7_0208_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-08")])
reg7_0209_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-09")])
reg7_0209_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-09")])
reg7_0210_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-10")])
reg7_0210_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-10")])
reg7_0211_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-11")])
reg7_0211_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-11")])
reg7_0212_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-12")])
reg7_0212_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-12")])
reg7_0213_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-13")])
reg7_0213_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-13")])
reg7_0214_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-14")])
reg7_0214_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-14")])
reg7_0215_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-15")])
reg7_0215_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-15")])
reg7_0216_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-16")])
reg7_0216_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-16")])
reg7_0217_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-17")])
reg7_0217_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-17")])
reg7_0218_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-18")])
reg7_0218_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-18")])
reg7_0219_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-19")])
reg7_0219_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-19")])
reg7_0220_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-20")])
reg7_0220_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-20")])
reg7_0221_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-21")])
reg7_0221_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-21")])
reg7_0222_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-22")])
reg7_0222_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-22")])
reg7_0223_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-23")])
reg7_0223_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-23")])
reg7_0224_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-24")])
reg7_0224_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-24")])
reg7_0225_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-25")])
reg7_0225_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-25")])
reg7_0226_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-26")])
reg7_0226_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-26")])
reg7_0227_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-27")])
reg7_0227_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-27")])
reg7_0228_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-28")])
reg7_0228_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-02-28")])

reg7_0301_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-01")])
reg7_0301_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-01")])

reg7_0302_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-02")])
reg7_0302_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-02")])

reg7_0303_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-03")])
reg7_0303_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-03")])

reg7_0304_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-04")])
reg7_0304_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-04")])

reg7_0305_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-05")])
reg7_0305_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-05")])

reg7_0306_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-06")])
reg7_0306_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-06")])

reg7_0307_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-07")])
reg7_0307_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-07")])


reg7_0308_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-08")])
reg7_0308_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-08")])

reg7_0309_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-09")])
reg7_0309_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-09")])

reg7_0310_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-10")])
reg7_0310_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-10")])

reg7_0311_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-11")])
reg7_0311_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-11")])

reg7_0312_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-12")])
reg7_0312_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-12")])

reg7_0313_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-13")])
reg7_0313_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-13")])

reg7_0314_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-14")])
reg7_0314_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-14")])

reg7_0315_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-15")])
reg7_0315_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-15")])

reg7_0316_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-16")])
reg7_0316_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-16")])

reg7_0317_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-17")])
reg7_0317_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-17")])

reg7_0318_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-18")])
reg7_0318_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-18")])

reg7_0319_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-19")])
reg7_0319_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-19")])

reg7_0320_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-20")])
reg7_0320_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-20")])

reg7_0321_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-21")])
reg7_0321_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-21")])

reg7_0322_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-22")])
reg7_0322_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-22")])

reg7_0323_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-23")])
reg7_0323_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-23")])

reg7_0324_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-24")])
reg7_0324_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-24")])

reg7_0325_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-25")])
reg7_0325_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-25")])

reg7_0326_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-26")])
reg7_0326_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-26")])

reg7_0327_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-27")])
reg7_0327_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-27")])

reg7_0328_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-28")])
reg7_0328_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-28")])

reg7_0329_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-29")])
reg7_0329_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-29")])

reg7_0330_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-30")])
reg7_0330_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-30")])

reg7_0331_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-31")])
reg7_0331_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-03-31")])

reg7_0401_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-01")])
reg7_0401_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-01")])
reg7_0402_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-02")])
reg7_0402_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-02")])
reg7_0403_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-03")])
reg7_0403_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-03")])
reg7_0404_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-04")])
reg7_0404_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-04")])
reg7_0405_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-05")])
reg7_0405_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-05")])
reg7_0406_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-06")])
reg7_0406_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-06")])
reg7_0407_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-07")])
reg7_0407_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-07")])
reg7_0408_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-08")])
reg7_0408_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-08")])
reg7_0409_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-09")])
reg7_0409_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-09")])
reg7_0410_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-10")])
reg7_0410_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-10")])
reg7_0411_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-11")])
reg7_0411_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-11")])
reg7_0412_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-12")])
reg7_0412_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-12")])
reg7_0413_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-13")])
reg7_0413_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-13")])
reg7_0414_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-14")])
reg7_0414_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-14")])
reg7_0415_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-15")])
reg7_0415_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-15")])
reg7_0416_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-16")])
reg7_0416_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-16")])
reg7_0417_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-17")])
reg7_0417_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-17")])
reg7_0418_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-18")])
reg7_0418_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-18")])
reg7_0419_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-19")])
reg7_0419_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-19")])
reg7_0420_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-20")])
reg7_0420_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-20")])
reg7_0421_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-21")])
reg7_0421_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-21")])
reg7_0422_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-22")])
reg7_0422_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-22")])
reg7_0423_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-23")])
reg7_0423_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-23")])
reg7_0424_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-24")])
reg7_0424_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-24")])
reg7_0425_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-25")])
reg7_0425_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-25")])
reg7_0426_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-26")])
reg7_0426_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-26")])
reg7_0427_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-27")])
reg7_0427_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-27")])
reg7_0428_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-28")])
reg7_0428_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-28")])
reg7_0429_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-29")])
reg7_0429_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-29")])
reg7_0430_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-30")])
reg7_0430_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-01-30")])


reg7_0501_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-01")])
reg7_0501_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-01")])

reg7_0502_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-02")])
reg7_0502_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-02")])

reg7_0503_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-03")])
reg7_0503_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-03")])

reg7_0504_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-04")])
reg7_0504_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-04")])

reg7_0505_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-05")])
reg7_0505_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-05")])

reg7_0506_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-06")])
reg7_0506_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-06")])

reg7_0507_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-07")])
reg7_0507_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-07")])

reg7_0508_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-08")])
reg7_0508_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-08")])

reg7_0509_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-09")])
reg7_0509_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-09")])

reg7_0510_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-10")])
reg7_0510_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-10")])

reg7_0511_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-11")])
reg7_0511_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-11")])

reg7_0512_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-12")])
reg7_0512_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-12")])

reg7_0513_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-13")])
reg7_0513_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-13")])

reg7_0514_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-14")])
reg7_0514_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-14")])

reg7_0515_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-15")])
reg7_0515_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-15")])

reg7_0516_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-16")])
reg7_0516_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-16")])

reg7_0517_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-17")])
reg7_0517_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-17")])

reg7_0518_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-18")])
reg7_0518_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-18")])

reg7_0519_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-19")])
reg7_0519_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-19")])

reg7_0520_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-20")])
reg7_0520_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-20")])

reg7_0521_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-21")])
reg7_0521_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-21")])

reg7_0522_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-22")])
reg7_0522_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-22")])

reg7_0523_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-23")])
reg7_0523_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-23")])

reg7_0524_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-24")])
reg7_0524_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-24")])

reg7_0525_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-25")])
reg7_0525_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-25")])

reg7_0526_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-26")])
reg7_0526_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-26")])

reg7_0527_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-27")])
reg7_0527_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-27")])

reg7_0528_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-28")])
reg7_0528_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-28")])

reg7_0529_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-29")])
reg7_0529_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-29")])

reg7_0530_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-30")])
reg7_0530_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-30")])

reg7_0531_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-31")])
reg7_0531_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-05-31")])

reg7_0601_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-01")])
reg7_0601_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-01")])
reg7_0602_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-02")])
reg7_0602_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-02")])
reg7_0603_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-03")])
reg7_0603_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-03")])
reg7_0604_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-04")])
reg7_0604_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-04")])
reg7_0605_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-05")])
reg7_0605_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-05")])
reg7_0606_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-06")])
reg7_0606_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-06")])
reg7_0607_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-07")])
reg7_0607_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-07")])
reg7_0608_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-08")])
reg7_0608_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-08")])
reg7_0609_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-09")])
reg7_0609_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-09")])
reg7_0610_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-10")])
reg7_0610_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-10")])
reg7_0611_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-11")])
reg7_0611_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-11")])
reg7_0612_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-12")])
reg7_0612_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-12")])
reg7_0613_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-13")])
reg7_0613_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-13")])
reg7_0614_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-14")])
reg7_0614_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-14")])
reg7_0615_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-15")])
reg7_0615_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-15")])
reg7_0616_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-16")])
reg7_0616_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-16")])
reg7_0617_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-17")])
reg7_0617_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-17")])
reg7_0618_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-18")])
reg7_0618_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-18")])
reg7_0619_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-19")])
reg7_0619_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-19")])
reg7_0620_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-20")])
reg7_0620_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-20")])
reg7_0621_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-21")])
reg7_0621_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-21")])
reg7_0622_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-22")])
reg7_0622_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-22")])
reg7_0623_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-23")])
reg7_0623_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-23")])
reg7_0624_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-24")])
reg7_0624_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-24")])
reg7_0625_p<-sum(data.filtrage$P[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-25")])
reg7_0625_t<-sum(data.filtrage$T[which( data.filtrage$reg==7 & data.filtrage$jour=="2021-06-25")])


reg8_0102_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-02")])
reg8_0102_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-02")])
reg8_0103_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-03")])
reg8_0103_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-03")])
reg8_0104_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-04")])
reg8_0104_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-04")])
reg8_0105_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-05")])
reg8_0105_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-05")])
reg8_0106_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-06")])
reg8_0106_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-06")])
reg8_0107_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-07")])
reg8_0107_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-07")])
reg8_0108_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-08")])
reg8_0108_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-08")])
reg8_0109_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-09")])
reg8_0109_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-09")])
reg8_0110_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-10")])
reg8_0110_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-10")])
reg8_0111_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-11")])
reg8_0111_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-11")])
reg8_0112_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-12")])
reg8_0112_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-12")])
reg8_0113_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-13")])
reg8_0113_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-13")])
reg8_0114_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-14")])
reg8_0114_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-14")])
reg8_0115_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-15")])
reg8_0115_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-15")])
reg8_0116_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-16")])
reg8_0116_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-16")])
reg8_0117_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-17")])
reg8_0117_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-17")])
reg8_0118_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-18")])
reg8_0118_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-18")])
reg8_0119_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-19")])
reg8_0119_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-19")])
reg8_0120_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-20")])
reg8_0120_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-20")])
reg8_0121_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-21")])
reg8_0121_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-21")])
reg8_0122_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-22")])
reg8_0122_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-22")])
reg8_0123_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-23")])
reg8_0123_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-23")])
reg8_0124_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-24")])
reg8_0124_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-24")])
reg8_0125_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-25")])
reg8_0125_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-25")])
reg8_0126_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-26")])
reg8_0126_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-26")])
reg8_0127_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-27")])
reg8_0127_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-27")])
reg8_0128_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-28")])
reg8_0128_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-28")])
reg8_0129_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-29")])
reg8_0129_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-29")])

reg8_0130_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-30")])
reg8_0130_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-30")])
reg8_0131_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-31")])
reg8_0131_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-31")])




reg8_0201_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-01")])
reg8_0201_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-01")])
reg8_0202_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-02")])
reg8_0202_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-02")])
reg8_0203_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-03")])
reg8_0203_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-03")])
reg8_0204_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-04")])
reg8_0204_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-04")])
reg8_0205_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-05")])
reg8_0205_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-05")])
reg8_0206_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-06")])
reg8_0206_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-06")])
reg8_0207_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-07")])
reg8_0207_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-07")])
reg8_0208_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-08")])
reg8_0208_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-08")])
reg8_0209_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-09")])
reg8_0209_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-09")])
reg8_0210_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-10")])
reg8_0210_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-10")])
reg8_0211_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-11")])
reg8_0211_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-11")])
reg8_0212_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-12")])
reg8_0212_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-12")])
reg8_0213_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-13")])
reg8_0213_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-13")])
reg8_0214_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-14")])
reg8_0214_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-14")])
reg8_0215_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-15")])
reg8_0215_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-15")])
reg8_0216_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-16")])
reg8_0216_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-16")])
reg8_0217_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-17")])
reg8_0217_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-17")])
reg8_0218_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-18")])
reg8_0218_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-18")])
reg8_0219_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-19")])
reg8_0219_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-19")])
reg8_0220_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-20")])
reg8_0220_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-20")])
reg8_0221_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-21")])
reg8_0221_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-21")])
reg8_0222_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-22")])
reg8_0222_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-22")])
reg8_0223_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-23")])
reg8_0223_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-23")])
reg8_0224_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-24")])
reg8_0224_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-24")])
reg8_0225_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-25")])
reg8_0225_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-25")])
reg8_0226_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-26")])
reg8_0226_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-26")])
reg8_0227_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-27")])
reg8_0227_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-27")])
reg8_0228_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-28")])
reg8_0228_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-02-28")])

reg8_0301_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-01")])
reg8_0301_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-01")])

reg8_0302_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-02")])
reg8_0302_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-02")])

reg8_0303_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-03")])
reg8_0303_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-03")])

reg8_0304_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-04")])
reg8_0304_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-04")])

reg8_0305_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-05")])
reg8_0305_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-05")])

reg8_0306_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-06")])
reg8_0306_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-06")])

reg8_0307_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-07")])
reg8_0307_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-07")])


reg8_0308_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-08")])
reg8_0308_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-08")])

reg8_0309_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-09")])
reg8_0309_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-09")])

reg8_0310_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-10")])
reg8_0310_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-10")])

reg8_0311_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-11")])
reg8_0311_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-11")])

reg8_0312_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-12")])
reg8_0312_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-12")])

reg8_0313_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-13")])
reg8_0313_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-13")])

reg8_0314_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-14")])
reg8_0314_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-14")])

reg8_0315_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-15")])
reg8_0315_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-15")])

reg8_0316_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-16")])
reg8_0316_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-16")])

reg8_0317_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-17")])
reg8_0317_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-17")])

reg8_0318_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-18")])
reg8_0318_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-18")])

reg8_0319_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-19")])
reg8_0319_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-19")])

reg8_0320_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-20")])
reg8_0320_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-20")])

reg8_0321_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-21")])
reg8_0321_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-21")])

reg8_0322_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-22")])
reg8_0322_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-22")])

reg8_0323_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-23")])
reg8_0323_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-23")])

reg8_0324_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-24")])
reg8_0324_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-24")])

reg8_0325_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-25")])
reg8_0325_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-25")])

reg8_0326_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-26")])
reg8_0326_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-26")])

reg8_0327_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-27")])
reg8_0327_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-27")])

reg8_0328_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-28")])
reg8_0328_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-28")])

reg8_0329_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-29")])
reg8_0329_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-29")])

reg8_0330_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-30")])
reg8_0330_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-30")])

reg8_0331_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-31")])
reg8_0331_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-03-31")])

reg8_0401_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-01")])
reg8_0401_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-01")])
reg8_0402_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-02")])
reg8_0402_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-02")])
reg8_0403_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-03")])
reg8_0403_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-03")])
reg8_0404_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-04")])
reg8_0404_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-04")])
reg8_0405_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-05")])
reg8_0405_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-05")])
reg8_0406_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-06")])
reg8_0406_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-06")])
reg8_0407_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-07")])
reg8_0407_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-07")])
reg8_0408_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-08")])
reg8_0408_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-08")])
reg8_0409_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-09")])
reg8_0409_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-09")])
reg8_0410_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-10")])
reg8_0410_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-10")])
reg8_0411_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-11")])
reg8_0411_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-11")])
reg8_0412_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-12")])
reg8_0412_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-12")])
reg8_0413_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-13")])
reg8_0413_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-13")])
reg8_0414_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-14")])
reg8_0414_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-14")])
reg8_0415_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-15")])
reg8_0415_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-15")])
reg8_0416_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-16")])
reg8_0416_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-16")])
reg8_0417_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-17")])
reg8_0417_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-17")])
reg8_0418_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-18")])
reg8_0418_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-18")])
reg8_0419_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-19")])
reg8_0419_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-19")])
reg8_0420_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-20")])
reg8_0420_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-20")])
reg8_0421_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-21")])
reg8_0421_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-21")])
reg8_0422_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-22")])
reg8_0422_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-22")])
reg8_0423_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-23")])
reg8_0423_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-23")])
reg8_0424_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-24")])
reg8_0424_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-24")])
reg8_0425_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-25")])
reg8_0425_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-25")])
reg8_0426_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-26")])
reg8_0426_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-26")])
reg8_0427_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-27")])
reg8_0427_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-27")])
reg8_0428_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-28")])
reg8_0428_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-28")])
reg8_0429_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-29")])
reg8_0429_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-29")])
reg8_0430_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-30")])
reg8_0430_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-01-30")])


reg8_0501_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-01")])
reg8_0501_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-01")])

reg8_0502_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-02")])
reg8_0502_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-02")])

reg8_0503_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-03")])
reg8_0503_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-03")])

reg8_0504_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-04")])
reg8_0504_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-04")])

reg8_0505_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-05")])
reg8_0505_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-05")])

reg8_0506_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-06")])
reg8_0506_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-06")])

reg8_0507_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-07")])
reg8_0507_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-07")])

reg8_0508_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-08")])
reg8_0508_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-08")])

reg8_0509_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-09")])
reg8_0509_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-09")])

reg8_0510_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-10")])
reg8_0510_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-10")])

reg8_0511_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-11")])
reg8_0511_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-11")])

reg8_0512_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-12")])
reg8_0512_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-12")])

reg8_0513_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-13")])
reg8_0513_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-13")])

reg8_0514_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-14")])
reg8_0514_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-14")])

reg8_0515_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-15")])
reg8_0515_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-15")])

reg8_0516_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-16")])
reg8_0516_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-16")])

reg8_0517_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-17")])
reg8_0517_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-17")])

reg8_0518_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-18")])
reg8_0518_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-18")])

reg8_0519_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-19")])
reg8_0519_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-19")])

reg8_0520_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-20")])
reg8_0520_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-20")])

reg8_0521_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-21")])
reg8_0521_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-21")])

reg8_0522_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-22")])
reg8_0522_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-22")])

reg8_0523_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-23")])
reg8_0523_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-23")])

reg8_0524_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-24")])
reg8_0524_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-24")])

reg8_0525_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-25")])
reg8_0525_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-25")])

reg8_0526_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-26")])
reg8_0526_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-26")])

reg8_0527_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-27")])
reg8_0527_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-27")])

reg8_0528_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-28")])
reg8_0528_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-28")])

reg8_0529_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-29")])
reg8_0529_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-29")])

reg8_0530_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-30")])
reg8_0530_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-30")])

reg8_0531_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-31")])
reg8_0531_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-05-31")])

reg8_0601_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-01")])
reg8_0601_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-01")])
reg8_0602_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-02")])
reg8_0602_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-02")])
reg8_0603_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-03")])
reg8_0603_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-03")])
reg8_0604_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-04")])
reg8_0604_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-04")])
reg8_0605_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-05")])
reg8_0605_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-05")])
reg8_0606_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-06")])
reg8_0606_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-06")])
reg8_0607_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-07")])
reg8_0607_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-07")])
reg8_0608_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-08")])
reg8_0608_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-08")])
reg8_0609_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-09")])
reg8_0609_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-09")])
reg8_0610_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-10")])
reg8_0610_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-10")])
reg8_0611_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-11")])
reg8_0611_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-11")])
reg8_0612_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-12")])
reg8_0612_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-12")])
reg8_0613_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-13")])
reg8_0613_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-13")])
reg8_0614_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-14")])
reg8_0614_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-14")])
reg8_0615_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-15")])
reg8_0615_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-15")])
reg8_0616_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-16")])
reg8_0616_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-16")])
reg8_0617_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-17")])
reg8_0617_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-17")])
reg8_0618_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-18")])
reg8_0618_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-18")])
reg8_0619_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-19")])
reg8_0619_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-19")])
reg8_0620_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-20")])
reg8_0620_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-20")])
reg8_0621_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-21")])
reg8_0621_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-21")])
reg8_0622_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-22")])
reg8_0622_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-22")])
reg8_0623_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-23")])
reg8_0623_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-23")])
reg8_0624_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-24")])
reg8_0624_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-24")])
reg8_0625_p<-sum(data.filtrage$P[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-25")])
reg8_0625_t<-sum(data.filtrage$T[which( data.filtrage$reg==8 & data.filtrage$jour=="2021-06-25")])


reg9_0102_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-02")])
reg9_0102_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-02")])
reg9_0103_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-03")])
reg9_0103_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-03")])
reg9_0104_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-04")])
reg9_0104_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-04")])
reg9_0105_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-05")])
reg9_0105_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-05")])
reg9_0106_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-06")])
reg9_0106_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-06")])
reg9_0107_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-07")])
reg9_0107_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-07")])
reg9_0108_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-08")])
reg9_0108_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-08")])
reg9_0109_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-09")])
reg9_0109_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-09")])
reg9_0110_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-10")])
reg9_0110_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-10")])
reg9_0111_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-11")])
reg9_0111_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-11")])
reg9_0112_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-12")])
reg9_0112_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-12")])
reg9_0113_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-13")])
reg9_0113_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-13")])
reg9_0114_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-14")])
reg9_0114_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-14")])
reg9_0115_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-15")])
reg9_0115_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-15")])
reg9_0116_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-16")])
reg9_0116_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-16")])
reg9_0117_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-17")])
reg9_0117_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-17")])
reg9_0118_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-18")])
reg9_0118_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-18")])
reg9_0119_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-19")])
reg9_0119_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-19")])
reg9_0120_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-20")])
reg9_0120_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-20")])
reg9_0121_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-21")])
reg9_0121_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-21")])
reg9_0122_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-22")])
reg9_0122_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-22")])
reg9_0123_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-23")])
reg9_0123_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-23")])
reg9_0124_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-24")])
reg9_0124_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-24")])
reg9_0125_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-25")])
reg9_0125_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-25")])
reg9_0126_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-26")])
reg9_0126_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-26")])
reg9_0127_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-27")])
reg9_0127_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-27")])
reg9_0128_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-28")])
reg9_0128_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-28")])
reg9_0129_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-29")])
reg9_0129_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-29")])

reg9_0130_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-30")])
reg9_0130_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-30")])
reg9_0131_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-31")])
reg9_0131_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-31")])




reg9_0201_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-01")])
reg9_0201_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-01")])
reg9_0202_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-02")])
reg9_0202_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-02")])
reg9_0203_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-03")])
reg9_0203_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-03")])
reg9_0204_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-04")])
reg9_0204_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-04")])
reg9_0205_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-05")])
reg9_0205_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-05")])
reg9_0206_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-06")])
reg9_0206_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-06")])
reg9_0207_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-07")])
reg9_0207_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-07")])
reg9_0208_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-08")])
reg9_0208_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-08")])
reg9_0209_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-09")])
reg9_0209_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-09")])
reg9_0210_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-10")])
reg9_0210_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-10")])
reg9_0211_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-11")])
reg9_0211_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-11")])
reg9_0212_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-12")])
reg9_0212_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-12")])
reg9_0213_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-13")])
reg9_0213_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-13")])
reg9_0214_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-14")])
reg9_0214_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-14")])
reg9_0215_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-15")])
reg9_0215_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-15")])
reg9_0216_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-16")])
reg9_0216_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-16")])
reg9_0217_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-17")])
reg9_0217_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-17")])
reg9_0218_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-18")])
reg9_0218_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-18")])
reg9_0219_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-19")])
reg9_0219_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-19")])
reg9_0220_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-20")])
reg9_0220_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-20")])
reg9_0221_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-21")])
reg9_0221_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-21")])
reg9_0222_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-22")])
reg9_0222_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-22")])
reg9_0223_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-23")])
reg9_0223_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-23")])
reg9_0224_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-24")])
reg9_0224_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-24")])
reg9_0225_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-25")])
reg9_0225_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-25")])
reg9_0226_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-26")])
reg9_0226_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-26")])
reg9_0227_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-27")])
reg9_0227_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-27")])
reg9_0228_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-28")])
reg9_0228_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-02-28")])

reg9_0301_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-01")])
reg9_0301_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-01")])

reg9_0302_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-02")])
reg9_0302_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-02")])

reg9_0303_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-03")])
reg9_0303_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-03")])

reg9_0304_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-04")])
reg9_0304_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-04")])

reg9_0305_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-05")])
reg9_0305_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-05")])

reg9_0306_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-06")])
reg9_0306_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-06")])

reg9_0307_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-07")])
reg9_0307_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-07")])


reg9_0308_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-08")])
reg9_0308_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-08")])

reg9_0309_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-09")])
reg9_0309_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-09")])

reg9_0310_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-10")])
reg9_0310_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-10")])

reg9_0311_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-11")])
reg9_0311_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-11")])

reg9_0312_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-12")])
reg9_0312_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-12")])

reg9_0313_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-13")])
reg9_0313_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-13")])

reg9_0314_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-14")])
reg9_0314_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-14")])

reg9_0315_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-15")])
reg9_0315_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-15")])

reg9_0316_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-16")])
reg9_0316_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-16")])

reg9_0317_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-17")])
reg9_0317_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-17")])

reg9_0318_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-18")])
reg9_0318_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-18")])

reg9_0319_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-19")])
reg9_0319_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-19")])

reg9_0320_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-20")])
reg9_0320_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-20")])

reg9_0321_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-21")])
reg9_0321_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-21")])

reg9_0322_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-22")])
reg9_0322_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-22")])

reg9_0323_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-23")])
reg9_0323_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-23")])

reg9_0324_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-24")])
reg9_0324_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-24")])

reg9_0325_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-25")])
reg9_0325_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-25")])

reg9_0326_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-26")])
reg9_0326_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-26")])

reg9_0327_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-27")])
reg9_0327_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-27")])

reg9_0328_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-28")])
reg9_0328_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-28")])

reg9_0329_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-29")])
reg9_0329_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-29")])

reg9_0330_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-30")])
reg9_0330_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-30")])

reg9_0331_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-31")])
reg9_0331_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-03-31")])

reg9_0401_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-01")])
reg9_0401_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-01")])
reg9_0402_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-02")])
reg9_0402_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-02")])
reg9_0403_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-03")])
reg9_0403_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-03")])
reg9_0404_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-04")])
reg9_0404_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-04")])
reg9_0405_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-05")])
reg9_0405_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-05")])
reg9_0406_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-06")])
reg9_0406_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-06")])
reg9_0407_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-07")])
reg9_0407_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-07")])
reg9_0408_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-08")])
reg9_0408_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-08")])
reg9_0409_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-09")])
reg9_0409_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-09")])
reg9_0410_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-10")])
reg9_0410_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-10")])
reg9_0411_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-11")])
reg9_0411_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-11")])
reg9_0412_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-12")])
reg9_0412_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-12")])
reg9_0413_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-13")])
reg9_0413_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-13")])
reg9_0414_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-14")])
reg9_0414_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-14")])
reg9_0415_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-15")])
reg9_0415_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-15")])
reg9_0416_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-16")])
reg9_0416_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-16")])
reg9_0417_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-17")])
reg9_0417_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-17")])
reg9_0418_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-18")])
reg9_0418_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-18")])
reg9_0419_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-19")])
reg9_0419_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-19")])
reg9_0420_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-20")])
reg9_0420_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-20")])
reg9_0421_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-21")])
reg9_0421_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-21")])
reg9_0422_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-22")])
reg9_0422_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-22")])
reg9_0423_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-23")])
reg9_0423_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-23")])
reg9_0424_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-24")])
reg9_0424_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-24")])
reg9_0425_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-25")])
reg9_0425_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-25")])
reg9_0426_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-26")])
reg9_0426_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-26")])
reg9_0427_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-27")])
reg9_0427_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-27")])
reg9_0428_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-28")])
reg9_0428_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-28")])
reg9_0429_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-29")])
reg9_0429_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-29")])
reg9_0430_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-30")])
reg9_0430_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-01-30")])


reg9_0501_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-01")])
reg9_0501_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-01")])

reg9_0502_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-02")])
reg9_0502_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-02")])

reg9_0503_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-03")])
reg9_0503_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-03")])

reg9_0504_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-04")])
reg9_0504_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-04")])

reg9_0505_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-05")])
reg9_0505_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-05")])

reg9_0506_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-06")])
reg9_0506_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-06")])

reg9_0507_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-07")])
reg9_0507_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-07")])

reg9_0508_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-08")])
reg9_0508_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-08")])

reg9_0509_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-09")])
reg9_0509_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-09")])

reg9_0510_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-10")])
reg9_0510_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-10")])

reg9_0511_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-11")])
reg9_0511_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-11")])

reg9_0512_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-12")])
reg9_0512_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-12")])

reg9_0513_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-13")])
reg9_0513_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-13")])

reg9_0514_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-14")])
reg9_0514_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-14")])

reg9_0515_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-15")])
reg9_0515_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-15")])

reg9_0516_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-16")])
reg9_0516_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-16")])

reg9_0517_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-17")])
reg9_0517_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-17")])

reg9_0518_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-18")])
reg9_0518_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-18")])

reg9_0519_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-19")])
reg9_0519_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-19")])

reg9_0520_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-20")])
reg9_0520_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-20")])

reg9_0521_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-21")])
reg9_0521_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-21")])

reg9_0522_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-22")])
reg9_0522_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-22")])

reg9_0523_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-23")])
reg9_0523_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-23")])

reg9_0524_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-24")])
reg9_0524_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-24")])

reg9_0525_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-25")])
reg9_0525_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-25")])

reg9_0526_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-26")])
reg9_0526_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-26")])

reg9_0527_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-27")])
reg9_0527_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-27")])

reg9_0528_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-28")])
reg9_0528_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-28")])

reg9_0529_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-29")])
reg9_0529_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-29")])

reg9_0530_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-30")])
reg9_0530_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-30")])

reg9_0531_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-31")])
reg9_0531_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-05-31")])

reg9_0601_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-01")])
reg9_0601_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-01")])
reg9_0602_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-02")])
reg9_0602_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-02")])
reg9_0603_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-03")])
reg9_0603_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-03")])
reg9_0604_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-04")])
reg9_0604_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-04")])
reg9_0605_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-05")])
reg9_0605_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-05")])
reg9_0606_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-06")])
reg9_0606_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-06")])
reg9_0607_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-07")])
reg9_0607_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-07")])
reg9_0608_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-08")])
reg9_0608_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-08")])
reg9_0609_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-09")])
reg9_0609_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-09")])
reg9_0610_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-10")])
reg9_0610_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-10")])
reg9_0611_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-11")])
reg9_0611_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-11")])
reg9_0612_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-12")])
reg9_0612_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-12")])
reg9_0613_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-13")])
reg9_0613_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-13")])
reg9_0614_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-14")])
reg9_0614_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-14")])
reg9_0615_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-15")])
reg9_0615_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-15")])
reg9_0616_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-16")])
reg9_0616_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-16")])
reg9_0617_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-17")])
reg9_0617_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-17")])
reg9_0618_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-18")])
reg9_0618_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-18")])
reg9_0619_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-19")])
reg9_0619_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-19")])
reg9_0620_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-20")])
reg9_0620_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-20")])
reg9_0621_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-21")])
reg9_0621_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-21")])
reg9_0622_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-22")])
reg9_0622_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-22")])
reg9_0623_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-23")])
reg9_0623_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-23")])
reg9_0624_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-24")])
reg9_0624_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-24")])
reg9_0625_p<-sum(data.filtrage$P[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-25")])
reg9_0625_t<-sum(data.filtrage$T[which( data.filtrage$reg==9 & data.filtrage$jour=="2021-06-25")])


#######
######jours->semaine######
######

######semaine_region

reg01_1<-((reg1_0104_p+reg1_0105_p+reg1_0106_p+reg1_0107_p+reg1_0108_p+reg1_0109_p+reg1_0110_p)/7)/((reg1_0104_t+reg1_0105_t+reg1_0106_t+reg1_0107_t+reg1_0108_t+reg1_0109_t+reg1_0110_t)/7)

reg02_1<-((reg1_0111_p+reg1_0112_p+reg1_0113_p+reg1_0114_p+reg1_0115_p+reg1_0116_p+reg1_0117_p)/7)/((reg1_0111_t+reg1_0112_t+reg1_0113_t+reg1_0114_t+reg1_0115_t+reg1_0116_t+reg1_0117_t)/7)

reg03_1<-((reg1_0118_p+reg1_0119_p+reg1_0120_p+reg1_0121_p+reg1_0122_p+reg1_0123_p+reg1_0124_p)/7)/((reg1_0118_t+reg1_0119_t+reg1_0120_t+reg1_0121_t+reg1_0122_t+reg1_0123_t+reg1_0124_t)/7)

reg04_1<-((reg1_0125_p+reg1_0126_p+reg1_0127_p+reg1_0128_p+reg1_0129_p+reg1_0130_p+reg1_0131_p)/7)/((reg1_0125_t+reg1_0126_t+reg1_0127_t+reg1_0128_t+reg1_0129_t+reg1_0130_t+reg1_0131_t)/7)

reg05_1<-((reg1_0201_p+reg1_0202_p+reg1_0203_p+reg1_0204_p+reg1_0205_p+reg1_0206_p+reg1_0207_p)/7)/((reg1_0201_t+reg1_0202_t+reg1_0203_t+reg1_0204_t+reg1_0205_t+reg1_0206_t+reg1_0207_t)/7)

reg06_1<-((reg1_0208_p+reg1_0209_p+reg1_0210_p+reg1_0211_p+reg1_0212_p+reg1_0213_p+reg1_0214_p)/7)/((reg1_0208_t+reg1_0209_t+reg1_0210_t+reg1_0211_t+reg1_0212_t+reg1_0213_t+reg1_0214_t)/7)

reg07_1<-((reg1_0215_p+reg1_0216_p+reg1_0217_p+reg1_0218_p+reg1_0219_p+reg1_0220_p+reg1_0221_p)/7)/((reg1_0215_t+reg1_0216_t+reg1_0217_t+reg1_0218_t+reg1_0219_t+reg1_0220_t+reg1_0221_t)/7)

reg08_1<-((reg1_0222_p+reg1_0223_p+reg1_0224_p+reg1_0225_p+reg1_0226_p+reg1_0227_p+reg1_0228_p)/7)/((reg1_0222_t+reg1_0223_t+reg1_0224_t+reg1_0225_t+reg1_0226_t+reg1_0227_t+reg1_0228_t)/7)

reg09_1<-((reg1_0301_p+reg1_0302_p+reg1_0303_p+reg1_0304_p+reg1_0305_p+reg1_0306_p+reg1_0307_p)/7)/(( reg1_0301_t+reg1_0302_t+reg1_0303_t+reg1_0304_t+reg1_0305_t+reg1_0306_t+reg1_0307_t)/7)

reg10_1<-((reg1_0308_p+reg1_0309_p+reg1_0310_p+reg1_0311_p+reg1_0312_p+reg1_0313_p+reg1_0314_p)/7)/(( reg1_0308_t+reg1_0309_t+reg1_0310_t+reg1_0311_t+reg1_0312_t+reg1_0313_t+reg1_0314_t)/7)

reg11_1<-((reg1_0315_p+reg1_0316_p+reg1_0317_p+reg1_0318_p+reg1_0319_p+reg1_0320_p+reg1_0321_p)/7)/(( reg1_0315_t+reg1_0316_t+reg1_0317_t+reg1_0318_t+reg1_0319_t+reg1_0320_t+reg1_0321_t)/7)

reg12_1<-((reg1_0322_p+reg1_0323_p+reg1_0324_p+reg1_0325_p+reg1_0326_p+reg1_0327_p+reg1_0328_p)/7)/(( reg1_0322_t+reg1_0323_t+reg1_0324_t+reg1_0325_t+reg1_0326_t+reg1_0327_t+reg1_0328_t)/7)

reg13_1<-((reg1_0329_p+reg1_0330_p+reg1_0331_p+reg1_0401_p+reg1_0402_p+reg1_0403_p+reg1_0404_p)/7)/(( reg1_0329_t+reg1_0330_t+reg1_0331_t+reg1_0401_t+reg1_0402_t+reg1_0403_t+reg1_0404_t)/7)

reg14_1<-((reg1_0405_p+reg1_0406_p+reg1_0407_p+reg1_0408_p+reg1_0409_p+reg1_0410_p+reg1_0411_p)/7)/(( reg1_0405_t+reg1_0406_t+reg1_0407_t+reg1_0408_t+reg1_0409_t+reg1_0410_t+reg1_0411_t)/7)

reg15_1<-((reg1_0412_p+reg1_0413_p+reg1_0414_p+reg1_0415_p+reg1_0416_p+reg1_0417_p+reg1_0418_p)/7)/(( reg1_0412_t+reg1_0413_t+reg1_0414_t+reg1_0415_t+reg1_0416_t+reg1_0417_t+reg1_0418_t)/7)

reg16_1<-((reg1_0419_p+reg1_0420_p+reg1_0421_p+reg1_0422_p+reg1_0423_p+reg1_0424_p+reg1_0425_p)/7)/(( reg1_0419_t+reg1_0420_t+reg1_0421_t+reg1_0422_t+reg1_0423_t+reg1_0424_t+reg1_0425_t)/7)

reg17_1<-((reg1_0426_p+reg1_0427_p+reg1_0428_p+reg1_0429_p+reg1_0430_p+reg1_0501_p+reg1_0502_p)/7)/((reg1_0426_t+reg1_0427_t+reg1_0428_t+reg1_0429_t+reg1_0430_t+reg1_0501_t+reg1_0502_t)/7)

reg18_1<-((reg1_0503_p+reg1_0504_p+reg1_0505_p+reg1_0506_p+reg1_0507_p+reg1_0508_p+reg1_0509_p)/7)/((reg1_0503_t+reg1_0504_t+reg1_0505_t+reg1_0506_t+reg1_0507_t+reg1_0508_t+reg1_0509_t)/7)

reg19_1<-((reg1_0510_p+reg1_0511_p+reg1_0512_p+reg1_0513_p+reg1_0514_p+reg1_0515_p+reg1_0516_p)/7)/((reg1_0510_t+reg1_0511_t+reg1_0512_t+reg1_0513_t+reg1_0514_t+reg1_0515_t+reg1_0516_t)/7)

reg20_1<-((reg1_0517_p+reg1_0518_p+reg1_0519_p+reg1_0520_p+reg1_0521_p+reg1_0522_p+reg1_0523_p)/7)/((reg1_0517_t+reg1_0518_t+reg1_0519_t+reg1_0520_t+reg1_0521_t+reg1_0522_t+reg1_0523_t)/7)

reg21_1<-((reg1_0524_p+reg1_0525_p+reg1_0526_p+reg1_0527_p+reg1_0528_p+reg1_0529_p+reg1_0530_p)/7)/((reg1_0524_t+reg1_0525_t+reg1_0526_t+reg1_0527_t+reg1_0528_t+reg1_0529_t+reg1_0530_t)/7)

reg22_1<-((reg1_0531_p+reg1_0601_p+reg1_0602_p+reg1_0603_p+reg1_0604_p+reg1_0605_p+reg1_0606_p)/7)/((reg1_0531_t+reg1_0601_t+reg1_0602_t+reg1_0603_t+reg1_0604_t+reg1_0605_t+reg1_0606_t)/7)

reg23_1<-((reg1_0607_p+reg1_0608_p+reg1_0609_p+reg1_0610_p+reg1_0611_p+reg1_0612_p+reg1_0613_p)/7)/((reg1_0607_t+reg1_0608_t+reg1_0609_t+reg1_0610_t+reg1_0611_t+reg1_0612_t+reg1_0613_t)/7)

reg24_1<-((reg1_0614_p+reg1_0615_p+reg1_0616_p+reg1_0617_p+reg1_0618_p+reg1_0619_p+reg1_0620_p)/7)/((reg1_0614_t+reg1_0615_t+reg1_0616_t+reg1_0617_t+reg1_0618_t+reg1_0619_t+reg1_0620_t)/7)


reg01_2<-((reg2_0104_p+reg2_0105_p+reg2_0106_p+reg2_0107_p+reg2_0108_p+reg2_0109_p+reg2_0110_p)/7)/((reg2_0104_t+reg2_0105_t+reg2_0106_t+reg2_0107_t+reg2_0108_t+reg2_0109_t+reg2_0110_t)/7)

reg02_2<-((reg2_0111_p+reg2_0112_p+reg2_0113_p+reg2_0114_p+reg2_0115_p+reg2_0116_p+reg2_0117_p)/7)/((reg2_0111_t+reg2_0112_t+reg2_0113_t+reg2_0114_t+reg2_0115_t+reg2_0116_t+reg2_0117_t)/7)

reg03_2<-((reg2_0118_p+reg2_0119_p+reg2_0120_p+reg2_0121_p+reg2_0122_p+reg2_0123_p+reg2_0124_p)/7)/((reg2_0118_t+reg2_0119_t+reg2_0120_t+reg2_0121_t+reg2_0122_t+reg2_0123_t+reg2_0124_t)/7)

reg04_2<-((reg2_0125_p+reg2_0126_p+reg2_0127_p+reg2_0128_p+reg2_0129_p+reg2_0130_p+reg2_0131_p)/7)/((reg2_0125_t+reg2_0126_t+reg2_0127_t+reg2_0128_t+reg2_0129_t+reg2_0130_t+reg2_0131_t)/7)

reg05_2<-((reg2_0201_p+reg2_0202_p+reg2_0203_p+reg2_0204_p+reg2_0205_p+reg2_0206_p+reg2_0207_p)/7)/((reg2_0201_t+reg2_0202_t+reg2_0203_t+reg2_0204_t+reg2_0205_t+reg2_0206_t+reg2_0207_t)/7)

reg06_2<-((reg2_0208_p+reg2_0209_p+reg2_0210_p+reg2_0211_p+reg2_0212_p+reg2_0213_p+reg2_0214_p)/7)/((reg2_0208_t+reg2_0209_t+reg2_0210_t+reg2_0211_t+reg2_0212_t+reg2_0213_t+reg2_0214_t)/7)

reg07_2<-((reg2_0215_p+reg2_0216_p+reg2_0217_p+reg2_0218_p+reg2_0219_p+reg2_0220_p+reg2_0221_p)/7)/((reg2_0215_t+reg2_0216_t+reg2_0217_t+reg2_0218_t+reg2_0219_t+reg2_0220_t+reg2_0221_t)/7)

reg08_2<-((reg2_0222_p+reg2_0223_p+reg2_0224_p+reg2_0225_p+reg2_0226_p+reg2_0227_p+reg2_0228_p)/7)/((reg2_0222_t+reg2_0223_t+reg2_0224_t+reg2_0225_t+reg2_0226_t+reg2_0227_t+reg2_0228_t)/7)

reg09_2<-((reg2_0301_p+reg2_0302_p+reg2_0303_p+reg2_0304_p+reg2_0305_p+reg2_0306_p+reg2_0307_p)/7)/(( reg2_0301_t+reg2_0302_t+reg2_0303_t+reg2_0304_t+reg2_0305_t+reg2_0306_t+reg2_0307_t)/7)

reg10_2<-((reg2_0308_p+reg2_0309_p+reg2_0310_p+reg2_0311_p+reg2_0312_p+reg2_0313_p+reg2_0314_p)/7)/(( reg2_0308_t+reg2_0309_t+reg2_0310_t+reg2_0311_t+reg2_0312_t+reg2_0313_t+reg2_0314_t)/7)

reg11_2<-((reg2_0315_p+reg2_0316_p+reg2_0317_p+reg2_0318_p+reg2_0319_p+reg2_0320_p+reg2_0321_p)/7)/(( reg2_0315_t+reg2_0316_t+reg2_0317_t+reg2_0318_t+reg2_0319_t+reg2_0320_t+reg2_0321_t)/7)

reg12_2<-((reg2_0322_p+reg2_0323_p+reg2_0324_p+reg2_0325_p+reg2_0326_p+reg2_0327_p+reg2_0328_p)/7)/(( reg2_0322_t+reg2_0323_t+reg2_0324_t+reg2_0325_t+reg2_0326_t+reg2_0327_t+reg2_0328_t)/7)

reg13_2<-((reg2_0329_p+reg2_0330_p+reg2_0331_p+reg2_0401_p+reg2_0402_p+reg2_0403_p+reg2_0404_p)/7)/(( reg2_0329_t+reg2_0330_t+reg2_0331_t+reg2_0401_t+reg2_0402_t+reg2_0403_t+reg2_0404_t)/7)

reg14_2<-((reg2_0405_p+reg2_0406_p+reg2_0407_p+reg2_0408_p+reg2_0409_p+reg2_0410_p+reg2_0411_p)/7)/(( reg2_0405_t+reg2_0406_t+reg2_0407_t+reg2_0408_t+reg2_0409_t+reg2_0410_t+reg2_0411_t)/7)

reg15_2<-((reg2_0412_p+reg2_0413_p+reg2_0414_p+reg2_0415_p+reg2_0416_p+reg2_0417_p+reg2_0418_p)/7)/(( reg2_0412_t+reg2_0413_t+reg2_0414_t+reg2_0415_t+reg2_0416_t+reg2_0417_t+reg2_0418_t)/7)

reg16_2<-((reg2_0419_p+reg2_0420_p+reg2_0421_p+reg2_0422_p+reg2_0423_p+reg2_0424_p+reg2_0425_p)/7)/(( reg2_0419_t+reg2_0420_t+reg2_0421_t+reg2_0422_t+reg2_0423_t+reg2_0424_t+reg2_0425_t)/7)

reg17_2<-((reg2_0426_p+reg2_0427_p+reg2_0428_p+reg2_0429_p+reg2_0430_p+reg2_0501_p+reg2_0502_p)/7)/((reg2_0426_t+reg2_0427_t+reg2_0428_t+reg2_0429_t+reg2_0430_t+reg2_0501_t+reg2_0502_t)/7)

reg18_2<-((reg2_0503_p+reg2_0504_p+reg2_0505_p+reg2_0506_p+reg2_0507_p+reg2_0508_p+reg2_0509_p)/7)/((reg2_0503_t+reg2_0504_t+reg2_0505_t+reg2_0506_t+reg2_0507_t+reg2_0508_t+reg2_0509_t)/7)

reg19_2<-((reg2_0510_p+reg2_0511_p+reg2_0512_p+reg2_0513_p+reg2_0514_p+reg2_0515_p+reg2_0516_p)/7)/((reg2_0510_t+reg2_0511_t+reg2_0512_t+reg2_0513_t+reg2_0514_t+reg2_0515_t+reg2_0516_t)/7)

reg20_2<-((reg2_0517_p+reg2_0518_p+reg2_0519_p+reg2_0520_p+reg2_0521_p+reg2_0522_p+reg2_0523_p)/7)/((reg2_0517_t+reg2_0518_t+reg2_0519_t+reg2_0520_t+reg2_0521_t+reg2_0522_t+reg2_0523_t)/7)

reg21_2<-((reg2_0524_p+reg2_0525_p+reg2_0526_p+reg2_0527_p+reg2_0528_p+reg2_0529_p+reg2_0530_p)/7)/((reg2_0524_t+reg2_0525_t+reg2_0526_t+reg2_0527_t+reg2_0528_t+reg2_0529_t+reg2_0530_t)/7)

reg22_2<-((reg2_0531_p+reg2_0601_p+reg2_0602_p+reg2_0603_p+reg2_0604_p+reg2_0605_p+reg2_0606_p)/7)/((reg2_0531_t+reg2_0601_t+reg2_0602_t+reg2_0603_t+reg2_0604_t+reg2_0605_t+reg2_0606_t)/7)

reg23_2<-((reg2_0607_p+reg2_0608_p+reg2_0609_p+reg2_0610_p+reg2_0611_p+reg2_0612_p+reg2_0613_p)/7)/((reg2_0607_t+reg2_0608_t+reg2_0609_t+reg2_0610_t+reg2_0611_t+reg2_0612_t+reg2_0613_t)/7)

reg24_2<-((reg2_0614_p+reg2_0615_p+reg2_0616_p+reg2_0617_p+reg2_0618_p+reg2_0619_p+reg2_0620_p)/7)/((reg2_0614_t+reg2_0615_t+reg2_0616_t+reg2_0617_t+reg2_0618_t+reg2_0619_t+reg2_0620_t)/7)


reg01_3<-((reg3_0104_p+reg3_0105_p+reg3_0106_p+reg3_0107_p+reg3_0108_p+reg3_0109_p+reg3_0110_p)/7)/((reg3_0104_t+reg3_0105_t+reg3_0106_t+reg3_0107_t+reg3_0108_t+reg3_0109_t+reg3_0110_t)/7)

reg02_3<-((reg3_0111_p+reg3_0112_p+reg3_0113_p+reg3_0114_p+reg3_0115_p+reg3_0116_p+reg3_0117_p)/7)/((reg3_0111_t+reg3_0112_t+reg3_0113_t+reg3_0114_t+reg3_0115_t+reg3_0116_t+reg3_0117_t)/7)

reg03_3<-((reg3_0118_p+reg3_0119_p+reg3_0120_p+reg3_0121_p+reg3_0122_p+reg3_0123_p+reg3_0124_p)/7)/((reg3_0118_t+reg3_0119_t+reg3_0120_t+reg3_0121_t+reg3_0122_t+reg3_0123_t+reg3_0124_t)/7)

reg04_3<-((reg3_0125_p+reg3_0126_p+reg3_0127_p+reg3_0128_p+reg3_0129_p+reg3_0130_p+reg3_0131_p)/7)/((reg3_0125_t+reg3_0126_t+reg3_0127_t+reg3_0128_t+reg3_0129_t+reg3_0130_t+reg3_0131_t)/7)

reg05_3<-((reg3_0201_p+reg3_0202_p+reg3_0203_p+reg3_0204_p+reg3_0205_p+reg3_0206_p+reg3_0207_p)/7)/((reg3_0201_t+reg3_0202_t+reg3_0203_t+reg3_0204_t+reg3_0205_t+reg3_0206_t+reg3_0207_t)/7)

reg06_3<-((reg3_0208_p+reg3_0209_p+reg3_0210_p+reg3_0211_p+reg3_0212_p+reg3_0213_p+reg3_0214_p)/7)/((reg3_0208_t+reg3_0209_t+reg3_0210_t+reg3_0211_t+reg3_0212_t+reg3_0213_t+reg3_0214_t)/7)

reg07_3<-((reg3_0215_p+reg3_0216_p+reg3_0217_p+reg3_0218_p+reg3_0219_p+reg3_0220_p+reg3_0221_p)/7)/((reg3_0215_t+reg3_0216_t+reg3_0217_t+reg3_0218_t+reg3_0219_t+reg3_0220_t+reg3_0221_t)/7)

reg08_3<-((reg3_0222_p+reg3_0223_p+reg3_0224_p+reg3_0225_p+reg3_0226_p+reg3_0227_p+reg3_0228_p)/7)/((reg3_0222_t+reg3_0223_t+reg3_0224_t+reg3_0225_t+reg3_0226_t+reg3_0227_t+reg3_0228_t)/7)

reg09_3<-((reg3_0301_p+reg3_0302_p+reg3_0303_p+reg3_0304_p+reg3_0305_p+reg3_0306_p+reg3_0307_p)/7)/(( reg3_0301_t+reg3_0302_t+reg3_0303_t+reg3_0304_t+reg3_0305_t+reg3_0306_t+reg3_0307_t)/7)

reg10_3<-((reg3_0308_p+reg3_0309_p+reg3_0310_p+reg3_0311_p+reg3_0312_p+reg3_0313_p+reg3_0314_p)/7)/(( reg3_0308_t+reg3_0309_t+reg3_0310_t+reg3_0311_t+reg3_0312_t+reg3_0313_t+reg3_0314_t)/7)

reg11_3<-((reg3_0315_p+reg3_0316_p+reg3_0317_p+reg3_0318_p+reg3_0319_p+reg3_0320_p+reg3_0321_p)/7)/(( reg3_0315_t+reg3_0316_t+reg3_0317_t+reg3_0318_t+reg3_0319_t+reg3_0320_t+reg3_0321_t)/7)

reg12_3<-((reg3_0322_p+reg3_0323_p+reg3_0324_p+reg3_0325_p+reg3_0326_p+reg3_0327_p+reg3_0328_p)/7)/(( reg3_0322_t+reg3_0323_t+reg3_0324_t+reg3_0325_t+reg3_0326_t+reg3_0327_t+reg3_0328_t)/7)

reg13_3<-((reg3_0329_p+reg3_0330_p+reg3_0331_p+reg3_0401_p+reg3_0402_p+reg3_0403_p+reg3_0404_p)/7)/(( reg3_0329_t+reg3_0330_t+reg3_0331_t+reg3_0401_t+reg3_0402_t+reg3_0403_t+reg3_0404_t)/7)

reg14_3<-((reg3_0405_p+reg3_0406_p+reg3_0407_p+reg3_0408_p+reg3_0409_p+reg3_0410_p+reg3_0411_p)/7)/(( reg3_0405_t+reg3_0406_t+reg3_0407_t+reg3_0408_t+reg3_0409_t+reg3_0410_t+reg3_0411_t)/7)

reg15_3<-((reg3_0412_p+reg3_0413_p+reg3_0414_p+reg3_0415_p+reg3_0416_p+reg3_0417_p+reg3_0418_p)/7)/(( reg3_0412_t+reg3_0413_t+reg3_0414_t+reg3_0415_t+reg3_0416_t+reg3_0417_t+reg3_0418_t)/7)

reg16_3<-((reg3_0419_p+reg3_0420_p+reg3_0421_p+reg3_0422_p+reg3_0423_p+reg3_0424_p+reg3_0425_p)/7)/(( reg3_0419_t+reg3_0420_t+reg3_0421_t+reg3_0422_t+reg3_0423_t+reg3_0424_t+reg3_0425_t)/7)

reg17_3<-((reg3_0426_p+reg3_0427_p+reg3_0428_p+reg3_0429_p+reg3_0430_p+reg3_0501_p+reg3_0502_p)/7)/((reg3_0426_t+reg3_0427_t+reg3_0428_t+reg3_0429_t+reg3_0430_t+reg3_0501_t+reg3_0502_t)/7)

reg18_3<-((reg3_0503_p+reg3_0504_p+reg3_0505_p+reg3_0506_p+reg3_0507_p+reg3_0508_p+reg3_0509_p)/7)/((reg3_0503_t+reg3_0504_t+reg3_0505_t+reg3_0506_t+reg3_0507_t+reg3_0508_t+reg3_0509_t)/7)

reg19_3<-((reg3_0510_p+reg3_0511_p+reg3_0512_p+reg3_0513_p+reg3_0514_p+reg3_0515_p+reg3_0516_p)/7)/((reg3_0510_t+reg3_0511_t+reg3_0512_t+reg3_0513_t+reg3_0514_t+reg3_0515_t+reg3_0516_t)/7)

reg20_3<-((reg3_0517_p+reg3_0518_p+reg3_0519_p+reg3_0520_p+reg3_0521_p+reg3_0522_p+reg3_0523_p)/7)/((reg3_0517_t+reg3_0518_t+reg3_0519_t+reg3_0520_t+reg3_0521_t+reg3_0522_t+reg3_0523_t)/7)

reg21_3<-((reg3_0524_p+reg3_0525_p+reg3_0526_p+reg3_0527_p+reg3_0528_p+reg3_0529_p+reg3_0530_p)/7)/((reg3_0524_t+reg3_0525_t+reg3_0526_t+reg3_0527_t+reg3_0528_t+reg3_0529_t+reg3_0530_t)/7)

reg22_3<-((reg3_0531_p+reg3_0601_p+reg3_0602_p+reg3_0603_p+reg3_0604_p+reg3_0605_p+reg3_0606_p)/7)/((reg3_0531_t+reg3_0601_t+reg3_0602_t+reg3_0603_t+reg3_0604_t+reg3_0605_t+reg3_0606_t)/7)

reg23_3<-((reg3_0607_p+reg3_0608_p+reg3_0609_p+reg3_0610_p+reg3_0611_p+reg3_0612_p+reg3_0613_p)/7)/((reg3_0607_t+reg3_0608_t+reg3_0609_t+reg3_0610_t+reg3_0611_t+reg3_0612_t+reg3_0613_t)/7)

reg24_3<-((reg3_0614_p+reg3_0615_p+reg3_0616_p+reg3_0617_p+reg3_0618_p+reg3_0619_p+reg3_0620_p)/7)/((reg3_0614_t+reg3_0615_t+reg3_0616_t+reg3_0617_t+reg3_0618_t+reg3_0619_t+reg3_0620_t)/7)


reg01_4<-((reg4_0104_p+reg4_0105_p+reg4_0106_p+reg4_0107_p+reg4_0108_p+reg4_0109_p+reg4_0110_p)/7)/((reg4_0104_t+reg4_0105_t+reg4_0106_t+reg4_0107_t+reg4_0108_t+reg4_0109_t+reg4_0110_t)/7)

reg02_4<-((reg4_0111_p+reg4_0112_p+reg4_0113_p+reg4_0114_p+reg4_0115_p+reg4_0116_p+reg4_0117_p)/7)/((reg4_0111_t+reg4_0112_t+reg4_0113_t+reg4_0114_t+reg4_0115_t+reg4_0116_t+reg4_0117_t)/7)

reg03_4<-((reg4_0118_p+reg4_0119_p+reg4_0120_p+reg4_0121_p+reg4_0122_p+reg4_0123_p+reg4_0124_p)/7)/((reg4_0118_t+reg4_0119_t+reg4_0120_t+reg4_0121_t+reg4_0122_t+reg4_0123_t+reg4_0124_t)/7)

reg04_4<-((reg4_0125_p+reg4_0126_p+reg4_0127_p+reg4_0128_p+reg4_0129_p+reg4_0130_p+reg4_0131_p)/7)/((reg4_0125_t+reg4_0126_t+reg4_0127_t+reg4_0128_t+reg4_0129_t+reg4_0130_t+reg4_0131_t)/7)

reg05_4<-((reg4_0201_p+reg4_0202_p+reg4_0203_p+reg4_0204_p+reg4_0205_p+reg4_0206_p+reg4_0207_p)/7)/((reg4_0201_t+reg4_0202_t+reg4_0203_t+reg4_0204_t+reg4_0205_t+reg4_0206_t+reg4_0207_t)/7)

reg06_4<-((reg4_0208_p+reg4_0209_p+reg4_0210_p+reg4_0211_p+reg4_0212_p+reg4_0213_p+reg4_0214_p)/7)/((reg4_0208_t+reg4_0209_t+reg4_0210_t+reg4_0211_t+reg4_0212_t+reg4_0213_t+reg4_0214_t)/7)

reg07_4<-((reg4_0215_p+reg4_0216_p+reg4_0217_p+reg4_0218_p+reg4_0219_p+reg4_0220_p+reg4_0221_p)/7)/((reg4_0215_t+reg4_0216_t+reg4_0217_t+reg4_0218_t+reg4_0219_t+reg4_0220_t+reg4_0221_t)/7)

reg08_4<-((reg4_0222_p+reg4_0223_p+reg4_0224_p+reg4_0225_p+reg4_0226_p+reg4_0227_p+reg4_0228_p)/7)/((reg4_0222_t+reg4_0223_t+reg4_0224_t+reg4_0225_t+reg4_0226_t+reg4_0227_t+reg4_0228_t)/7)

reg09_4<-((reg4_0301_p+reg4_0302_p+reg4_0303_p+reg4_0304_p+reg4_0305_p+reg4_0306_p+reg4_0307_p)/7)/(( reg4_0301_t+reg4_0302_t+reg4_0303_t+reg4_0304_t+reg4_0305_t+reg4_0306_t+reg4_0307_t)/7)

reg10_4<-((reg4_0308_p+reg4_0309_p+reg4_0310_p+reg4_0311_p+reg4_0312_p+reg4_0313_p+reg4_0314_p)/7)/(( reg4_0308_t+reg4_0309_t+reg4_0310_t+reg4_0311_t+reg4_0312_t+reg4_0313_t+reg4_0314_t)/7)

reg11_4<-((reg4_0315_p+reg4_0316_p+reg4_0317_p+reg4_0318_p+reg4_0319_p+reg4_0320_p+reg4_0321_p)/7)/(( reg4_0315_t+reg4_0316_t+reg4_0317_t+reg4_0318_t+reg4_0319_t+reg4_0320_t+reg4_0321_t)/7)

reg12_4<-((reg4_0322_p+reg4_0323_p+reg4_0324_p+reg4_0325_p+reg4_0326_p+reg4_0327_p+reg4_0328_p)/7)/(( reg4_0322_t+reg4_0323_t+reg4_0324_t+reg4_0325_t+reg4_0326_t+reg4_0327_t+reg4_0328_t)/7)

reg13_4<-((reg4_0329_p+reg4_0330_p+reg4_0331_p+reg4_0401_p+reg4_0402_p+reg4_0403_p+reg4_0404_p)/7)/(( reg4_0329_t+reg4_0330_t+reg4_0331_t+reg4_0401_t+reg4_0402_t+reg4_0403_t+reg4_0404_t)/7)

reg14_4<-((reg4_0405_p+reg4_0406_p+reg4_0407_p+reg4_0408_p+reg4_0409_p+reg4_0410_p+reg4_0411_p)/7)/(( reg4_0405_t+reg4_0406_t+reg4_0407_t+reg4_0408_t+reg4_0409_t+reg4_0410_t+reg4_0411_t)/7)

reg15_4<-((reg4_0412_p+reg4_0413_p+reg4_0414_p+reg4_0415_p+reg4_0416_p+reg4_0417_p+reg4_0418_p)/7)/(( reg4_0412_t+reg4_0413_t+reg4_0414_t+reg4_0415_t+reg4_0416_t+reg4_0417_t+reg4_0418_t)/7)

reg16_4<-((reg4_0419_p+reg4_0420_p+reg4_0421_p+reg4_0422_p+reg4_0423_p+reg4_0424_p+reg4_0425_p)/7)/(( reg4_0419_t+reg4_0420_t+reg4_0421_t+reg4_0422_t+reg4_0423_t+reg4_0424_t+reg4_0425_t)/7)

reg17_4<-((reg4_0426_p+reg4_0427_p+reg4_0428_p+reg4_0429_p+reg4_0430_p+reg4_0501_p+reg4_0502_p)/7)/((reg4_0426_t+reg4_0427_t+reg4_0428_t+reg4_0429_t+reg4_0430_t+reg4_0501_t+reg4_0502_t)/7)

reg18_4<-((reg4_0503_p+reg4_0504_p+reg4_0505_p+reg4_0506_p+reg4_0507_p+reg4_0508_p+reg4_0509_p)/7)/((reg4_0503_t+reg4_0504_t+reg4_0505_t+reg4_0506_t+reg4_0507_t+reg4_0508_t+reg4_0509_t)/7)

reg19_4<-((reg4_0510_p+reg4_0511_p+reg4_0512_p+reg4_0513_p+reg4_0514_p+reg4_0515_p+reg4_0516_p)/7)/((reg4_0510_t+reg4_0511_t+reg4_0512_t+reg4_0513_t+reg4_0514_t+reg4_0515_t+reg4_0516_t)/7)

reg20_4<-((reg4_0517_p+reg4_0518_p+reg4_0519_p+reg4_0520_p+reg4_0521_p+reg4_0522_p+reg4_0523_p)/7)/((reg4_0517_t+reg4_0518_t+reg4_0519_t+reg4_0520_t+reg4_0521_t+reg4_0522_t+reg4_0523_t)/7)

reg21_4<-((reg4_0524_p+reg4_0525_p+reg4_0526_p+reg4_0527_p+reg4_0528_p+reg4_0529_p+reg4_0530_p)/7)/((reg4_0524_t+reg4_0525_t+reg4_0526_t+reg4_0527_t+reg4_0528_t+reg4_0529_t+reg4_0530_t)/7)

reg22_4<-((reg4_0531_p+reg4_0601_p+reg4_0602_p+reg4_0603_p+reg4_0604_p+reg4_0605_p+reg4_0606_p)/7)/((reg4_0531_t+reg4_0601_t+reg4_0602_t+reg4_0603_t+reg4_0604_t+reg4_0605_t+reg4_0606_t)/7)

reg23_4<-((reg4_0607_p+reg4_0608_p+reg4_0609_p+reg4_0610_p+reg4_0611_p+reg4_0612_p+reg4_0613_p)/7)/((reg4_0607_t+reg4_0608_t+reg4_0609_t+reg4_0610_t+reg4_0611_t+reg4_0612_t+reg4_0613_t)/7)

reg24_4<-((reg4_0614_p+reg4_0615_p+reg4_0616_p+reg4_0617_p+reg4_0618_p+reg4_0619_p+reg4_0620_p)/7)/((reg4_0614_t+reg4_0615_t+reg4_0616_t+reg4_0617_t+reg4_0618_t+reg4_0619_t+reg4_0620_t)/7)


reg01_5<-((reg5_0104_p+reg5_0105_p+reg5_0106_p+reg5_0107_p+reg5_0108_p+reg5_0109_p+reg5_0110_p)/7)/((reg5_0104_t+reg5_0105_t+reg5_0106_t+reg5_0107_t+reg5_0108_t+reg5_0109_t+reg5_0110_t)/7)

reg02_5<-((reg5_0111_p+reg5_0112_p+reg5_0113_p+reg5_0114_p+reg5_0115_p+reg5_0116_p+reg5_0117_p)/7)/((reg5_0111_t+reg5_0112_t+reg5_0113_t+reg5_0114_t+reg5_0115_t+reg5_0116_t+reg5_0117_t)/7)

reg03_5<-((reg5_0118_p+reg5_0119_p+reg5_0120_p+reg5_0121_p+reg5_0122_p+reg5_0123_p+reg5_0124_p)/7)/((reg5_0118_t+reg5_0119_t+reg5_0120_t+reg5_0121_t+reg5_0122_t+reg5_0123_t+reg5_0124_t)/7)

reg04_5<-((reg5_0125_p+reg5_0126_p+reg5_0127_p+reg5_0128_p+reg5_0129_p+reg5_0130_p+reg5_0131_p)/7)/((reg5_0125_t+reg5_0126_t+reg5_0127_t+reg5_0128_t+reg5_0129_t+reg5_0130_t+reg5_0131_t)/7)

reg05_5<-((reg5_0201_p+reg5_0202_p+reg5_0203_p+reg5_0204_p+reg5_0205_p+reg5_0206_p+reg5_0207_p)/7)/((reg5_0201_t+reg5_0202_t+reg5_0203_t+reg5_0204_t+reg5_0205_t+reg5_0206_t+reg5_0207_t)/7)

reg06_5<-((reg5_0208_p+reg5_0209_p+reg5_0210_p+reg5_0211_p+reg5_0212_p+reg5_0213_p+reg5_0214_p)/7)/((reg5_0208_t+reg5_0209_t+reg5_0210_t+reg5_0211_t+reg5_0212_t+reg5_0213_t+reg5_0214_t)/7)

reg07_5<-((reg5_0215_p+reg5_0216_p+reg5_0217_p+reg5_0218_p+reg5_0219_p+reg5_0220_p+reg5_0221_p)/7)/((reg5_0215_t+reg5_0216_t+reg5_0217_t+reg5_0218_t+reg5_0219_t+reg5_0220_t+reg5_0221_t)/7)

reg08_5<-((reg5_0222_p+reg5_0223_p+reg5_0224_p+reg5_0225_p+reg5_0226_p+reg5_0227_p+reg5_0228_p)/7)/((reg5_0222_t+reg5_0223_t+reg5_0224_t+reg5_0225_t+reg5_0226_t+reg5_0227_t+reg5_0228_t)/7)

reg09_5<-((reg5_0301_p+reg5_0302_p+reg5_0303_p+reg5_0304_p+reg5_0305_p+reg5_0306_p+reg5_0307_p)/7)/(( reg5_0301_t+reg5_0302_t+reg5_0303_t+reg5_0304_t+reg5_0305_t+reg5_0306_t+reg5_0307_t)/7)

reg10_5<-((reg5_0308_p+reg5_0309_p+reg5_0310_p+reg5_0311_p+reg5_0312_p+reg5_0313_p+reg5_0314_p)/7)/(( reg5_0308_t+reg5_0309_t+reg5_0310_t+reg5_0311_t+reg5_0312_t+reg5_0313_t+reg5_0314_t)/7)

reg11_5<-((reg5_0315_p+reg5_0316_p+reg5_0317_p+reg5_0318_p+reg5_0319_p+reg5_0320_p+reg5_0321_p)/7)/(( reg5_0315_t+reg5_0316_t+reg5_0317_t+reg5_0318_t+reg5_0319_t+reg5_0320_t+reg5_0321_t)/7)

reg12_5<-((reg5_0322_p+reg5_0323_p+reg5_0324_p+reg5_0325_p+reg5_0326_p+reg5_0327_p+reg5_0328_p)/7)/(( reg5_0322_t+reg5_0323_t+reg5_0324_t+reg5_0325_t+reg5_0326_t+reg5_0327_t+reg5_0328_t)/7)

reg13_5<-((reg5_0329_p+reg5_0330_p+reg5_0331_p+reg5_0401_p+reg5_0402_p+reg5_0403_p+reg5_0404_p)/7)/(( reg5_0329_t+reg5_0330_t+reg5_0331_t+reg5_0401_t+reg5_0402_t+reg5_0403_t+reg5_0404_t)/7)

reg14_5<-((reg5_0405_p+reg5_0406_p+reg5_0407_p+reg5_0408_p+reg5_0409_p+reg5_0410_p+reg5_0411_p)/7)/(( reg5_0405_t+reg5_0406_t+reg5_0407_t+reg5_0408_t+reg5_0409_t+reg5_0410_t+reg5_0411_t)/7)

reg15_5<-((reg5_0412_p+reg5_0413_p+reg5_0414_p+reg5_0415_p+reg5_0416_p+reg5_0417_p+reg5_0418_p)/7)/(( reg5_0412_t+reg5_0413_t+reg5_0414_t+reg5_0415_t+reg5_0416_t+reg5_0417_t+reg5_0418_t)/7)

reg16_5<-((reg5_0419_p+reg5_0420_p+reg5_0421_p+reg5_0422_p+reg5_0423_p+reg5_0424_p+reg5_0425_p)/7)/(( reg5_0419_t+reg5_0420_t+reg5_0421_t+reg5_0422_t+reg5_0423_t+reg5_0424_t+reg5_0425_t)/7)

reg17_5<-((reg5_0426_p+reg5_0427_p+reg5_0428_p+reg5_0429_p+reg5_0430_p+reg5_0501_p+reg5_0502_p)/7)/((reg5_0426_t+reg5_0427_t+reg5_0428_t+reg5_0429_t+reg5_0430_t+reg5_0501_t+reg5_0502_t)/7)

reg18_5<-((reg5_0503_p+reg5_0504_p+reg5_0505_p+reg5_0506_p+reg5_0507_p+reg5_0508_p+reg5_0509_p)/7)/((reg5_0503_t+reg5_0504_t+reg5_0505_t+reg5_0506_t+reg5_0507_t+reg5_0508_t+reg5_0509_t)/7)

reg19_5<-((reg5_0510_p+reg5_0511_p+reg5_0512_p+reg5_0513_p+reg5_0514_p+reg5_0515_p+reg5_0516_p)/7)/((reg5_0510_t+reg5_0511_t+reg5_0512_t+reg5_0513_t+reg5_0514_t+reg5_0515_t+reg5_0516_t)/7)

reg20_5<-((reg5_0517_p+reg5_0518_p+reg5_0519_p+reg5_0520_p+reg5_0521_p+reg5_0522_p+reg5_0523_p)/7)/((reg5_0517_t+reg5_0518_t+reg5_0519_t+reg5_0520_t+reg5_0521_t+reg5_0522_t+reg5_0523_t)/7)

reg21_5<-((reg5_0524_p+reg5_0525_p+reg5_0526_p+reg5_0527_p+reg5_0528_p+reg5_0529_p+reg5_0530_p)/7)/((reg5_0524_t+reg5_0525_t+reg5_0526_t+reg5_0527_t+reg5_0528_t+reg5_0529_t+reg5_0530_t)/7)

reg22_5<-((reg5_0531_p+reg5_0601_p+reg5_0602_p+reg5_0603_p+reg5_0604_p+reg5_0605_p+reg5_0606_p)/7)/((reg5_0531_t+reg5_0601_t+reg5_0602_t+reg5_0603_t+reg5_0604_t+reg5_0605_t+reg5_0606_t)/7)

reg23_5<-((reg5_0607_p+reg5_0608_p+reg5_0609_p+reg5_0610_p+reg5_0611_p+reg5_0612_p+reg5_0613_p)/7)/((reg5_0607_t+reg5_0608_t+reg5_0609_t+reg5_0610_t+reg5_0611_t+reg5_0612_t+reg5_0613_t)/7)

reg24_5<-((reg5_0614_p+reg5_0615_p+reg5_0616_p+reg5_0617_p+reg5_0618_p+reg5_0619_p+reg5_0620_p)/7)/((reg5_0614_t+reg5_0615_t+reg5_0616_t+reg5_0617_t+reg5_0618_t+reg5_0619_t+reg5_0620_t)/7)


reg01_6<-((reg6_0104_p+reg6_0105_p+reg6_0106_p+reg6_0107_p+reg6_0108_p+reg6_0109_p+reg6_0110_p)/7)/((reg6_0104_t+reg6_0105_t+reg6_0106_t+reg6_0107_t+reg6_0108_t+reg6_0109_t+reg6_0110_t)/7)

reg02_6<-((reg6_0111_p+reg6_0112_p+reg6_0113_p+reg6_0114_p+reg6_0115_p+reg6_0116_p+reg6_0117_p)/7)/((reg6_0111_t+reg6_0112_t+reg6_0113_t+reg6_0114_t+reg6_0115_t+reg6_0116_t+reg6_0117_t)/7)

reg03_6<-((reg6_0118_p+reg6_0119_p+reg6_0120_p+reg6_0121_p+reg6_0122_p+reg6_0123_p+reg6_0124_p)/7)/((reg6_0118_t+reg6_0119_t+reg6_0120_t+reg6_0121_t+reg6_0122_t+reg6_0123_t+reg6_0124_t)/7)

reg04_6<-((reg6_0125_p+reg6_0126_p+reg6_0127_p+reg6_0128_p+reg6_0129_p+reg6_0130_p+reg6_0131_p)/7)/((reg6_0125_t+reg6_0126_t+reg6_0127_t+reg6_0128_t+reg6_0129_t+reg6_0130_t+reg6_0131_t)/7)

reg05_6<-((reg6_0201_p+reg6_0202_p+reg6_0203_p+reg6_0204_p+reg6_0205_p+reg6_0206_p+reg6_0207_p)/7)/((reg6_0201_t+reg6_0202_t+reg6_0203_t+reg6_0204_t+reg6_0205_t+reg6_0206_t+reg6_0207_t)/7)

reg06_6<-((reg6_0208_p+reg6_0209_p+reg6_0210_p+reg6_0211_p+reg6_0212_p+reg6_0213_p+reg6_0214_p)/7)/((reg6_0208_t+reg6_0209_t+reg6_0210_t+reg6_0211_t+reg6_0212_t+reg6_0213_t+reg6_0214_t)/7)

reg07_6<-((reg6_0215_p+reg6_0216_p+reg6_0217_p+reg6_0218_p+reg6_0219_p+reg6_0220_p+reg6_0221_p)/7)/((reg6_0215_t+reg6_0216_t+reg6_0217_t+reg6_0218_t+reg6_0219_t+reg6_0220_t+reg6_0221_t)/7)

reg08_6<-((reg6_0222_p+reg6_0223_p+reg6_0224_p+reg6_0225_p+reg6_0226_p+reg6_0227_p+reg6_0228_p)/7)/((reg6_0222_t+reg6_0223_t+reg6_0224_t+reg6_0225_t+reg6_0226_t+reg6_0227_t+reg6_0228_t)/7)

reg09_6<-((reg6_0301_p+reg6_0302_p+reg6_0303_p+reg6_0304_p+reg6_0305_p+reg6_0306_p+reg6_0307_p)/7)/(( reg6_0301_t+reg6_0302_t+reg6_0303_t+reg6_0304_t+reg6_0305_t+reg6_0306_t+reg6_0307_t)/7)

reg10_6<-((reg6_0308_p+reg6_0309_p+reg6_0310_p+reg6_0311_p+reg6_0312_p+reg6_0313_p+reg6_0314_p)/7)/(( reg6_0308_t+reg6_0309_t+reg6_0310_t+reg6_0311_t+reg6_0312_t+reg6_0313_t+reg6_0314_t)/7)

reg11_6<-((reg6_0315_p+reg6_0316_p+reg6_0317_p+reg6_0318_p+reg6_0319_p+reg6_0320_p+reg6_0321_p)/7)/(( reg6_0315_t+reg6_0316_t+reg6_0317_t+reg6_0318_t+reg6_0319_t+reg6_0320_t+reg6_0321_t)/7)

reg12_6<-((reg6_0322_p+reg6_0323_p+reg6_0324_p+reg6_0325_p+reg6_0326_p+reg6_0327_p+reg6_0328_p)/7)/(( reg6_0322_t+reg6_0323_t+reg6_0324_t+reg6_0325_t+reg6_0326_t+reg6_0327_t+reg6_0328_t)/7)

reg13_6<-((reg6_0329_p+reg6_0330_p+reg6_0331_p+reg6_0401_p+reg6_0402_p+reg6_0403_p+reg6_0404_p)/7)/(( reg6_0329_t+reg6_0330_t+reg6_0331_t+reg6_0401_t+reg6_0402_t+reg6_0403_t+reg6_0404_t)/7)

reg14_6<-((reg6_0405_p+reg6_0406_p+reg6_0407_p+reg6_0408_p+reg6_0409_p+reg6_0410_p+reg6_0411_p)/7)/(( reg6_0405_t+reg6_0406_t+reg6_0407_t+reg6_0408_t+reg6_0409_t+reg6_0410_t+reg6_0411_t)/7)

reg15_6<-((reg6_0412_p+reg6_0413_p+reg6_0414_p+reg6_0415_p+reg6_0416_p+reg6_0417_p+reg6_0418_p)/7)/(( reg6_0412_t+reg6_0413_t+reg6_0414_t+reg6_0415_t+reg6_0416_t+reg6_0417_t+reg6_0418_t)/7)

reg16_6<-((reg6_0419_p+reg6_0420_p+reg6_0421_p+reg6_0422_p+reg6_0423_p+reg6_0424_p+reg6_0425_p)/7)/(( reg6_0419_t+reg6_0420_t+reg6_0421_t+reg6_0422_t+reg6_0423_t+reg6_0424_t+reg6_0425_t)/7)

reg17_6<-((reg6_0426_p+reg6_0427_p+reg6_0428_p+reg6_0429_p+reg6_0430_p+reg6_0501_p+reg6_0502_p)/7)/((reg6_0426_t+reg6_0427_t+reg6_0428_t+reg6_0429_t+reg6_0430_t+reg6_0501_t+reg6_0502_t)/7)

reg18_6<-((reg6_0503_p+reg6_0504_p+reg6_0505_p+reg6_0506_p+reg6_0507_p+reg6_0508_p+reg6_0509_p)/7)/((reg6_0503_t+reg6_0504_t+reg6_0505_t+reg6_0506_t+reg6_0507_t+reg6_0508_t+reg6_0509_t)/7)

reg19_6<-((reg6_0510_p+reg6_0511_p+reg6_0512_p+reg6_0513_p+reg6_0514_p+reg6_0515_p+reg6_0516_p)/7)/((reg6_0510_t+reg6_0511_t+reg6_0512_t+reg6_0513_t+reg6_0514_t+reg6_0515_t+reg6_0516_t)/7)

reg20_6<-((reg6_0517_p+reg6_0518_p+reg6_0519_p+reg6_0520_p+reg6_0521_p+reg6_0522_p+reg6_0523_p)/7)/((reg6_0517_t+reg6_0518_t+reg6_0519_t+reg6_0520_t+reg6_0521_t+reg6_0522_t+reg6_0523_t)/7)

reg21_6<-((reg6_0524_p+reg6_0525_p+reg6_0526_p+reg6_0527_p+reg6_0528_p+reg6_0529_p+reg6_0530_p)/7)/((reg6_0524_t+reg6_0525_t+reg6_0526_t+reg6_0527_t+reg6_0528_t+reg6_0529_t+reg6_0530_t)/7)

reg22_6<-((reg6_0531_p+reg6_0601_p+reg6_0602_p+reg6_0603_p+reg6_0604_p+reg6_0605_p+reg6_0606_p)/7)/((reg6_0531_t+reg6_0601_t+reg6_0602_t+reg6_0603_t+reg6_0604_t+reg6_0605_t+reg6_0606_t)/7)

reg23_6<-((reg6_0607_p+reg6_0608_p+reg6_0609_p+reg6_0610_p+reg6_0611_p+reg6_0612_p+reg6_0613_p)/7)/((reg6_0607_t+reg6_0608_t+reg6_0609_t+reg6_0610_t+reg6_0611_t+reg6_0612_t+reg6_0613_t)/7)

reg24_6<-((reg6_0614_p+reg6_0615_p+reg6_0616_p+reg6_0617_p+reg6_0618_p+reg6_0619_p+reg6_0620_p)/7)/((reg6_0614_t+reg6_0615_t+reg6_0616_t+reg6_0617_t+reg6_0618_t+reg6_0619_t+reg6_0620_t)/7)


reg01_7<-((reg7_0104_p+reg7_0105_p+reg7_0106_p+reg7_0107_p+reg7_0108_p+reg7_0109_p+reg7_0110_p)/7)/((reg7_0104_t+reg7_0105_t+reg7_0106_t+reg7_0107_t+reg7_0108_t+reg7_0109_t+reg7_0110_t)/7)

reg02_7<-((reg7_0111_p+reg7_0112_p+reg7_0113_p+reg7_0114_p+reg7_0115_p+reg7_0116_p+reg7_0117_p)/7)/((reg7_0111_t+reg7_0112_t+reg7_0113_t+reg7_0114_t+reg7_0115_t+reg7_0116_t+reg7_0117_t)/7)

reg03_7<-((reg7_0118_p+reg7_0119_p+reg7_0120_p+reg7_0121_p+reg7_0122_p+reg7_0123_p+reg7_0124_p)/7)/((reg7_0118_t+reg7_0119_t+reg7_0120_t+reg7_0121_t+reg7_0122_t+reg7_0123_t+reg7_0124_t)/7)

reg04_7<-((reg7_0125_p+reg7_0126_p+reg7_0127_p+reg7_0128_p+reg7_0129_p+reg7_0130_p+reg7_0131_p)/7)/((reg7_0125_t+reg7_0126_t+reg7_0127_t+reg7_0128_t+reg7_0129_t+reg7_0130_t+reg7_0131_t)/7)

reg05_7<-((reg7_0201_p+reg7_0202_p+reg7_0203_p+reg7_0204_p+reg7_0205_p+reg7_0206_p+reg7_0207_p)/7)/((reg7_0201_t+reg7_0202_t+reg7_0203_t+reg7_0204_t+reg7_0205_t+reg7_0206_t+reg7_0207_t)/7)

reg06_7<-((reg7_0208_p+reg7_0209_p+reg7_0210_p+reg7_0211_p+reg7_0212_p+reg7_0213_p+reg7_0214_p)/7)/((reg7_0208_t+reg7_0209_t+reg7_0210_t+reg7_0211_t+reg7_0212_t+reg7_0213_t+reg7_0214_t)/7)

reg07_7<-((reg7_0215_p+reg7_0216_p+reg7_0217_p+reg7_0218_p+reg7_0219_p+reg7_0220_p+reg7_0221_p)/7)/((reg7_0215_t+reg7_0216_t+reg7_0217_t+reg7_0218_t+reg7_0219_t+reg7_0220_t+reg7_0221_t)/7)

reg08_7<-((reg7_0222_p+reg7_0223_p+reg7_0224_p+reg7_0225_p+reg7_0226_p+reg7_0227_p+reg7_0228_p)/7)/((reg7_0222_t+reg7_0223_t+reg7_0224_t+reg7_0225_t+reg7_0226_t+reg7_0227_t+reg7_0228_t)/7)

reg09_7<-((reg7_0301_p+reg7_0302_p+reg7_0303_p+reg7_0304_p+reg7_0305_p+reg7_0306_p+reg7_0307_p)/7)/(( reg7_0301_t+reg7_0302_t+reg7_0303_t+reg7_0304_t+reg7_0305_t+reg7_0306_t+reg7_0307_t)/7)

reg10_7<-((reg7_0308_p+reg7_0309_p+reg7_0310_p+reg7_0311_p+reg7_0312_p+reg7_0313_p+reg7_0314_p)/7)/(( reg7_0308_t+reg7_0309_t+reg7_0310_t+reg7_0311_t+reg7_0312_t+reg7_0313_t+reg7_0314_t)/7)

reg11_7<-((reg7_0315_p+reg7_0316_p+reg7_0317_p+reg7_0318_p+reg7_0319_p+reg7_0320_p+reg7_0321_p)/7)/(( reg7_0315_t+reg7_0316_t+reg7_0317_t+reg7_0318_t+reg7_0319_t+reg7_0320_t+reg7_0321_t)/7)

reg12_7<-((reg7_0322_p+reg7_0323_p+reg7_0324_p+reg7_0325_p+reg7_0326_p+reg7_0327_p+reg7_0328_p)/7)/(( reg7_0322_t+reg7_0323_t+reg7_0324_t+reg7_0325_t+reg7_0326_t+reg7_0327_t+reg7_0328_t)/7)

reg13_7<-((reg7_0329_p+reg7_0330_p+reg7_0331_p+reg7_0401_p+reg7_0402_p+reg7_0403_p+reg7_0404_p)/7)/(( reg7_0329_t+reg7_0330_t+reg7_0331_t+reg7_0401_t+reg7_0402_t+reg7_0403_t+reg7_0404_t)/7)

reg14_7<-((reg7_0405_p+reg7_0406_p+reg7_0407_p+reg7_0408_p+reg7_0409_p+reg7_0410_p+reg7_0411_p)/7)/(( reg7_0405_t+reg7_0406_t+reg7_0407_t+reg7_0408_t+reg7_0409_t+reg7_0410_t+reg7_0411_t)/7)

reg15_7<-((reg7_0412_p+reg7_0413_p+reg7_0414_p+reg7_0415_p+reg7_0416_p+reg7_0417_p+reg7_0418_p)/7)/(( reg7_0412_t+reg7_0413_t+reg7_0414_t+reg7_0415_t+reg7_0416_t+reg7_0417_t+reg7_0418_t)/7)

reg16_7<-((reg7_0419_p+reg7_0420_p+reg7_0421_p+reg7_0422_p+reg7_0423_p+reg7_0424_p+reg7_0425_p)/7)/(( reg7_0419_t+reg7_0420_t+reg7_0421_t+reg7_0422_t+reg7_0423_t+reg7_0424_t+reg7_0425_t)/7)

reg17_7<-((reg7_0426_p+reg7_0427_p+reg7_0428_p+reg7_0429_p+reg7_0430_p+reg7_0501_p+reg7_0502_p)/7)/((reg7_0426_t+reg7_0427_t+reg7_0428_t+reg7_0429_t+reg7_0430_t+reg7_0501_t+reg7_0502_t)/7)

reg18_7<-((reg7_0503_p+reg7_0504_p+reg7_0505_p+reg7_0506_p+reg7_0507_p+reg7_0508_p+reg7_0509_p)/7)/((reg7_0503_t+reg7_0504_t+reg7_0505_t+reg7_0506_t+reg7_0507_t+reg7_0508_t+reg7_0509_t)/7)

reg19_7<-((reg7_0510_p+reg7_0511_p+reg7_0512_p+reg7_0513_p+reg7_0514_p+reg7_0515_p+reg7_0516_p)/7)/((reg7_0510_t+reg7_0511_t+reg7_0512_t+reg7_0513_t+reg7_0514_t+reg7_0515_t+reg7_0516_t)/7)

reg20_7<-((reg7_0517_p+reg7_0518_p+reg7_0519_p+reg7_0520_p+reg7_0521_p+reg7_0522_p+reg7_0523_p)/7)/((reg7_0517_t+reg7_0518_t+reg7_0519_t+reg7_0520_t+reg7_0521_t+reg7_0522_t+reg7_0523_t)/7)

reg21_7<-((reg7_0524_p+reg7_0525_p+reg7_0526_p+reg7_0527_p+reg7_0528_p+reg7_0529_p+reg7_0530_p)/7)/((reg7_0524_t+reg7_0525_t+reg7_0526_t+reg7_0527_t+reg7_0528_t+reg7_0529_t+reg7_0530_t)/7)

reg22_7<-((reg7_0531_p+reg7_0601_p+reg7_0602_p+reg7_0603_p+reg7_0604_p+reg7_0605_p+reg7_0606_p)/7)/((reg7_0531_t+reg7_0601_t+reg7_0602_t+reg7_0603_t+reg7_0604_t+reg7_0605_t+reg7_0606_t)/7)

reg23_7<-((reg7_0607_p+reg7_0608_p+reg7_0609_p+reg7_0610_p+reg7_0611_p+reg7_0612_p+reg7_0613_p)/7)/((reg7_0607_t+reg7_0608_t+reg7_0609_t+reg7_0610_t+reg7_0611_t+reg7_0612_t+reg7_0613_t)/7)

reg24_7<-((reg7_0614_p+reg7_0615_p+reg7_0616_p+reg7_0617_p+reg7_0618_p+reg7_0619_p+reg7_0620_p)/7)/((reg7_0614_t+reg7_0615_t+reg7_0616_t+reg7_0617_t+reg7_0618_t+reg7_0619_t+reg7_0620_t)/7)


reg01_8<-((reg8_0104_p+reg8_0105_p+reg8_0106_p+reg8_0107_p+reg8_0108_p+reg8_0109_p+reg8_0110_p)/7)/((reg8_0104_t+reg8_0105_t+reg8_0106_t+reg8_0107_t+reg8_0108_t+reg8_0109_t+reg8_0110_t)/7)

reg02_8<-((reg8_0111_p+reg8_0112_p+reg8_0113_p+reg8_0114_p+reg8_0115_p+reg8_0116_p+reg8_0117_p)/7)/((reg8_0111_t+reg8_0112_t+reg8_0113_t+reg8_0114_t+reg8_0115_t+reg8_0116_t+reg8_0117_t)/7)

reg03_8<-((reg8_0118_p+reg8_0119_p+reg8_0120_p+reg8_0121_p+reg8_0122_p+reg8_0123_p+reg8_0124_p)/7)/((reg8_0118_t+reg8_0119_t+reg8_0120_t+reg8_0121_t+reg8_0122_t+reg8_0123_t+reg8_0124_t)/7)

reg04_8<-((reg8_0125_p+reg8_0126_p+reg8_0127_p+reg8_0128_p+reg8_0129_p+reg8_0130_p+reg8_0131_p)/7)/((reg8_0125_t+reg8_0126_t+reg8_0127_t+reg8_0128_t+reg8_0129_t+reg8_0130_t+reg8_0131_t)/7)

reg05_8<-((reg8_0201_p+reg8_0202_p+reg8_0203_p+reg8_0204_p+reg8_0205_p+reg8_0206_p+reg8_0207_p)/7)/((reg8_0201_t+reg8_0202_t+reg8_0203_t+reg8_0204_t+reg8_0205_t+reg8_0206_t+reg8_0207_t)/7)

reg06_8<-((reg8_0208_p+reg8_0209_p+reg8_0210_p+reg8_0211_p+reg8_0212_p+reg8_0213_p+reg8_0214_p)/7)/((reg8_0208_t+reg8_0209_t+reg8_0210_t+reg8_0211_t+reg8_0212_t+reg8_0213_t+reg8_0214_t)/7)

reg07_8<-((reg8_0215_p+reg8_0216_p+reg8_0217_p+reg8_0218_p+reg8_0219_p+reg8_0220_p+reg8_0221_p)/7)/((reg8_0215_t+reg8_0216_t+reg8_0217_t+reg8_0218_t+reg8_0219_t+reg8_0220_t+reg8_0221_t)/7)

reg08_8<-((reg8_0222_p+reg8_0223_p+reg8_0224_p+reg8_0225_p+reg8_0226_p+reg8_0227_p+reg8_0228_p)/7)/((reg8_0222_t+reg8_0223_t+reg8_0224_t+reg8_0225_t+reg8_0226_t+reg8_0227_t+reg8_0228_t)/7)

reg09_8<-((reg8_0301_p+reg8_0302_p+reg8_0303_p+reg8_0304_p+reg8_0305_p+reg8_0306_p+reg8_0307_p)/7)/(( reg8_0301_t+reg8_0302_t+reg8_0303_t+reg8_0304_t+reg8_0305_t+reg8_0306_t+reg8_0307_t)/7)

reg10_8<-((reg8_0308_p+reg8_0309_p+reg8_0310_p+reg8_0311_p+reg8_0312_p+reg8_0313_p+reg8_0314_p)/7)/(( reg8_0308_t+reg8_0309_t+reg8_0310_t+reg8_0311_t+reg8_0312_t+reg8_0313_t+reg8_0314_t)/7)

reg11_8<-((reg8_0315_p+reg8_0316_p+reg8_0317_p+reg8_0318_p+reg8_0319_p+reg8_0320_p+reg8_0321_p)/7)/(( reg8_0315_t+reg8_0316_t+reg8_0317_t+reg8_0318_t+reg8_0319_t+reg8_0320_t+reg8_0321_t)/7)

reg12_8<-((reg8_0322_p+reg8_0323_p+reg8_0324_p+reg8_0325_p+reg8_0326_p+reg8_0327_p+reg8_0328_p)/7)/(( reg8_0322_t+reg8_0323_t+reg8_0324_t+reg8_0325_t+reg8_0326_t+reg8_0327_t+reg8_0328_t)/7)

reg13_8<-((reg8_0329_p+reg8_0330_p+reg8_0331_p+reg8_0401_p+reg8_0402_p+reg8_0403_p+reg8_0404_p)/7)/(( reg8_0329_t+reg8_0330_t+reg8_0331_t+reg8_0401_t+reg8_0402_t+reg8_0403_t+reg8_0404_t)/7)

reg14_8<-((reg8_0405_p+reg8_0406_p+reg8_0407_p+reg8_0408_p+reg8_0409_p+reg8_0410_p+reg8_0411_p)/7)/(( reg8_0405_t+reg8_0406_t+reg8_0407_t+reg8_0408_t+reg8_0409_t+reg8_0410_t+reg8_0411_t)/7)

reg15_8<-((reg8_0412_p+reg8_0413_p+reg8_0414_p+reg8_0415_p+reg8_0416_p+reg8_0417_p+reg8_0418_p)/7)/(( reg8_0412_t+reg8_0413_t+reg8_0414_t+reg8_0415_t+reg8_0416_t+reg8_0417_t+reg8_0418_t)/7)

reg16_8<-((reg8_0419_p+reg8_0420_p+reg8_0421_p+reg8_0422_p+reg8_0423_p+reg8_0424_p+reg8_0425_p)/7)/(( reg8_0419_t+reg8_0420_t+reg8_0421_t+reg8_0422_t+reg8_0423_t+reg8_0424_t+reg8_0425_t)/7)

reg17_8<-((reg8_0426_p+reg8_0427_p+reg8_0428_p+reg8_0429_p+reg8_0430_p+reg8_0501_p+reg8_0502_p)/7)/((reg8_0426_t+reg8_0427_t+reg8_0428_t+reg8_0429_t+reg8_0430_t+reg8_0501_t+reg8_0502_t)/7)

reg18_8<-((reg8_0503_p+reg8_0504_p+reg8_0505_p+reg8_0506_p+reg8_0507_p+reg8_0508_p+reg8_0509_p)/7)/((reg8_0503_t+reg8_0504_t+reg8_0505_t+reg8_0506_t+reg8_0507_t+reg8_0508_t+reg8_0509_t)/7)

reg19_8<-((reg8_0510_p+reg8_0511_p+reg8_0512_p+reg8_0513_p+reg8_0514_p+reg8_0515_p+reg8_0516_p)/7)/((reg8_0510_t+reg8_0511_t+reg8_0512_t+reg8_0513_t+reg8_0514_t+reg8_0515_t+reg8_0516_t)/7)

reg20_8<-((reg8_0517_p+reg8_0518_p+reg8_0519_p+reg8_0520_p+reg8_0521_p+reg8_0522_p+reg8_0523_p)/7)/((reg8_0517_t+reg8_0518_t+reg8_0519_t+reg8_0520_t+reg8_0521_t+reg8_0522_t+reg8_0523_t)/7)

reg21_8<-((reg8_0524_p+reg8_0525_p+reg8_0526_p+reg8_0527_p+reg8_0528_p+reg8_0529_p+reg8_0530_p)/7)/((reg8_0524_t+reg8_0525_t+reg8_0526_t+reg8_0527_t+reg8_0528_t+reg8_0529_t+reg8_0530_t)/7)

reg22_8<-((reg8_0531_p+reg8_0601_p+reg8_0602_p+reg8_0603_p+reg8_0604_p+reg8_0605_p+reg8_0606_p)/7)/((reg8_0531_t+reg8_0601_t+reg8_0602_t+reg8_0603_t+reg8_0604_t+reg8_0605_t+reg8_0606_t)/7)

reg23_8<-((reg8_0607_p+reg8_0608_p+reg8_0609_p+reg8_0610_p+reg8_0611_p+reg8_0612_p+reg8_0613_p)/7)/((reg8_0607_t+reg8_0608_t+reg8_0609_t+reg8_0610_t+reg8_0611_t+reg8_0612_t+reg8_0613_t)/7)

reg24_8<-((reg8_0614_p+reg8_0615_p+reg8_0616_p+reg8_0617_p+reg8_0618_p+reg8_0619_p+reg8_0620_p)/7)/((reg8_0614_t+reg8_0615_t+reg8_0616_t+reg8_0617_t+reg8_0618_t+reg8_0619_t+reg8_0620_t)/7)


reg01_9<-((reg9_0104_p+reg9_0105_p+reg9_0106_p+reg9_0107_p+reg9_0108_p+reg9_0109_p+reg9_0110_p)/7)/((reg9_0104_t+reg9_0105_t+reg9_0106_t+reg9_0107_t+reg9_0108_t+reg9_0109_t+reg9_0110_t)/7)

reg02_9<-((reg9_0111_p+reg9_0112_p+reg9_0113_p+reg9_0114_p+reg9_0115_p+reg9_0116_p+reg9_0117_p)/7)/((reg9_0111_t+reg9_0112_t+reg9_0113_t+reg9_0114_t+reg9_0115_t+reg9_0116_t+reg9_0117_t)/7)

reg03_9<-((reg9_0118_p+reg9_0119_p+reg9_0120_p+reg9_0121_p+reg9_0122_p+reg9_0123_p+reg9_0124_p)/7)/((reg9_0118_t+reg9_0119_t+reg9_0120_t+reg9_0121_t+reg9_0122_t+reg9_0123_t+reg9_0124_t)/7)

reg04_9<-((reg9_0125_p+reg9_0126_p+reg9_0127_p+reg9_0128_p+reg9_0129_p+reg9_0130_p+reg9_0131_p)/7)/((reg9_0125_t+reg9_0126_t+reg9_0127_t+reg9_0128_t+reg9_0129_t+reg9_0130_t+reg9_0131_t)/7)

reg05_9<-((reg9_0201_p+reg9_0202_p+reg9_0203_p+reg9_0204_p+reg9_0205_p+reg9_0206_p+reg9_0207_p)/7)/((reg9_0201_t+reg9_0202_t+reg9_0203_t+reg9_0204_t+reg9_0205_t+reg9_0206_t+reg9_0207_t)/7)

reg06_9<-((reg9_0208_p+reg9_0209_p+reg9_0210_p+reg9_0211_p+reg9_0212_p+reg9_0213_p+reg9_0214_p)/7)/((reg9_0208_t+reg9_0209_t+reg9_0210_t+reg9_0211_t+reg9_0212_t+reg9_0213_t+reg9_0214_t)/7)

reg07_9<-((reg9_0215_p+reg9_0216_p+reg9_0217_p+reg9_0218_p+reg9_0219_p+reg9_0220_p+reg9_0221_p)/7)/((reg9_0215_t+reg9_0216_t+reg9_0217_t+reg9_0218_t+reg9_0219_t+reg9_0220_t+reg9_0221_t)/7)

reg08_9<-((reg9_0222_p+reg9_0223_p+reg9_0224_p+reg9_0225_p+reg9_0226_p+reg9_0227_p+reg9_0228_p)/7)/((reg9_0222_t+reg9_0223_t+reg9_0224_t+reg9_0225_t+reg9_0226_t+reg9_0227_t+reg9_0228_t)/7)

reg09_9<-((reg9_0301_p+reg9_0302_p+reg9_0303_p+reg9_0304_p+reg9_0305_p+reg9_0306_p+reg9_0307_p)/7)/(( reg9_0301_t+reg9_0302_t+reg9_0303_t+reg9_0304_t+reg9_0305_t+reg9_0306_t+reg9_0307_t)/7)

reg10_9<-((reg9_0308_p+reg9_0309_p+reg9_0310_p+reg9_0311_p+reg9_0312_p+reg9_0313_p+reg9_0314_p)/7)/(( reg9_0308_t+reg9_0309_t+reg9_0310_t+reg9_0311_t+reg9_0312_t+reg9_0313_t+reg9_0314_t)/7)

reg11_9<-((reg9_0315_p+reg9_0316_p+reg9_0317_p+reg9_0318_p+reg9_0319_p+reg9_0320_p+reg9_0321_p)/7)/(( reg9_0315_t+reg9_0316_t+reg9_0317_t+reg9_0318_t+reg9_0319_t+reg9_0320_t+reg9_0321_t)/7)

reg12_9<-((reg9_0322_p+reg9_0323_p+reg9_0324_p+reg9_0325_p+reg9_0326_p+reg9_0327_p+reg9_0328_p)/7)/(( reg9_0322_t+reg9_0323_t+reg9_0324_t+reg9_0325_t+reg9_0326_t+reg9_0327_t+reg9_0328_t)/7)

reg13_9<-((reg9_0329_p+reg9_0330_p+reg9_0331_p+reg9_0401_p+reg9_0402_p+reg9_0403_p+reg9_0404_p)/7)/(( reg9_0329_t+reg9_0330_t+reg9_0331_t+reg9_0401_t+reg9_0402_t+reg9_0403_t+reg9_0404_t)/7)

reg14_9<-((reg9_0405_p+reg9_0406_p+reg9_0407_p+reg9_0408_p+reg9_0409_p+reg9_0410_p+reg9_0411_p)/7)/(( reg9_0405_t+reg9_0406_t+reg9_0407_t+reg9_0408_t+reg9_0409_t+reg9_0410_t+reg9_0411_t)/7)

reg15_9<-((reg9_0412_p+reg9_0413_p+reg9_0414_p+reg9_0415_p+reg9_0416_p+reg9_0417_p+reg9_0418_p)/7)/(( reg9_0412_t+reg9_0413_t+reg9_0414_t+reg9_0415_t+reg9_0416_t+reg9_0417_t+reg9_0418_t)/7)

reg16_9<-((reg9_0419_p+reg9_0420_p+reg9_0421_p+reg9_0422_p+reg9_0423_p+reg9_0424_p+reg9_0425_p)/7)/(( reg9_0419_t+reg9_0420_t+reg9_0421_t+reg9_0422_t+reg9_0423_t+reg9_0424_t+reg9_0425_t)/7)

reg17_9<-((reg9_0426_p+reg9_0427_p+reg9_0428_p+reg9_0429_p+reg9_0430_p+reg9_0501_p+reg9_0502_p)/7)/((reg9_0426_t+reg9_0427_t+reg9_0428_t+reg9_0429_t+reg9_0430_t+reg9_0501_t+reg9_0502_t)/7)

reg18_9<-((reg9_0503_p+reg9_0504_p+reg9_0505_p+reg9_0506_p+reg9_0507_p+reg9_0508_p+reg9_0509_p)/7)/((reg9_0503_t+reg9_0504_t+reg9_0505_t+reg9_0506_t+reg9_0507_t+reg9_0508_t+reg9_0509_t)/7)

reg19_9<-((reg9_0510_p+reg9_0511_p+reg9_0512_p+reg9_0513_p+reg9_0514_p+reg9_0515_p+reg9_0516_p)/7)/((reg9_0510_t+reg9_0511_t+reg9_0512_t+reg9_0513_t+reg9_0514_t+reg9_0515_t+reg9_0516_t)/7)

reg20_9<-((reg9_0517_p+reg9_0518_p+reg9_0519_p+reg9_0520_p+reg9_0521_p+reg9_0522_p+reg9_0523_p)/7)/((reg9_0517_t+reg9_0518_t+reg9_0519_t+reg9_0520_t+reg9_0521_t+reg9_0522_t+reg9_0523_t)/7)

reg21_9<-((reg9_0524_p+reg9_0525_p+reg9_0526_p+reg9_0527_p+reg9_0528_p+reg9_0529_p+reg9_0530_p)/7)/((reg9_0524_t+reg9_0525_t+reg9_0526_t+reg9_0527_t+reg9_0528_t+reg9_0529_t+reg9_0530_t)/7)

reg22_9<-((reg9_0531_p+reg9_0601_p+reg9_0602_p+reg9_0603_p+reg9_0604_p+reg9_0605_p+reg9_0606_p)/7)/((reg9_0531_t+reg9_0601_t+reg9_0602_t+reg9_0603_t+reg9_0604_t+reg9_0605_t+reg9_0606_t)/7)

reg23_9<-((reg9_0607_p+reg9_0608_p+reg9_0609_p+reg9_0610_p+reg9_0611_p+reg9_0612_p+reg9_0613_p)/7)/((reg9_0607_t+reg9_0608_t+reg9_0609_t+reg9_0610_t+reg9_0611_t+reg9_0612_t+reg9_0613_t)/7)

reg24_9<-((reg9_0614_p+reg9_0615_p+reg9_0616_p+reg9_0617_p+reg9_0618_p+reg9_0619_p+reg9_0620_p)/7)/((reg9_0614_t+reg9_0615_t+reg9_0616_t+reg9_0617_t+reg9_0618_t+reg9_0619_t+reg9_0620_t)/7)



reg1<-c(reg01_1,reg02_1,reg03_1,reg04_1,reg05_1,reg06_1,reg07_1,reg08_1,reg09_1,reg10_1,reg11_1,reg12_1,reg13_1,reg14_1,reg15_1,reg16_1,reg17_1,reg18_1,reg19_1,reg20_1,reg21_1,reg22_1,reg23_1,reg24_1)

reg2<-c(reg01_2,reg02_2,reg03_2,reg04_2,reg05_2,reg06_2,reg07_2,reg08_2,reg09_2,reg10_2,reg11_2,reg12_2,reg13_2,reg14_2,reg15_2,reg16_2,reg17_2,reg18_2,reg19_2,reg20_2,reg21_2,reg22_2,reg23_2,reg24_2)

reg3<-c(reg01_3,reg02_3,reg03_3,reg04_3,reg05_3,reg06_3,reg07_3,reg08_3,reg09_3,reg10_3,reg11_3,reg12_3,reg13_3,reg14_3,reg15_3,reg16_3,reg17_3,reg18_3,reg19_3,reg20_3,reg21_3,reg22_3,reg23_3,reg24_3)

reg4<-c(reg01_4,reg02_4,reg03_4,reg04_4,reg05_4,reg06_4,reg07_4,reg08_4,reg09_4,reg10_4,reg11_4,reg12_4,reg13_4,reg14_4,reg15_4,reg16_4,reg17_4,reg18_4,reg19_4,reg20_4,reg21_4,reg22_4,reg23_4,reg24_4)

reg5<-c(reg01_5,reg02_5,reg03_5,reg04_5,reg05_5,reg06_5,reg07_5,reg08_5,reg09_5,reg10_5,reg11_5,reg12_5,reg13_5,reg14_5,reg15_5,reg16_5,reg17_5,reg18_5,reg19_5,reg20_5,reg21_5,reg22_5,reg23_5,reg24_5)

reg6<-c(reg01_6,reg02_6,reg03_6,reg04_6,reg05_6,reg06_6,reg07_6,reg08_6,reg09_6,reg10_6,reg11_6,reg12_6,reg13_6,reg14_6,reg15_6,reg16_6,reg17_6,reg18_6,reg19_6,reg20_6,reg21_6,reg22_6,reg23_6,reg24_6)

reg7<-c(reg01_7,reg02_7,reg03_7,reg04_7,reg05_7,reg06_7,reg07_7,reg08_7,reg09_7,reg10_7,reg11_7,reg12_7,reg13_7,reg14_7,reg15_7,reg16_7,reg17_7,reg18_7,reg19_7,reg20_7,reg21_7,reg22_7,reg23_7,reg24_7)

reg8<-c(reg01_8,reg02_8,reg03_8,reg04_8,reg05_8,reg06_8,reg07_8,reg08_8,reg09_8,reg10_8,reg11_8,reg12_8,reg13_8,reg14_8,reg15_8,reg16_8,reg17_8,reg18_8,reg19_8,reg20_8,reg21_8,reg22_8,reg23_8,reg24_8)

reg9<-c(reg01_9,reg02_9,reg03_9,reg04_9,reg05_9,reg06_9,reg07_9,reg08_9,reg09_9,reg10_9,reg11_9,reg12_9,reg13_9,reg14_9,reg15_9,reg16_9,reg17_9,reg18_9,reg19_9,reg20_9,reg21_9,reg22_9,reg23_9,reg24_9)

reg1=100*reg1
reg2=100*reg2
reg3=100*reg3
reg4=100*reg4
reg5=100*reg5
reg6=100*reg6
reg7=100*reg7
reg8=100*reg8
reg9=100*reg9


covid<-data.frame(reg1,reg2,reg3,reg4,reg5,reg6,reg7,reg8,reg9)
write.csv(covid,file="~/M1/TER/region infection.csv")












