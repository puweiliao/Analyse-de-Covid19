rm(list=objects())
graphics.off()
setwd("~/Desktop/project")
data.original.vaccination=read.csv("donnees-vaccination-par-tranche-dage-type-de-vaccin-et-departement.csv",sep=";")

data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="95")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="92")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="91")]<-2

data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="85")]<-1
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="86")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="80")]<-2

data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="79")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="78")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="76")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="75")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="72")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="18")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="28")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="36")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="37")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="41")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="45")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="02")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="14")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="27")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="50")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="61")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="59")]<-3
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="60")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="62")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="44")]<-1

data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="49")]<-1
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="53")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="22")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="29")]<-1
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="35")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="56")]<-1





############
############
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="90")]<-4

data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="94")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="93")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="89")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="88")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="77")]<-2
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="71")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="70")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="68")]<-4
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="67")]<-4
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="21")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="25")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="39")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="58")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="08")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="10")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="51")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="52")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="54")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="55")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="57")]<-4





data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="84")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="83")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="73")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="74")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="69")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="66")]<-7
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="01")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="03")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="07")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="15")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="26")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="38")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="42")]<-5
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="43")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="63")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="04")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="05")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="06")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="13")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="2A")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="2B")]<-9



data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="87")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="82")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="81")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="16")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="17")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="19")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="23")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="24")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="33")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="40")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="47")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="64")]<-8
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="9")]<-7
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="11")]<-7
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="12")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="30")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="31")]<-7
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="32")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="34")]<-6
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="46")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="48")]<-9
data.original.vaccination$departement_residence[which(data.original.vaccination$departement_residence=="65")]<-8


####semaine_injection 2021_01 2021_24
data.f.vaccination<-data.original.vaccination[,c("departement_residence","taux_cumu_termine","semaine_injection")]

#######On remplace NA par 0
data.original.vaccination$taux_cumu_termine[is.na(data.original.vaccination$taux_cumu_termine)]=0




V01_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="1")])
V02_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="1")])
V03_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="1")])
V04_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="1")])
V05_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="1")])
V06_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="1")])
V07_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="1")])
V08_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="1")])
V09_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="1")])
V10_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="1")])
V11_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="1")])
V12_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="1")])
V13_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="1")])
V14_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="1")])
V15_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="1")])
V16_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="1")])
V17_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="1")])
V18_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="1")])
V19_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="1")])
V20_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="1")])
V21_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="1")])
V22_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="1")])
V23_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="1")])
V24_r1<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="1")])


V01_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="2")])
V02_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="2")])
V03_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="2")])
V04_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="2")])
V05_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="2")])
V06_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="2")])
V07_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="2")])
V08_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="2")])
V09_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="2")])
V10_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="2")])
V11_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="2")])
V12_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="2")])
V13_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="2")])
V14_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="2")])
V15_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="2")])
V16_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="2")])
V17_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="2")])
V18_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="2")])
V19_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="2")])
V20_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="2")])
V21_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="2")])
V22_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="2")])
V23_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="2")])
V24_r2<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="2")])

V01_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="3")])
V02_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="3")])
V03_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="3")])
V04_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="3")])
V05_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="3")])
V06_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="3")])
V07_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="3")])
V08_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="3")])
V09_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="3")])
V10_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="3")])
V11_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="3")])
V12_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="3")])
V13_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="3")])
V14_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="3")])
V15_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="3")])
V16_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="3")])
V17_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="3")])
V18_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="3")])
V19_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="3")])
V20_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="3")])
V21_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="3")])
V22_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="3")])
V23_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="3")])
V24_r3<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="3")])



V01_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="4")])
V02_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="4")])
V03_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="4")])
V04_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="4")])
V05_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="4")])
V06_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="4")])
V07_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="4")])
V08_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="4")])
V09_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="4")])
V10_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="4")])
V11_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="4")])
V12_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="4")])
V13_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="4")])
V14_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="4")])
V15_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="4")])
V16_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="4")])
V17_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="4")])
V18_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="4")])
V19_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="4")])
V20_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="4")])
V21_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="4")])
V22_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="4")])
V23_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="4")])
V24_r4<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="4")])

V01_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="5")])
V02_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="5")])
V03_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="5")])
V04_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="5")])
V05_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="5")])
V06_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="5")])
V07_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="5")])
V08_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="5")])
V09_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="5")])
V10_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="5")])
V11_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="5")])
V12_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="5")])
V13_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="5")])
V14_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="5")])
V15_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="5")])
V16_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="5")])
V17_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="5")])
V18_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="5")])
V19_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="5")])
V20_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="5")])
V21_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="5")])
V22_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="5")])
V23_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="5")])
V24_r5<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="5")])



V01_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="6")])
V02_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="6")])
V03_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="6")])
V04_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="6")])
V05_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="6")])
V06_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="6")])
V07_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="6")])
V08_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="6")])
V09_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="6")])
V10_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="6")])
V11_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="6")])
V12_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="6")])
V13_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="6")])
V14_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="6")])
V15_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="6")])
V16_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="6")])
V17_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="6")])
V18_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="6")])
V19_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="6")])
V20_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="6")])
V21_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="6")])
V22_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="6")])
V23_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="6")])
V24_r6<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="6")])


V01_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="7")])
V02_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="7")])
V03_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="7")])
V04_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="7")])
V05_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="7")])
V06_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="7")])
V07_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="7")])
V08_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="7")])
V09_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="7")])
V10_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="7")])
V11_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="7")])
V12_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="7")])
V13_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="7")])
V14_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="7")])
V15_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="7")])
V16_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="7")])
V17_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="7")])
V18_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="7")])
V19_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="7")])
V20_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="7")])
V21_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="7")])
V22_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="7")])
V23_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="7")])
V24_r7<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="7")])


V01_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="8")])
V02_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="8")])
V03_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="8")])
V04_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="8")])
V05_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="8")])
V06_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="8")])
V07_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="8")])
V08_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="8")])
V09_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="8")])
V10_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="8")])
V11_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="8")])
V12_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="8")])
V13_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="8")])
V14_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="8")])
V15_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="8")])
V16_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="8")])
V17_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="8")])
V18_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="8")])
V19_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="8")])
V20_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="8")])
V21_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="8")])
V22_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="8")])
V23_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="8")])
V24_r8<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="8")])

V01_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-01" & data.original.vaccination$departement_residence=="9")])
V02_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-02" & data.original.vaccination$departement_residence=="9")])
V03_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-03" & data.original.vaccination$departement_residence=="9")])
V04_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-04" & data.original.vaccination$departement_residence=="9")])
V05_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-05" & data.original.vaccination$departement_residence=="9")])
V06_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-06" & data.original.vaccination$departement_residence=="9")])
V07_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-07" & data.original.vaccination$departement_residence=="9")])
V08_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-08" & data.original.vaccination$departement_residence=="9")])
V09_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-09" & data.original.vaccination$departement_residence=="9")])
V10_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-10" & data.original.vaccination$departement_residence=="9")])
V11_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-11" & data.original.vaccination$departement_residence=="9")])
V12_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-12" & data.original.vaccination$departement_residence=="9")])
V13_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-13" & data.original.vaccination$departement_residence=="9")])
V14_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-14" & data.original.vaccination$departement_residence=="9")])
V15_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-15" & data.original.vaccination$departement_residence=="9")])
V16_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-16" & data.original.vaccination$departement_residence=="9")])
V17_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-17" & data.original.vaccination$departement_residence=="9")])
V18_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-18" & data.original.vaccination$departement_residence=="9")])
V19_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-19" & data.original.vaccination$departement_residence=="9")])
V20_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-20" & data.original.vaccination$departement_residence=="9")])
V21_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-21" & data.original.vaccination$departement_residence=="9")])
V22_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-22" & data.original.vaccination$departement_residence=="9")])
V23_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-23" & data.original.vaccination$departement_residence=="9")])
V24_r9<-mean(data.original.vaccination$taux_cumu_termine[which(data.original.vaccination$semaine_injection=="2021-24" & data.original.vaccination$departement_residence=="9")])



r1=c(V01_r1,V02_r1, V03_r1, V04_r1, V05_r1, V06_r1, V07_r1, V08_r1, V09_r1, V10_r1, V11_r1, V12_r1, V13_r1, V14_r1, V15_r1, V16_r1, V17_r1, V18_r1, V19_r1, V20_r1, V21_r1, V22_r1, V23_r1,V24_r1)
r2=c(V01_r2,V02_r2, V03_r2, V04_r2, V05_r2, V06_r2, V07_r2, V08_r2, V09_r2, V10_r2, V11_r2, V12_r2, V13_r2, V14_r2, V15_r2, V16_r2, V17_r2, V18_r2, V19_r2, V20_r2, V21_r2, V22_r2, V23_r2,V24_r2)
r3=c(V01_r3,V02_r3, V03_r3, V04_r3, V05_r3, V06_r3, V07_r3, V08_r3, V09_r3, V10_r3, V11_r3, V12_r3, V13_r3, V14_r3, V15_r3, V16_r3, V17_r3, V18_r3, V19_r3, V20_r3, V21_r3, V22_r3, V23_r3,V24_r3)
r4=c(V01_r4,V02_r4, V03_r4, V04_r4, V05_r4, V06_r4, V07_r4, V08_r4, V09_r4, V10_r4, V11_r4, V12_r4, V13_r4, V14_r4, V15_r4, V16_r4, V17_r4, V18_r4, V19_r4, V20_r4, V21_r4, V22_r4, V23_r4,V24_r4)
r5=c(V01_r5,V02_r5, V03_r5, V04_r5, V05_r5, V06_r5, V07_r5, V08_r5, V09_r5, V10_r5, V11_r5, V12_r5, V13_r5, V14_r5, V15_r5, V16_r5, V17_r5, V18_r5, V19_r5, V20_r5, V21_r5, V22_r5, V23_r5,V24_r5)
r6=c(V01_r6,V02_r6, V03_r6, V04_r6, V05_r6, V06_r6, V07_r6, V08_r6, V09_r6, V10_r6, V11_r6, V12_r6, V13_r6, V14_r6, V15_r6, V16_r6, V17_r6, V18_r6, V19_r6, V20_r6, V21_r6, V22_r6, V23_r6,V24_r6)
r7=c(V01_r7,V02_r7, V03_r7, V04_r7, V05_r7, V06_r7, V07_r7, V08_r7, V09_r7, V10_r7, V11_r7, V12_r7, V13_r7, V14_r7, V15_r7, V16_r7, V17_r7, V18_r7, V19_r7, V20_r7, V21_r7, V22_r7, V23_r7,V24_r7)
r8=c(V01_r8,V02_r8, V03_r8, V04_r8, V05_r8, V06_r8, V07_r8, V08_r8, V09_r8, V10_r8, V11_r8, V12_r8, V13_r8, V14_r8, V15_r8, V16_r8, V17_r8, V18_r8, V19_r8, V20_r8, V21_r8, V22_r8, V23_r8,V24_r8)
r9=c(V01_r9,V02_r9, V03_r9, V04_r9, V05_r9, V06_r9, V07_r9, V08_r9, V09_r9, V10_r9, V11_r9, V12_r9, V13_r9, V14_r9, V15_r9, V16_r9, V17_r9, V18_r9, V19_r9, V20_r9, V21_r9, V22_r9, V23_r9,V24_r9)

r1=100*r1
r2=100*r2
r3=100*r3
r4=100*r4
r5=100*r5
r6=100*r6
r7=100*r7
r8=100*r8
r9=100*r9

vaccination<-data.frame(r1,r2,r3,r4,r5,r6,r7,r8,r9)
write.csv(vaccination,file="~/Desktop/project/vaccination_region.csv")
