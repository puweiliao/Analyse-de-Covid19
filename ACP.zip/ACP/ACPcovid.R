setwd("~/M1/TER/ACP")
seeds=read.csv("dataframe_covid.csv")
#seeds$taux_maladie_national=seeds$taux_maladie_national*100#poids important
library(rwa)
library(tidyverse)
library(FactoMineR)
#res=PCA(seeds[,-1])
res=PCA(seeds)


#rwa(seeds,seeds$taux_maladie_national,c(seeds$temperature,seeds$taux_infection_age1,seeds$taux_infection_age2,seeds$taux_infection_region1,seeds$taux_infection_region2,seeds$taux_infection_region3,seeds$taux_infection_region4,seeds$taux_infection_region5,seeds$taux_infection_region6,seeds$taux_infection_region7,seeds$taux_infection_region8,seeds$taux_infection_region9,seeds$taux_vaccination_age1,seeds$taux_vaccination_age2,seeds$taux_vaccination_region1,seeds$taux_vaccination_region2,seeds$taux_vaccination_region3,seeds$taux_vaccination_region4,seeds$taux_vaccination_region5,seeds$taux_vaccination_region6,seeds$taux_vaccination_region7,seeds$taux_vaccination_region8,seeds$taux_vaccination_region9,seeds$temps,seeds$politique))
                                        
                                        
res_rwa=rwa(seeds,"taux_maladie_national",c("temperature","taux_infection_age1","taux_infection_age2","taux_infection_region1"
                                            ,"taux_infection_region2","taux_infection_region3","taux_infection_region4",
                                            "taux_infection_region5","taux_infection_region6","taux_infection_region7",
                                            "taux_infection_region8","taux_infection_region9","taux_vaccination_age1",
                                            "taux_vaccination_age2","taux_vaccination_region1","taux_vaccination_region2",
                                            "taux_vaccination_region3","taux_vaccination_region4","taux_vaccination_region5",
                                            "taux_vaccination_region6","taux_vaccination_region7","taux_vaccination_region8",
                                            "taux_vaccination_region9","temps","politique"))                                        
                                        



res_rwa2=rwa(seeds,"taux_maladie_national",c("temperature","taux_infection_age1","taux_infection_age2","taux_vaccination_age1","taux_vaccination_age2","temps","politique"))                                     
#rwa(region_infection)
#rwa(region_vaccination)
                              












#poids
#variable semaine n'a pas de sens! mais avec un poids 0, car semaine important
#mat corrélation c'est mat covariance

#cov(x,y)=E(xy)-ExEy=E((x-/bar(x)(y-/bar(y))) 
#cor(x,y)=E((x-/bar(x)/ /bar(x)) (y-/bar(y)/ /bar(y))))


#cor(x,2y)=E((x-/bar(x)/ /bar(x)) (2y-2/bar(y)/ 2/bar(y))))=change pas!
#normaliser!!!!




plot(seeds$taux_maladie_national,type = "l", xlab = "Semaine de 2021 (04/01/2021-14/06/2021)", ylab = "Taux d'infection en France%", col = "royalblue3")
points(seeds$taux_maladie_national,pch=20)


plot(seeds$taux_infection_age1,type = "l", xlab = "Semaine de 2021 (04/01/2021-14/06/2021)", ylab = "Taux d'infection par age", col = "royalblue3")
lines(seeds$taux_infection_age2,col=1)
legend("topleft",legend=c("Taux infection <54ans","Taux infection >54ans"),col=c("royalblue3",1),lwd=2,lty = 1)




plot(seeds$taux_infection_region3,type = "l", xlab = "Semaine de 2021 (04/01/2021-14/06/2021)", ylab = "Taux de vaccination régional", col = "royalblue3")
lines(seeds$taux_infection_region2,col=2)
lines(seeds$taux_infection_region4,col=3)
lines(seeds$taux_infection_region1,col=4)
lines(seeds$taux_infection_region5,col=5)
lines(seeds$taux_infection_region6,col=6)
lines(seeds$taux_infection_region7,col=7)
lines(seeds$taux_infection_region8,col=8)
lines(seeds$taux_infection_region9,col=9)
legend("topleft",legend=c("infec_reg1","infec_reg2","infec_reg3","infec_reg4","infec_reg5","infec_reg6","infec_reg7","infec_reg8","infec_reg9"),col=c(4,2,"royalblue3",3,5,6,7,8,9),lwd=2,lty = 1)



plot(seeds$taux_vaccination_age2,type = "l", xlab = "Semaine de 2021 (04/01/2021-14/06/2021)", ylab = "Taux d'vaccination par age", col = "royalblue3")
lines(seeds$taux_vaccination_age1,col=1)
legend("topleft",legend=c("Taux vaccination <54ans","Taux vaccination >54ans"),col=c(1,"royalblue3"),lwd=2,lty = 1)




plot(seeds$taux_vaccination_region3,type = "l", xlab = "Semaine de 2021 (04/01/2021-14/06/2021)", ylab = "Taux de vaccination régional", col = "royalblue3")
lines(seeds$taux_vaccination_region2,col=2)
lines(seeds$taux_vaccination_region4,col=3)
lines(seeds$taux_vaccination_region1,col=4)
lines(seeds$taux_vaccination_region5,col=5)
lines(seeds$taux_vaccination_region6,col=6)
lines(seeds$taux_vaccination_region7,col=7)
lines(seeds$taux_vaccination_region8,col=8)
lines(seeds$taux_vaccination_region9,col=9)
legend("topleft",legend=c("vac_reg1","vac_reg2","vac_reg3","vac_reg4","vac_reg5","vac_reg6","vac_reg7","vac_reg8","vac_reg9"),col=c(4,2,"royalblue3",3,5,6,7,8,9),lwd=2,lty = 1)








#ACP#########################################
############


pairs(seeds[,-1])
#why rounds???????????
round(cor(seeds[,-1]),2)

library(corrplot)
#plot corrélation 2 par 2
corrplot(cor(seeds[,-1]), method="circle")

library(car)
#comment analyser??????
scatterplotMatrix(as.matrix(seeds[,-1]))
#comment analyser???????
boxplot(seeds[,-1])

library(GGally)
ggpairs(seeds[,-1])

round(apply(seeds[,-1], 2, var), 2)


n=nrow(seeds)



############
#PCA
############
par(mfrow=c(1,2))

res=PCA(seeds[,-1])
res              # comment acc?der aux sorties
round(res$eig,4) # variance de chacun des 7 axes
sum(res$eig[,1])
barplot(res$eig[,2],main="% inertie",names=paste("Dim",1:nrow(res$eig)))
abline(h=100/7,lty=2)

### Etude des variables
V=res$var
plot(res,choix="var")

#qualit? de repr?sentation
V$cos2
V$cor^2

# corr?lation
V$cor

#contribution ? l'axe
V$contrib
V$cos2[,1]/sum(V$cos2[,1])

#visualisation
par(mfrow=c(1,2))
plot(res,axes = c(1,2), choix = "var",graph.type = "classic")
# axe 1 = effet taille
# axe 2 = opposition asymetrie - compacit?
# axe 3 = compacit? + asym?trie  
plot(res,axes = c(2,3), choix = "var",graph.type = "classic")

### Etude des individus
par(mfrow=c(1,2))
plot(res,axes = c(1,2), choix = "var",graph.type = "classic")
plot(res,axes = c(1,2), choix = "ind",label="none",graph.type = "classic")
# Dans le premier quadrant droit, individus plut?t grands et asym?triques; 
# ? gauche en haut, individus petits et asym?triques, 
# en bas au centre, de taille moyenne et r?guliers

Ind=res$ind
#indi=c(19,39,58,89,90,95,178)
#points(Ind$coord[indi,1],Ind$coord[indi,2],col="red",pch=20)
#text(Ind$coord[indi,1],Ind$coord[indi,2],as.character(indi),pos=3,cex=0.7,col=2)

# contributions
apply(Ind$contrib,2,which.max)   # le plus contributif sur chaque axe

head(sort(Ind$contrib[, 1],decreasing=TRUE)) # les premiers contibutifs du premier axe


# cosinus carré : qualité de représentration
which.max(Ind$cos2[,2])

#on passe à la direction suivante
plot(res,axes = c(2,3), choix = "var",graph.type = "classic")
plot(res,axes = c(2,3), choix = "ind",label="none",graph.type = "classic")
#points(Ind$coord[indi,2],Ind$coord[indi,3],col="red",pch=20)
#text(res$ind$coord[indi,2],res$ind$coord[indi,3],as.character(indi),pos=3,cex=0.7,col=2)

### contributif et mal représenté sur l'axe 3
which(res$ind$cos2[,3]<0.15 & res$ind$contrib[,3]>1)

#c(contrib=Ind$contrib[89,3],cos2= Ind$cos2[89,3])


### contributif et bien repr?sent? sur l'axe 2
#which(res$ind$cos2[,2]>0.95 & res$ind$contrib[,2]>0.85) #58
#c(contrib=Ind$contrib[58,2],cos2= Ind$cos2[58,2])

### Etude simultane
par(mfrow=c(2,2))
plot(res,axes = c(1,2), choix = "ind",label="none",graph.type = "classic")
plot(res,axes = c(2,3), choix = "ind",label="none",graph.type = "classic")
plot(res,axes = c(1,2), choix = "var",graph.type = "classic")
plot(res,axes = c(2,3), choix = "var",graph.type = "classic")





