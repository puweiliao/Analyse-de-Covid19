
setwd("~/M1/TER/ACP")
seeds=read.csv("dataframe_covid.csv")
library(rwa)
library(tidyverse)





res_rwa_reste=rwa(seeds,"taux_maladie_national",c("temperature","taux_infection_age1","taux_infection_age2","taux_vaccination_age1","taux_vaccination_age2","temps","politique"))                                     
res_rwa_region_infection=rwa(seeds,"taux_maladie_national",c("taux_infection_region1"
                                                             ,"taux_infection_region2","taux_infection_region3","taux_infection_region4",
                                                             "taux_infection_region5","taux_infection_region6","taux_infection_region7",
                                                             "taux_infection_region8","taux_infection_region9"))
res_rwa_region_vaccination=rwa(seeds,"taux_maladie_national",c("taux_vaccination_region1","taux_vaccination_region2",
                               "taux_vaccination_region3","taux_vaccination_region4","taux_vaccination_region5",
                               "taux_vaccination_region6","taux_vaccination_region7","taux_vaccination_region8",
                               "taux_vaccination_region9"))
